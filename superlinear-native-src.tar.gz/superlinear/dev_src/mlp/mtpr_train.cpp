/*   This software is called MLIP for Machine Learning Interatomic Potentials.
 *   MLIP can only be used for non-commercial research and cannot be re-distributed.
 *   The use of MLIP must be acknowledged by citing approriate references.
 *   See the LICENSE file for details.
 */

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <ctime>
#include <functional>
#include <iomanip>
#include <limits>
#include <map>
#include <numeric>
#include <random>
#include <sstream>
#include <sys/stat.h>
#include <unistd.h>

#include "mtpr_train.h"
#include "../sh_model_init.h"
#include "../optimizer_checkpoint.h"
#include "../rescale_search.h"
#include "../../src/zbl.h"

using namespace std;

char* mtpfnm;
char* cfgfnm;

int prank = 0;
int psize = 1;

vector<Configuration> training_set;
vector<Configuration> validSet;

struct DatasetStats {
	long long cfg_count = 0;
	long long atom_count = 0;
};

struct MomentCoeffStats {
	double center_log = 0.0;
	double spread_log = 0.0;
	std::size_t count = 0;
	bool valid = false;
};

struct RescaleEvalResult {
	double scaling = 0.0;
	MomentCoeffStats stats;
	std::vector<double> coeffs;
	bool valid = false;
};

constexpr std::size_t kNeighborhoodCacheBudgetBytesPerRank = 4ULL * 1024ULL * 1024ULL * 1024ULL;

namespace {

int ParseOptionalNonnegativeInteger(
	const std::map<std::string, std::string>& opts,
	const std::string& name)
{
	const auto it = opts.find(name);
	if (it == opts.end())
		return -1;
	const std::string& value = it->second;
	if (value.empty()
	    || !std::all_of(value.begin(), value.end(), [](char ch) {
		    return ch >= '0' && ch <= '9';
	    }))
		ERROR("--" + name + " should be a non-negative integer written as --"
		      + name + "=<R>");
	try {
		return std::stoi(value);
	} catch (const std::exception&) {
		ERROR("--" + name + " is outside the supported integer range");
	}
}

std::string CurrentTimestamp()
{
	std::time_t now = std::time(nullptr);
	char buf[32];
	std::strftime(buf, sizeof(buf), "%F %T", std::localtime(&now));
	return std::string(buf);
}

std::string SanitizeShardTag(const std::string& value)
{
	std::string sanitized;
	sanitized.reserve(value.size());
	for (char ch : value) {
		if ((ch >= 'a' && ch <= 'z') ||
		    (ch >= 'A' && ch <= 'Z') ||
		    (ch >= '0' && ch <= '9'))
			sanitized.push_back(ch);
		else
			sanitized.push_back('_');
	}
	return sanitized;
}

std::string MakeShardDir(const std::string& cfgfnm, const std::string& label)
{
	std::string basename = cfgfnm;
	size_t slash = basename.find_last_of("/\\");
	if (slash != std::string::npos)
		basename = basename.substr(slash + 1);
	return ".cfg_shards_" + label + "_" + SanitizeShardTag(basename) + "_" +
		std::to_string(static_cast<long long>(std::time(nullptr))) + "_" +
		std::to_string(static_cast<long long>(getpid()));
}

DatasetStats LoadConfigsFromFile(const std::string& cfgfnm, std::vector<Configuration>& target)
{
	DatasetStats stats;
	target.clear();
	Configuration cfg;
	std::ifstream ifs(cfgfnm, std::ios::binary);
	for (; cfg.Load(ifs); ) {
		target.push_back(cfg);
		stats.cfg_count++;
		stats.atom_count += cfg.size();
	}
	return stats;
}

std::pair<double, double> ParseRangeOption(const std::string& value, const std::string& opt_name)
{
	const std::size_t comma = value.find(',');
	if (comma == std::string::npos || value.find(',', comma + 1) != std::string::npos)
		ERROR(opt_name + " should contain exactly two comma-separated doubles");

	const std::string first = value.substr(0, comma);
	const std::string second = value.substr(comma + 1);
	if (first.empty() || second.empty())
		ERROR(opt_name + " should contain exactly two comma-separated doubles");

	try {
		return std::make_pair(std::stod(first), std::stod(second));
	} catch (const std::exception&) {
		ERROR(opt_name + " should contain exactly two comma-separated doubles");
	}
}

std::vector<double> ParseDoubleListOption(const std::string& value, const std::string& opt_name)
{
	std::vector<double> values;
	std::size_t begin = 0;
	while (begin <= value.size()) {
		const std::size_t comma = value.find(',', begin);
		const std::size_t end = (comma == std::string::npos) ? value.size() : comma;
		const std::string token = value.substr(begin, end - begin);
		if (token.empty())
			ERROR(opt_name + " should be a comma-separated list of finite doubles");
		try {
			const double parsed = std::stod(token);
			if (!std::isfinite(parsed))
				ERROR(opt_name + " should be a comma-separated list of finite doubles");
			values.push_back(parsed);
		} catch (const std::exception&) {
			ERROR(opt_name + " should be a comma-separated list of finite doubles");
		}
		if (comma == std::string::npos)
			break;
		begin = comma + 1;
	}
	if (values.empty())
		ERROR(opt_name + " should be a comma-separated list of finite doubles");
	return values;
}

double ParseStrictDoubleOption(const std::string& value, const std::string& opt_name)
{
	std::size_t parsed = 0;
	double result = 0.0;
	try {
		result = std::stod(value, &parsed);
	} catch (const std::exception&) {
		ERROR(opt_name + " should be a finite double.");
	}
	if (parsed != value.size() || !std::isfinite(result))
		ERROR(opt_name + " should be a finite double.");
	return result;
}

struct OptionalRandomSeed {
	bool has_value = false;
	std::mt19937_64::result_type value = 0;
};

OptionalRandomSeed ParseOptionalRandomSeed(
	const std::map<std::string, std::string>& opts)
{
	const auto it = opts.find("init-random-seed");
	if (it == opts.end() || it->second.empty())
		return OptionalRandomSeed();
	const std::string& value = it->second;
	if (!std::all_of(value.begin(), value.end(), [](char ch) {
		return ch >= '0' && ch <= '9';
	}))
		ERROR("--init-random-seed should be an unsigned integer");
	std::size_t parsed = 0;
	unsigned long long seed = 0;
	try {
		seed = std::stoull(value, &parsed);
	} catch (const std::exception&) {
		ERROR("--init-random-seed is outside the supported uint64 range");
	}
	if (parsed != value.size()
	    || seed > std::numeric_limits<std::mt19937_64::result_type>::max())
		ERROR("--init-random-seed is outside the supported uint64 range");
	OptionalRandomSeed result;
	result.has_value = true;
	result.value = static_cast<std::mt19937_64::result_type>(seed);
	return result;
}

struct ZBLTrainOptions {
	bool enabled = false;
	double inner = DefaultZBLInnerCutoff();
	double outer = DefaultZBLOuterCutoff();
	bool typewise = false;
	double typewise_factor = DefaultZBLTypewiseCutoffFactor();
	std::vector<int> atomic_numbers;
};

bool HasOption(const std::map<std::string, std::string>& opts, const std::string& name)
{
	std::map<std::string, std::string>::const_iterator it = opts.find(name);
	return it != opts.end() && !it->second.empty();
}

bool HasAnyZBLOption(const std::map<std::string, std::string>& opts)
{
	return HasOption(opts, "zbl-elements")
	    || HasOption(opts, "zbl-inner")
	    || HasOption(opts, "zbl-outer")
	    || HasOption(opts, "zbl-typewise-cutoff-factor");
}

ZBLTrainOptions ParseZBLTrainOptions(const std::map<std::string, std::string>& opts)
{
	ZBLTrainOptions zbl;
	if (!HasAnyZBLOption(opts))
		return zbl;
	if (!HasOption(opts, "zbl-elements"))
		ERROR("ZBL requires --zbl-elements=<comma-separated symbols or atomic numbers>.");
	zbl.enabled = true;
	zbl.atomic_numbers = ParseZBLAtomicNumbers(opts.find("zbl-elements")->second);
	if (HasOption(opts, "zbl-inner"))
		zbl.inner = ParseStrictDoubleOption(opts.find("zbl-inner")->second,
		                                    "--zbl-inner");
	if (HasOption(opts, "zbl-outer"))
		zbl.outer = ParseStrictDoubleOption(opts.find("zbl-outer")->second,
		                                    "--zbl-outer");
	if (!std::isfinite(zbl.inner) || zbl.inner < 0.0)
		ERROR("--zbl-inner should be finite and non-negative.");
	if (!std::isfinite(zbl.outer) || zbl.outer <= 0.0)
		ERROR("--zbl-outer should be finite and positive.");
	zbl.typewise = HasOption(opts, "zbl-typewise-cutoff-factor");
	if (zbl.typewise) {
		zbl.typewise_factor =
			ParseStrictDoubleOption(opts.find("zbl-typewise-cutoff-factor")->second,
			                        "--zbl-typewise-cutoff-factor");
		if (!std::isfinite(zbl.typewise_factor) || zbl.typewise_factor < 0.5)
			ERROR("--zbl-typewise-cutoff-factor should be finite and >= 0.5.");
	} else if (zbl.outer <= zbl.inner) {
		ERROR("--zbl-inner and --zbl-outer should satisfy 0 <= inner < outer.");
	}
	return zbl;
}

MomentCoeffStats ComputeMomentCoeffStats(const MLMTPR& mtpr)
{
	constexpr double kMomentCoeffEps = 1.0e-12;
	MomentCoeffStats stats;
	std::vector<double> logs;
	logs.reserve(mtpr.linear_coeffs.size());

	for (int i = 0; i < static_cast<int>(mtpr.linear_coeffs.size()) - mtpr.species_count; ++i) {
		const double coeff = std::abs(mtpr.linear_coeffs[i + mtpr.species_count]);
		if (coeff > kMomentCoeffEps)
			logs.push_back(std::log(coeff));
	}

	if (logs.empty())
		return stats;

	std::sort(logs.begin(), logs.end());
	stats.count = logs.size();
	stats.center_log = logs[logs.size() / 2];

	double sq_sum = 0.0;
	for (double value : logs) {
		const double diff = value - stats.center_log;
		sq_sum += diff * diff;
	}
	stats.spread_log = std::sqrt(sq_sum / logs.size());
	stats.valid = true;
	return stats;
}

double RescaleMetric(const MomentCoeffStats& stats)
{
	constexpr double kMetricCenterWeight = 3.0;
	return stats.spread_log * stats.spread_log
	     + kMetricCenterWeight * stats.center_log * stats.center_log;
}

long long SumAtoms(const std::vector<Configuration>& configs)
{
	long long atoms = 0;
	for (const Configuration& cfg : configs)
		atoms += cfg.size();
	return atoms;
}

long long EstimateConfigWork(const Configuration& cfg)
{
	return cfg.size();
}

void LogShardBalance(const std::string& label,
					 const std::vector<long long>& cfg_counts,
					 const std::vector<long long>& atom_counts,
					 const std::vector<long long>& cost_counts)
{
	if (cfg_counts.empty())
		return;

	const auto cfg_minmax = std::minmax_element(cfg_counts.begin(), cfg_counts.end());
	const auto atom_minmax = std::minmax_element(atom_counts.begin(), atom_counts.end());
	const auto cost_minmax = std::minmax_element(cost_counts.begin(), cost_counts.end());
	const double atom_avg = std::accumulate(atom_counts.begin(), atom_counts.end(), 0.0) / atom_counts.size();
	const double cost_avg = std::accumulate(cost_counts.begin(), cost_counts.end(), 0.0) / cost_counts.size();

	std::cout << "[" << CurrentTimestamp() << "] "
			  << label
			  << " shard balance: cfg[min,max]=" << *cfg_minmax.first << "," << *cfg_minmax.second
			  << " atoms[min,max,avg]=" << *atom_minmax.first << "," << *atom_minmax.second << "," << atom_avg
			  << " load[min,max,avg]=" << *cost_minmax.first << "," << *cost_minmax.second << "," << cost_avg
			  << std::endl;
}

long long GlobalAtomCount(const std::vector<Configuration>& configs)
{
	long long atoms = SumAtoms(configs);
#ifdef MLIP_MPI
	long long total_atoms = 0;
	MPI_Allreduce(&atoms, &total_atoms, 1, MPI_LONG_LONG_INT, MPI_SUM, MPI_COMM_WORLD);
	return total_atoms;
#else
	return atoms;
#endif
}

std::vector<Neighborhoods> BuildNeighborhoods(const std::vector<Configuration>& configs, double cutoff)
{
	std::vector<Neighborhoods> neighborhoods;
	neighborhoods.reserve(configs.size());
	for (size_t idx = 0; idx < configs.size(); ++idx) {
		const Configuration& cfg = configs[idx];
		double min_lattice_len = 0.0;
		double max_lattice_len = 0.0;
		if (cfg.lattice.det() != 0.0) {
			min_lattice_len = max_lattice_len = std::sqrt(
				cfg.lattice[0][0] * cfg.lattice[0][0] +
				cfg.lattice[0][1] * cfg.lattice[0][1] +
				cfg.lattice[0][2] * cfg.lattice[0][2]);
			for (int a = 0; a < 3; ++a) {
				const double len = std::sqrt(
					cfg.lattice[a][0] * cfg.lattice[a][0] +
					cfg.lattice[a][1] * cfg.lattice[a][1] +
					cfg.lattice[a][2] * cfg.lattice[a][2]);
				min_lattice_len = std::min(min_lattice_len, len);
				max_lattice_len = std::max(max_lattice_len, len);
			}
		}
		const auto start_time = std::chrono::steady_clock::now();
		neighborhoods.emplace_back(cfg, cutoff);
		const double elapsed_seconds = std::chrono::duration<double>(
			std::chrono::steady_clock::now() - start_time).count();
		if (elapsed_seconds > 10.0) {
			std::cout << "[" << CurrentTimestamp() << "] "
			          << "Neighborhood build done"
			          << " rank=" << prank
			          << " local_cfg=" << idx
			          << " atoms=" << cfg.size()
			          << " elapsed_s=" << elapsed_seconds
			          << std::endl;
		}
	}
	return neighborhoods;
}

bool TryBuildNeighborhoods(const std::vector<Configuration>& configs,
						   double cutoff,
						   std::vector<Neighborhoods>& neighborhoods_out)
{
	try {
		neighborhoods_out = BuildNeighborhoods(configs, cutoff);
		return true;
	}
	catch (const std::bad_alloc&) {
		neighborhoods_out.clear();
		neighborhoods_out.shrink_to_fit();
		return false;
	}
}

double EstimateConfigurationVolume(const Configuration& cfg)
{
	double volume = std::abs(cfg.lattice.det());
	if (volume > 1.0e-12)
		return volume;

	if (cfg.size() == 0)
		return 0.0;

	Vector3 min_pos = cfg.pos(0);
	Vector3 max_pos = cfg.pos(0);
	for (int i = 1; i < cfg.size(); ++i) {
		for (int a = 0; a < 3; ++a) {
			min_pos[a] = std::min(min_pos[a], cfg.pos(i, a));
			max_pos[a] = std::max(max_pos[a], cfg.pos(i, a));
		}
	}

	const double dx = std::max(1.0e-6, max_pos[0] - min_pos[0]);
	const double dy = std::max(1.0e-6, max_pos[1] - min_pos[1]);
	const double dz = std::max(1.0e-6, max_pos[2] - min_pos[2]);
	return dx * dy * dz;
}

std::size_t EstimateNeighborhoodCacheBytes(const std::vector<Configuration>& configs, double cutoff)
{
	const double sphere_volume = (4.0 / 3.0) * M_PI * cutoff * cutoff * cutoff;
	long double total_bytes = 0.0L;
	for (const Configuration& cfg : configs) {
		if (cfg.size() == 0)
			continue;

		const double volume = EstimateConfigurationVolume(cfg);
		const double number_density = volume > 1.0e-12 ? static_cast<double>(cfg.size()) / volume : 0.0;
		const double expected_neighbors = std::max(1.0, sphere_volume * number_density);
		const long double entries = static_cast<long double>(cfg.size()) * expected_neighbors;
		total_bytes += static_cast<long double>(cfg.size()) * 160.0L;
		total_bytes += entries * 96.0L;
	}
	if (total_bytes < 0.0L)
		return 0;
	if (total_bytes > static_cast<long double>(std::numeric_limits<std::size_t>::max()))
		return std::numeric_limits<std::size_t>::max();
	return static_cast<std::size_t>(total_bytes);
}

bool ShouldCacheNeighborhoods(const std::vector<Configuration>& configs, double cutoff, std::size_t* estimated_bytes = nullptr)
{
	const std::size_t bytes = EstimateNeighborhoodCacheBytes(configs, cutoff);
	if (estimated_bytes != nullptr)
		*estimated_bytes = bytes;

	const char* env = std::getenv("MLIP_CACHE_NEIGHBORHOODS");
	if (env != nullptr) {
		if (std::strcmp(env, "0") == 0 || std::strcmp(env, "false") == 0 || std::strcmp(env, "FALSE") == 0)
			return false;
		if (std::strcmp(env, "1") == 0 || std::strcmp(env, "true") == 0 || std::strcmp(env, "TRUE") == 0)
			return true;
	}
	return bytes <= kNeighborhoodCacheBudgetBytesPerRank;
}

void ApplyZBLResidualToDataset(std::vector<Configuration>& configs,
                               const ZBLPotential& zbl,
                               bool subtract,
                               const std::vector<Neighborhoods>* neighborhoods)
{
	if (neighborhoods != nullptr && neighborhoods->size() != configs.size())
		ERROR("ZBL residualization neighborhood cache size mismatch");
	const double sign = subtract ? -1.0 : 1.0;
	for (std::size_t cfg_index = 0; cfg_index < configs.size(); ++cfg_index) {
		Configuration& cfg = configs[cfg_index];
		const ZBLEFS zbl_efs = neighborhoods == nullptr ?
			zbl.Compute(cfg) :
			zbl.Compute(cfg, (*neighborhoods)[cfg_index]);
		if (cfg.has_energy())
			cfg.energy += sign * zbl_efs.energy;
		if (cfg.has_forces())
			for (int i = 0; i < cfg.size(); ++i)
				cfg.force(i) += sign * zbl_efs.forces[i];
		if (cfg.has_stresses())
			for (int a = 0; a < 3; ++a)
				for (int b = 0; b < 3; ++b)
					cfg.stresses[a][b] += sign * zbl_efs.stresses[a][b];
	}
}

bool HasSphericalHarmonicInitOptions(const std::map<std::string, std::string>& opts)
{
	const char* names[] = {
		"init-sh",
		"species-count",
		"l-max",
		"k-max",
		"body-order",
		"body-l-max",
		"body2-l-max",
		"body3-l-max",
		"body4-l-max",
		"body5-l-max",
		"body6-l-max",
			"sh-factor-pruning",
			"readout-mode",
			"joint-readout",
			"adaptive-radial-projection",
			"adaptive-radial-amplitude-mode",
			"adaptive-radial-shared-n-rank",
			"adaptive-radial-activation",
			"tensor-message-lmax",
			"write-sh-scalar-info",
		"cutoff",
		"max-dist",
		"min-dist",
		"radial-basis-size",
		"radial-basis-type",
		"radial-cutoff-type",
		"radial-cutoff-p",
		"scaling-map",
			"zbl-elements",
			"zbl-inner",
			"zbl-outer",
			"zbl-typewise-cutoff-factor",
			"scaling",
		"potential-name",
				"inline-sh-model",
					"two-layer-gate",
							"two-layer-gate-body-order",
							"two-layer-gate-factor-pruning",
							"two-layer-gate-mode",
							"two-layer-gate-tanh-amplitude",
						"two-layer-gate-site-mode",
							"two-layer-gate-shared-radial",
							"two-layer-gate-decoupled-scaling",
							"two-layer-gate-full-decoupled",
							"two-layer-gate-radial-mixing",
							"two-layer-gate-edge-l1",
							"two-layer-gate-readout",
							"outer-k-rank",
							"outer-k-rank1",
							"superlinear-mode",
							"two-layer-gate-k-rank",
						"multi-layer-gate",
							"second-layer-gate-body-order",
							"second-layer-gate-factor-pruning",
						"second-layer-gate-mode",
						"two-layer-residual"
			};
	for (const char* name : names) {
		std::map<std::string, std::string>::const_iterator it = opts.find(name);
		// The command dispatcher pre-populates known option keys with an empty
		// value.  Only a non-empty value means the user actually requested an
		// inline SH initialization option.  Treating mere key presence as an
		// explicit request silently changes `train train.cfg` into init-sh mode.
		if (it != opts.end() && !it->second.empty())
			return true;
	}
	return false;
}

bool IsSHFactorPruningValue(const std::string& value)
{
	return value == "same-k" || value == "legacy"
	    || value == "q-total" || value == "total";
}

std::string InlineSHModelFilename(const std::map<std::string, std::string>& opts)
{
	std::map<std::string, std::string>::const_iterator requested = opts.find("inline-sh-model");
	if (requested != opts.end() && !requested->second.empty())
	{
		sus2::ValidateModelOutputPath(requested->second);
		return requested->second;
	}

	std::ostringstream oss;
	oss << ".sus2sh_inline_init_"
	    << static_cast<long long>(std::time(nullptr))
	    << "_"
	    << static_cast<long long>(getpid())
	    << ".sus2";
	return oss.str();
}

bool RegularFileExists(const std::string& filename)
{
	struct stat st;
	if (stat(filename.c_str(), &st) != 0)
		return false;
	if (!S_ISREG(st.st_mode))
		ERROR("--inline-sh-model path exists but is not a regular file: " + filename);
	return true;
}

void BroadcastString(std::string& value);

bool PrepareInlineSphericalHarmonicModel(std::vector<std::string>& args,
										 std::map<std::string, std::string>& opts)
{
	const bool explicit_inline = opts.find("init-sh") != opts.end() && !opts["init-sh"].empty();
	const bool implicit_inline = args.size() == 1 && HasSphericalHarmonicInitOptions(opts);
	if (!explicit_inline && !implicit_inline)
		return false;
	if (args.size() != 1)
		ERROR("inline SUS2-SH training expects exactly one train_set.cfg argument");

	int world_rank = 0;
#ifdef MLIP_MPI
	MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
#endif
	std::string model_filename;
	if (world_rank == 0) {
		model_filename = InlineSHModelFilename(opts);
		if (RegularFileExists(model_filename)) {
			std::cout << "SUS2-SH inline model exists; continuing training from "
			          << model_filename << std::endl;
		} else {
			WriteSphericalHarmonicModel(model_filename, opts);
			std::cout << "SUS2-SH inline initial model written to "
			          << model_filename << std::endl;
		}
	}
	BroadcastString(model_filename);
#ifdef MLIP_MPI
	MPI_Barrier(MPI_COMM_WORLD);
#endif
	args.insert(args.begin(), model_filename);
	return true;
}

std::vector<size_t> BuildRescaleSubsetIndices(const std::vector<Configuration>& source
#ifdef MLIP_MPI
											   , MPI_Comm comm,
											   int comm_size
#endif
)
{
	constexpr size_t kRescaleCfgLimitPerRank = 5;

	if (source.empty())
		return {};

	long long global_cfg_count = static_cast<long long>(source.size());
#ifdef MLIP_MPI
	long long local_cfg_count = static_cast<long long>(source.size());
	MPI_Allreduce(&local_cfg_count, &global_cfg_count, 1, MPI_LONG_LONG_INT, MPI_SUM, comm);
	const int active_size = std::max(comm_size, 1);
#else
	const int active_size = 1;
#endif
	if (global_cfg_count <= static_cast<long long>(kRescaleCfgLimitPerRank) * active_size)
		return {};

	std::vector<size_t> order(source.size());
	std::iota(order.begin(), order.end(), 0);
	std::stable_sort(order.begin(), order.end(),
					 [&](size_t lhs, size_t rhs) {
						 if (source[lhs].size() != source[rhs].size())
							 return source[lhs].size() < source[rhs].size();
						 return lhs < rhs;
					 });

	std::vector<size_t> picks;
	picks.reserve(std::min(source.size(), kRescaleCfgLimitPerRank));
	auto push_unique = [&picks](size_t idx) {
		if (std::find(picks.begin(), picks.end(), idx) == picks.end())
			picks.push_back(idx);
	};

	const size_t n = order.size();
	push_unique(order[n - 1]);          // max
	if (n >= 2) push_unique(order[n - 2]); // second max
	push_unique(order[n / 2]);          // median
	if (n >= 2) push_unique(order[1]);  // second min
	push_unique(order[0]);              // min

	return picks;
}

std::vector<Configuration> GatherConfigurationsByIndex(const std::vector<Configuration>& source,
														 const std::vector<size_t>& indices)
{
	std::vector<Configuration> subset;
	subset.reserve(indices.size());
	for (size_t idx : indices)
		subset.push_back(source[idx]);
	return subset;
}

std::vector<Neighborhoods> GatherNeighborhoodsByIndex(const std::vector<Neighborhoods>& source,
														const std::vector<size_t>& indices)
{
	std::vector<Neighborhoods> subset;
	subset.reserve(indices.size());
	for (size_t idx : indices)
		subset.push_back(source[idx]);
	return subset;
}

void BroadcastString(std::string& value)
{
#ifdef MLIP_MPI
	int rank = 0;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	int length = static_cast<int>(value.size());
	MPI_Bcast(&length, 1, MPI_INT, 0, MPI_COMM_WORLD);
	if (rank != 0)
		value.resize(length);
	if (length > 0)
		MPI_Bcast(&value[0], length, MPI_CHAR, 0, MPI_COMM_WORLD);
#else
	(void)value;
#endif
}

DatasetStats LoadConfigsViaRank0Shards(const std::string& cfgfnm,
									   int proc_rank,
									   int proc_size,
									   std::vector<Configuration>& target,
									   const std::string& label)
{
	if (proc_size <= 1)
		return LoadConfigsFromFile(cfgfnm, target);

	DatasetStats stats;
	std::string shard_dir;

	if (proc_rank == 0) {
		shard_dir = MakeShardDir(cfgfnm, label);
		if (mkdir(shard_dir.c_str(), 0777) != 0)
			ERROR("Unable to create shard directory " + shard_dir);

		std::vector<Configuration> all_cfgs;
		{
			Configuration cfg;
			std::ifstream ifs(cfgfnm, std::ios::binary);
			for (; cfg.Load(ifs); )
				all_cfgs.push_back(cfg);
		}
		std::vector<size_t> order(all_cfgs.size());
		std::iota(order.begin(), order.end(), 0);
		std::stable_sort(order.begin(), order.end(),
						 [&](size_t lhs, size_t rhs) {
							 return EstimateConfigWork(all_cfgs[lhs]) > EstimateConfigWork(all_cfgs[rhs]);
						 });

		std::vector<std::ofstream> shard_streams(proc_size);
		std::vector<long long> shard_cfg_counts(proc_size, 0);
		std::vector<long long> shard_atom_counts(proc_size, 0);
		std::vector<long long> shard_costs(proc_size, 0);
		for (int rank = 0; rank < proc_size; rank++) {
			const std::string shard_path = shard_dir + "/rank_" + std::to_string(rank) + ".bin";
			shard_streams[rank].open(shard_path, std::ios::binary | std::ios::trunc);
			if (!shard_streams[rank].is_open())
				ERROR("Unable to open shard file " + shard_path);
		}

		for (size_t idx : order) {
			const Configuration& cfg = all_cfgs[idx];
			const int owner = static_cast<int>(
				std::min_element(shard_costs.begin(), shard_costs.end()) - shard_costs.begin());
			cfg.SaveBin(shard_streams[owner]);
			shard_cfg_counts[owner] += 1;
			shard_atom_counts[owner] += cfg.size();
			shard_costs[owner] += EstimateConfigWork(cfg);
		}
		for (std::ofstream& ofs : shard_streams)
			ofs.close();
		std::vector<Configuration>().swap(all_cfgs);
		LogShardBalance(label, shard_cfg_counts, shard_atom_counts, shard_costs);
	}

	BroadcastString(shard_dir);

	const std::string local_shard = shard_dir + "/rank_" + std::to_string(proc_rank) + ".bin";
	stats = LoadConfigsFromFile(local_shard, target);

#ifdef MLIP_MPI
	MPI_Barrier(MPI_COMM_WORLD);
#endif

	if (proc_rank == 0) {
		for (int rank = 0; rank < proc_size; rank++) {
			const std::string shard_path = shard_dir + "/rank_" + std::to_string(rank) + ".bin";
			std::remove(shard_path.c_str());
		}
		rmdir(shard_dir.c_str());
	}

#ifdef MLIP_MPI
	MPI_Barrier(MPI_COMM_WORLD);
#endif

	return stats;
}

struct GuardCompressionOptions {
	std::string anchor = "off";
	std::vector<double> scales = {0.95, 0.90, 0.85, 0.80};
	double floor_weight = 1.0;
	double monotonic_weight = 1.0;
	double curvature_weight = 1.0;
	double block_monotonic_weight = 0.1;
	double floor_margin = 0.0;
	double monotonic_margin = 0.2;
	double curvature_margin = 0.0;
	double smooth = 0.02;
	bool enabled = false;
};

struct GuardCompressionBuildResult {
	std::vector<NonLinearRegression::GuardCompressionSample> samples;
	std::vector<NonLinearRegression::GuardCompressionAnchorPair> anchor_pairs;
	std::vector<NonLinearRegression::GuardCompressionPair> pairs;
	std::vector<NonLinearRegression::GuardCompressionAnchorTriplet> anchor_triplets;
	std::vector<NonLinearRegression::GuardCompressionTriplet> triplets;
	std::vector<Neighborhoods> neighborhoods;
	long long global_sample_count = 0;
	long long global_pair_count = 0;
	long long global_triplet_count = 0;
	long long global_group_count = 0;
};

struct GuardAnchorCandidate {
	Configuration cfg;
	double energy_per_atom = 0.0;
	double volume_per_atom = 0.0;
	bool valid = false;
};

struct GuardCompositionAnchors {
	GuardAnchorCandidate highest_energy;
	GuardAnchorCandidate highest_density;
};

std::string FormatGuardDouble(double value)
{
	std::ostringstream oss;
	oss << std::setprecision(17) << value;
	return oss.str();
}

GuardCompressionOptions ParseGuardCompressionOptions(
	const std::map<std::string, std::string>& opts)
{
	GuardCompressionOptions options;
	auto get_opt = [&](const std::string& key) -> std::string {
		std::map<std::string, std::string>::const_iterator it = opts.find(key);
		return it == opts.end() ? std::string() : it->second;
	};

	if (!get_opt("guard-compression-anchor").empty())
		options.anchor = get_opt("guard-compression-anchor");
	if (!get_opt("guard-compression").empty())
		options.anchor = get_opt("guard-compression");
	if (options.anchor == "true")
		options.anchor = "highest-density";
	if (options.anchor == "false")
		options.anchor = "off";
	if (options.anchor != "off"
	    && options.anchor != "highest-density"
	    && options.anchor != "highest-energy"
	    && options.anchor != "both"
	    && options.anchor != "auto")
		ERROR("--guard-compression-anchor should be off, highest-density, highest-energy, both, or auto");
	options.enabled = options.anchor != "off";

	if (!get_opt("guard-compression-scales").empty())
		options.scales = ParseDoubleListOption(get_opt("guard-compression-scales"),
		                                       "--guard-compression-scales");
	for (double scale : options.scales) {
		if (!std::isfinite(scale) || scale <= 0.0 || scale >= 1.0)
			ERROR("--guard-compression-scales values should be finite and between 0 and 1");
	}
	std::sort(options.scales.begin(), options.scales.end(), std::greater<double>());
	options.scales.erase(std::unique(options.scales.begin(), options.scales.end()),
	                     options.scales.end());
	if (options.enabled && options.scales.empty())
		ERROR("--guard-compression-scales should contain at least one scale when guard compression is enabled");

	if (!get_opt("guard-compression-floor-weight").empty())
		options.floor_weight = ParseStrictDoubleOption(get_opt("guard-compression-floor-weight"),
		                                               "--guard-compression-floor-weight");
	if (!get_opt("guard-compression-monotonic-weight").empty())
		options.monotonic_weight = ParseStrictDoubleOption(get_opt("guard-compression-monotonic-weight"),
		                                                   "--guard-compression-monotonic-weight");
	if (!get_opt("guard-compression-curvature-weight").empty())
		options.curvature_weight = ParseStrictDoubleOption(get_opt("guard-compression-curvature-weight"),
		                                                   "--guard-compression-curvature-weight");
	if (!get_opt("guard-compression-block-monotonic-weight").empty())
		options.block_monotonic_weight = ParseStrictDoubleOption(get_opt("guard-compression-block-monotonic-weight"),
		                                                         "--guard-compression-block-monotonic-weight");
	if (!get_opt("guard-compression-floor-margin").empty())
		options.floor_margin = ParseStrictDoubleOption(get_opt("guard-compression-floor-margin"),
		                                               "--guard-compression-floor-margin");
	if (!get_opt("guard-compression-monotonic-margin").empty())
		options.monotonic_margin = ParseStrictDoubleOption(get_opt("guard-compression-monotonic-margin"),
		                                                   "--guard-compression-monotonic-margin");
	if (!get_opt("guard-compression-curvature-margin").empty())
		options.curvature_margin = ParseStrictDoubleOption(get_opt("guard-compression-curvature-margin"),
		                                                   "--guard-compression-curvature-margin");
	if (!get_opt("guard-compression-smooth").empty())
		options.smooth = ParseStrictDoubleOption(get_opt("guard-compression-smooth"),
		                                         "--guard-compression-smooth");
	if (!std::isfinite(options.floor_weight) || options.floor_weight < 0.0)
		ERROR("--guard-compression-floor-weight should be finite and non-negative");
	if (!std::isfinite(options.monotonic_weight) || options.monotonic_weight < 0.0)
		ERROR("--guard-compression-monotonic-weight should be finite and non-negative");
	if (!std::isfinite(options.curvature_weight) || options.curvature_weight < 0.0)
		ERROR("--guard-compression-curvature-weight should be finite and non-negative");
	if (!std::isfinite(options.block_monotonic_weight) || options.block_monotonic_weight < 0.0)
		ERROR("--guard-compression-block-monotonic-weight should be finite and non-negative");
	if (!std::isfinite(options.floor_margin))
		ERROR("--guard-compression-floor-margin should be finite");
	if (!std::isfinite(options.monotonic_margin))
		ERROR("--guard-compression-monotonic-margin should be finite");
	if (!std::isfinite(options.curvature_margin))
		ERROR("--guard-compression-curvature-margin should be finite");
	if (!std::isfinite(options.smooth) || options.smooth < 0.0)
		ERROR("--guard-compression-smooth should be finite and non-negative");
	const bool has_active_loss =
		options.floor_weight > 0.0
		|| options.monotonic_weight > 0.0
		|| options.curvature_weight > 0.0
		|| options.block_monotonic_weight > 0.0;
	if (options.enabled && !has_active_loss)
		options.enabled = false;
	return options;
}

std::string CompositionKey(const Configuration& cfg)
{
	std::map<int, int> counts;
	for (int type : cfg.types_)
		counts[type]++;
	int divisor = 0;
	for (const auto& kv : counts) {
		int value = kv.second < 0 ? -kv.second : kv.second;
		while (value != 0) {
			const int tmp = divisor % value;
			divisor = value;
			value = tmp;
		}
	}
	if (divisor <= 0)
		divisor = 1;
	std::ostringstream oss;
	bool first = true;
	for (const auto& kv : counts) {
		if (!first)
			oss << ';';
		first = false;
		oss << kv.first << ':' << (kv.second / divisor);
	}
	return oss.str();
}

bool PeriodicVolumePerAtom(const Configuration& cfg, double& volume_per_atom)
{
	if (cfg.size() == 0)
		return false;
	const double volume = std::abs(cfg.lattice.det());
	if (!std::isfinite(volume) || volume <= 1.0e-12)
		return false;
	volume_per_atom = volume / cfg.size();
	return true;
}

Configuration UniformlyScaledConfiguration(const Configuration& anchor, double scale)
{
	Configuration cfg = anchor;
	cfg.lattice *= scale;
	for (int i = 0; i < cfg.size(); ++i)
		cfg.pos(i) *= scale;
	cfg.has_energy(false);
	cfg.has_forces(false);
	cfg.has_stresses(false);
	cfg.has_site_energies(false);
	cfg.has_charges(false);
	cfg.cal_se.clear();
	cfg.cal_se0.clear();
	cfg.type_mean.clear();
	cfg.features.clear();
	return cfg;
}

double GuardCompressionCoordinate(double scale)
{
	if (!std::isfinite(scale) || scale <= 0.0)
		ERROR("guard-compression scale should be finite and positive");
	return -3.0 * std::log(scale);
}

void StoreGuardFeatures(Configuration& cfg,
                        int group_index,
                        double scale,
                        double floor_energy_per_atom,
                        const std::string& anchor_kind,
                        const std::string& composition_key,
                        bool is_anchor = false)
{
	cfg.features["guard_compression_group"] = std::to_string(group_index);
	cfg.features["guard_compression_scale"] = FormatGuardDouble(scale);
	cfg.features["guard_compression_floor_energy_per_atom"] =
		FormatGuardDouble(floor_energy_per_atom);
	cfg.features["guard_compression_anchor"] = anchor_kind;
	cfg.features["guard_compression_composition"] = composition_key;
	cfg.features["guard_compression_is_anchor"] = is_anchor ? "1" : "0";
}

NonLinearRegression::GuardCompressionSample GuardSampleFromConfig(Configuration cfg)
{
	NonLinearRegression::GuardCompressionSample sample;
	const auto floor_it = cfg.features.find("guard_compression_floor_energy_per_atom");
	const auto group_it = cfg.features.find("guard_compression_group");
	const auto scale_it = cfg.features.find("guard_compression_scale");
	if (floor_it == cfg.features.end()
	    || group_it == cfg.features.end()
	    || scale_it == cfg.features.end())
		ERROR("guard-compression sample is missing cached metadata");
	sample.floor_energy_per_atom = ParseStrictDoubleOption(
		floor_it->second, "guard_compression_floor_energy_per_atom");
	sample.group_index = std::stoi(group_it->second);
	sample.scale = ParseStrictDoubleOption(scale_it->second,
	                                       "guard_compression_scale");
	const auto anchor_flag_it = cfg.features.find("guard_compression_is_anchor");
	sample.is_anchor = anchor_flag_it != cfg.features.end()
		&& (anchor_flag_it->second == "1"
		    || anchor_flag_it->second == "true"
		    || anchor_flag_it->second == "True");
	cfg.has_energy(false);
	cfg.has_forces(false);
	cfg.has_stresses(false);
	cfg.has_site_energies(false);
	cfg.has_charges(false);
	sample.cfg = std::move(cfg);
	return sample;
}

void LoadGuardSamplesFromFile(
	const std::string& filename,
	std::vector<NonLinearRegression::GuardCompressionSample>& samples,
	std::vector<NonLinearRegression::GuardCompressionAnchorPair>& anchor_pairs,
	std::vector<NonLinearRegression::GuardCompressionPair>& pairs,
	std::vector<NonLinearRegression::GuardCompressionAnchorTriplet>& anchor_triplets,
	std::vector<NonLinearRegression::GuardCompressionTriplet>& triplets)
{
	samples.clear();
	anchor_pairs.clear();
	pairs.clear();
	anchor_triplets.clear();
	triplets.clear();
	std::map<int, int> anchor_by_group;
	std::map<int, int> previous_fake_by_group;
	std::map<int, int> second_previous_fake_by_group;
	Configuration cfg;
	std::ifstream ifs(filename, std::ios::binary);
	for (; cfg.Load(ifs); ) {
		NonLinearRegression::GuardCompressionSample sample =
			GuardSampleFromConfig(cfg);
		const int current_index = static_cast<int>(samples.size());
		if (sample.is_anchor) {
			anchor_by_group[sample.group_index] = current_index;
			samples.push_back(std::move(sample));
			continue;
		}
		std::map<int, int>::iterator prev_it =
			previous_fake_by_group.find(sample.group_index);
		if (prev_it == previous_fake_by_group.end()) {
			NonLinearRegression::GuardCompressionAnchorPair pair;
			const std::map<int, int>::iterator anchor_it =
				anchor_by_group.find(sample.group_index);
			if (anchor_it != anchor_by_group.end())
				pair.anchor = anchor_it->second;
			pair.more_compressed = current_index;
			anchor_pairs.push_back(pair);
		}
		if (prev_it != previous_fake_by_group.end()) {
			NonLinearRegression::GuardCompressionPair pair;
			pair.less_compressed = prev_it->second;
			pair.more_compressed = current_index;
			pairs.push_back(pair);
		}
		std::map<int, int>::iterator second_prev_it =
			second_previous_fake_by_group.find(sample.group_index);
		if (prev_it != previous_fake_by_group.end()
		    && second_prev_it == second_previous_fake_by_group.end()) {
			NonLinearRegression::GuardCompressionAnchorTriplet triplet;
			triplet.first_compressed = prev_it->second;
			triplet.second_compressed = current_index;
			anchor_triplets.push_back(triplet);
		}
		if (second_prev_it != second_previous_fake_by_group.end()
		    && prev_it != previous_fake_by_group.end()) {
			NonLinearRegression::GuardCompressionTriplet triplet;
			triplet.less_compressed = second_prev_it->second;
			triplet.middle_compressed = prev_it->second;
			triplet.more_compressed = current_index;
			triplets.push_back(triplet);
		}
		if (prev_it != previous_fake_by_group.end())
			second_previous_fake_by_group[sample.group_index] = prev_it->second;
		previous_fake_by_group[sample.group_index] = current_index;
		samples.push_back(std::move(sample));
	}
}

void ApplyZBLResidualToGuardSamples(
	std::vector<NonLinearRegression::GuardCompressionSample>& samples,
	const ZBLPotential& zbl,
	const std::vector<Neighborhoods>* neighborhoods)
{
	if (neighborhoods != nullptr && neighborhoods->size() != samples.size())
		ERROR("guard-compression ZBL neighborhood cache size mismatch");
	for (std::size_t i = 0; i < samples.size(); ++i) {
		if (samples[i].cfg.size() == 0)
			continue;
		const ZBLEFS zbl_efs = neighborhoods == nullptr
			? zbl.Compute(samples[i].cfg)
			: zbl.Compute(samples[i].cfg, (*neighborhoods)[i]);
		samples[i].floor_energy_per_atom -=
			zbl_efs.energy / samples[i].cfg.size();
	}
}

std::vector<Configuration> GuardSampleConfigurations(
	const std::vector<NonLinearRegression::GuardCompressionSample>& samples)
{
	std::vector<Configuration> configs;
	configs.reserve(samples.size());
	for (const auto& sample : samples)
		configs.push_back(sample.cfg);
	return configs;
}

GuardCompressionBuildResult BuildGuardCompressionSamplesFromFile(
	const std::string& cfgfnm,
	const GuardCompressionOptions& options,
	int proc_rank,
	int proc_size,
	double cutoff)
{
	GuardCompressionBuildResult result;
	if (!options.enabled)
		return result;

	std::string shard_dir;
	if (proc_rank == 0) {
		shard_dir = MakeShardDir(cfgfnm, "guard");
		if (mkdir(shard_dir.c_str(), 0777) != 0)
			ERROR("Unable to create guard shard directory " + shard_dir);

		std::map<std::string, GuardCompositionAnchors> anchors;
		Configuration cfg;
		std::ifstream ifs(cfgfnm, std::ios::binary);
		for (; cfg.Load(ifs); ) {
			if (cfg.size() == 0 || !cfg.has_energy())
				continue;
			const std::string key = CompositionKey(cfg);
			GuardCompositionAnchors& entry = anchors[key];
			const double epa = cfg.energy / cfg.size();
			if (!entry.highest_energy.valid
			    || epa > entry.highest_energy.energy_per_atom) {
				entry.highest_energy.cfg = cfg;
				entry.highest_energy.energy_per_atom = epa;
				entry.highest_energy.valid = true;
			}
			double vpa = 0.0;
			if (PeriodicVolumePerAtom(cfg, vpa)
			    && (!entry.highest_density.valid
			        || vpa < entry.highest_density.volume_per_atom)) {
				entry.highest_density.cfg = cfg;
				entry.highest_density.energy_per_atom = epa;
				entry.highest_density.volume_per_atom = vpa;
				entry.highest_density.valid = true;
			}
		}

		std::vector<std::ofstream> shard_streams(proc_size);
		std::vector<long long> shard_cfg_counts(proc_size, 0);
		std::vector<long long> shard_atom_counts(proc_size, 0);
		std::vector<long long> shard_costs(proc_size, 0);
		for (int rank = 0; rank < proc_size; rank++) {
			const std::string shard_path = shard_dir + "/rank_" + std::to_string(rank) + ".bin";
			shard_streams[rank].open(shard_path, std::ios::binary | std::ios::trunc);
			if (!shard_streams[rank].is_open())
				ERROR("Unable to open guard shard file " + shard_path);
		}

		int group_index = 0;
		auto write_group = [&](const std::string& key,
		                       const GuardAnchorCandidate& candidate,
		                       const std::string& anchor_kind) {
			if (!candidate.valid)
				return;
			const int owner = static_cast<int>(
				std::min_element(shard_costs.begin(), shard_costs.end()) - shard_costs.begin());
			long long group_atoms = 0;
			if (options.block_monotonic_weight > 0.0) {
				Configuration anchor_cfg = candidate.cfg;
				StoreGuardFeatures(anchor_cfg,
				                   group_index,
				                   1.0,
				                   candidate.energy_per_atom,
				                   anchor_kind,
				                   key,
				                   true);
				anchor_cfg.SaveBin(shard_streams[owner]);
				shard_cfg_counts[owner] += 1;
				shard_atom_counts[owner] += anchor_cfg.size();
				group_atoms += anchor_cfg.size();
			}
			for (double scale : options.scales) {
				Configuration fake = UniformlyScaledConfiguration(candidate.cfg, scale);
				StoreGuardFeatures(fake,
				                   group_index,
				                   scale,
				                   candidate.energy_per_atom,
				                   anchor_kind,
				                   key,
				                   false);
				fake.SaveBin(shard_streams[owner]);
				shard_cfg_counts[owner] += 1;
				shard_atom_counts[owner] += fake.size();
				group_atoms += fake.size();
				result.global_sample_count += 1;
			}
			result.global_pair_count +=
				static_cast<long long>(options.scales.size());
			if (options.scales.size() >= 2)
				result.global_triplet_count +=
					static_cast<long long>(options.scales.size() - 1);
			result.global_group_count += 1;
			shard_costs[owner] += std::max<long long>(1, group_atoms);
			group_index++;
		};

		for (const auto& kv : anchors) {
			const GuardCompositionAnchors& entry = kv.second;
			if (options.anchor == "highest-density") {
				write_group(kv.first, entry.highest_density, "highest-density");
			} else if (options.anchor == "highest-energy") {
				write_group(kv.first, entry.highest_energy, "highest-energy");
			} else if (options.anchor == "auto") {
				if (entry.highest_density.valid)
					write_group(kv.first, entry.highest_density, "highest-density");
				else
					write_group(kv.first, entry.highest_energy, "highest-energy");
			} else if (options.anchor == "both") {
				write_group(kv.first, entry.highest_density, "highest-density");
				if (!entry.highest_density.valid
				    || !entry.highest_energy.valid
				    || entry.highest_energy.cfg.id() != entry.highest_density.cfg.id())
					write_group(kv.first, entry.highest_energy, "highest-energy");
			}
		}
		for (std::ofstream& ofs : shard_streams)
			ofs.close();
		LogShardBalance("guard-compression", shard_cfg_counts, shard_atom_counts, shard_costs);
	}

	BroadcastString(shard_dir);
#ifdef MLIP_MPI
	MPI_Bcast(&result.global_sample_count, 1, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(&result.global_pair_count, 1, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(&result.global_triplet_count, 1, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);
	MPI_Bcast(&result.global_group_count, 1, MPI_LONG_LONG_INT, 0, MPI_COMM_WORLD);
#endif

	const std::string local_shard = shard_dir + "/rank_" + std::to_string(proc_rank) + ".bin";
	LoadGuardSamplesFromFile(local_shard,
	                         result.samples,
	                         result.anchor_pairs,
	                         result.pairs,
	                         result.anchor_triplets,
	                         result.triplets);

#ifdef MLIP_MPI
	MPI_Barrier(MPI_COMM_WORLD);
#endif

	if (proc_rank == 0) {
		for (int rank = 0; rank < proc_size; rank++) {
			const std::string shard_path = shard_dir + "/rank_" + std::to_string(rank) + ".bin";
			std::remove(shard_path.c_str());
		}
		rmdir(shard_dir.c_str());
	}

#ifdef MLIP_MPI
	MPI_Barrier(MPI_COMM_WORLD);
#endif

	std::vector<Configuration> guard_cfgs = GuardSampleConfigurations(result.samples);
	if (!guard_cfgs.empty()) {
		std::size_t estimated_guard_cache_bytes = 0;
		const bool cache_guard_neighborhoods =
			ShouldCacheNeighborhoods(guard_cfgs, cutoff, &estimated_guard_cache_bytes);
		if (cache_guard_neighborhoods) {
			if (prank == 0)
				std::cout << "[" << CurrentTimestamp() << "] Building guard-compression neighborhoods..."
				          << " local_samples=" << result.samples.size()
				          << " estimated_bytes=" << estimated_guard_cache_bytes
				          << std::endl;
			const bool built_ok = TryBuildNeighborhoods(guard_cfgs, cutoff, result.neighborhoods);
			if (!built_ok && prank == 0)
				std::cout << "[" << CurrentTimestamp() << "] Guard-compression neighborhood cache fallback"
				          << " reason=bad_alloc" << std::endl;
		}
	}
	return result;
}

void ReportGuardCompressionStatus(
	MLMTPR& mtpr,
	const std::vector<NonLinearRegression::GuardCompressionSample>& samples,
	const std::vector<Neighborhoods>& neighborhoods,
	const std::vector<NonLinearRegression::GuardCompressionAnchorPair>& anchor_pairs,
	const std::vector<NonLinearRegression::GuardCompressionPair>& pairs,
	const std::vector<NonLinearRegression::GuardCompressionAnchorTriplet>& anchor_triplets,
	const std::vector<NonLinearRegression::GuardCompressionTriplet>& triplets,
	const GuardCompressionOptions& options,
	const std::string& label,
	int proc_rank)
{
	if (!options.enabled)
		return;
	const bool need_floor = options.floor_weight > 0.0;
	const bool need_monotonic = options.monotonic_weight > 0.0;
	const bool need_curvature = options.curvature_weight > 0.0;
	if (!need_floor && !need_monotonic && !need_curvature)
		return;
	std::vector<double> epa(samples.size(), 0.0);
	double local_worst_floor = 0.0;
	double local_worst_mono = 0.0;
	double local_worst_curv = 0.0;
	long long local_floor_active = 0;
	long long local_mono_active = 0;
	long long local_curv_active = 0;
	for (std::size_t i = 0; i < samples.size(); ++i) {
		Configuration cfg = samples[i].cfg;
		if (neighborhoods.empty())
			mtpr.CalcEnergyAndSiteEnergies(cfg);
		else
			mtpr.CalcEnergyAndSiteEnergies(cfg, neighborhoods[i]);
		if (cfg.size() == 0)
			continue;
		epa[i] = cfg.energy / cfg.size();
		if (!need_floor || samples[i].is_anchor)
			continue;
		const double violation = samples[i].floor_energy_per_atom
			+ options.floor_margin - epa[i];
		if (violation > 0.0) {
			local_floor_active++;
			local_worst_floor = std::max(local_worst_floor, violation);
		}
	}
	if (need_monotonic) {
		for (const auto& pair : anchor_pairs) {
			const double violation = samples[pair.more_compressed].floor_energy_per_atom
				+ options.monotonic_margin - epa[pair.more_compressed];
			if (violation > 0.0) {
				local_mono_active++;
				local_worst_mono = std::max(local_worst_mono, violation);
			}
		}
		for (const auto& pair : pairs) {
			const double violation = epa[pair.less_compressed]
				+ options.monotonic_margin - epa[pair.more_compressed];
			if (violation > 0.0) {
				local_mono_active++;
				local_worst_mono = std::max(local_worst_mono, violation);
			}
		}
	}
	if (need_curvature) {
		for (const auto& triplet : anchor_triplets) {
			const double x_anchor = 0.0;
			const double x_first = GuardCompressionCoordinate(
				samples[triplet.first_compressed].scale);
			const double x_second = GuardCompressionCoordinate(
				samples[triplet.second_compressed].scale);
			const double dx_left = x_first - x_anchor;
			const double dx_right = x_second - x_first;
			if (!(dx_left > 0.0 && dx_right > 0.0))
				ERROR("guard-compression anchor-curvature triplet has non-increasing compression coordinate");
			const double slope_left =
				(epa[triplet.first_compressed]
				 - samples[triplet.first_compressed].floor_energy_per_atom) / dx_left;
			const double slope_right =
				(epa[triplet.second_compressed] - epa[triplet.first_compressed]) / dx_right;
			const double violation =
				slope_left + options.curvature_margin - slope_right;
			if (violation > 0.0) {
				local_curv_active++;
				local_worst_curv = std::max(local_worst_curv, violation);
			}
		}
		for (const auto& triplet : triplets) {
			const double x_less = GuardCompressionCoordinate(
				samples[triplet.less_compressed].scale);
			const double x_middle = GuardCompressionCoordinate(
				samples[triplet.middle_compressed].scale);
			const double x_more = GuardCompressionCoordinate(
				samples[triplet.more_compressed].scale);
			const double dx_left = x_middle - x_less;
			const double dx_right = x_more - x_middle;
			if (!(dx_left > 0.0 && dx_right > 0.0))
				ERROR("guard-compression curvature triplet has non-increasing compression coordinate");
			const double slope_left =
				(epa[triplet.middle_compressed] - epa[triplet.less_compressed]) / dx_left;
			const double slope_right =
				(epa[triplet.more_compressed] - epa[triplet.middle_compressed]) / dx_right;
			const double violation =
				slope_left + options.curvature_margin - slope_right;
			if (violation > 0.0) {
				local_curv_active++;
				local_worst_curv = std::max(local_worst_curv, violation);
			}
		}
	}

	double global_worst_floor = local_worst_floor;
	double global_worst_mono = local_worst_mono;
	double global_worst_curv = local_worst_curv;
	long long global_floor_active = local_floor_active;
	long long global_mono_active = local_mono_active;
	long long global_curv_active = local_curv_active;
	long long local_samples = 0;
	for (const auto& sample : samples)
		if (!sample.is_anchor)
			local_samples++;
	long long local_pairs =
		static_cast<long long>(anchor_pairs.size() + pairs.size());
	long long local_triplets =
		static_cast<long long>(anchor_triplets.size() + triplets.size());
	long long global_samples = local_samples;
	long long global_pairs = local_pairs;
	long long global_triplets = local_triplets;
#ifdef MLIP_MPI
	MPI_Reduce(&local_worst_floor, &global_worst_floor, 1, MPI_DOUBLE,
	           MPI_MAX, 0, MPI_COMM_WORLD);
	MPI_Reduce(&local_worst_mono, &global_worst_mono, 1, MPI_DOUBLE,
	           MPI_MAX, 0, MPI_COMM_WORLD);
	MPI_Reduce(&local_worst_curv, &global_worst_curv, 1, MPI_DOUBLE,
	           MPI_MAX, 0, MPI_COMM_WORLD);
	MPI_Reduce(&local_floor_active, &global_floor_active, 1, MPI_LONG_LONG_INT,
	           MPI_SUM, 0, MPI_COMM_WORLD);
	MPI_Reduce(&local_mono_active, &global_mono_active, 1, MPI_LONG_LONG_INT,
	           MPI_SUM, 0, MPI_COMM_WORLD);
	MPI_Reduce(&local_curv_active, &global_curv_active, 1, MPI_LONG_LONG_INT,
	           MPI_SUM, 0, MPI_COMM_WORLD);
	MPI_Reduce(&local_samples, &global_samples, 1, MPI_LONG_LONG_INT,
	           MPI_SUM, 0, MPI_COMM_WORLD);
	MPI_Reduce(&local_pairs, &global_pairs, 1, MPI_LONG_LONG_INT,
	           MPI_SUM, 0, MPI_COMM_WORLD);
	MPI_Reduce(&local_triplets, &global_triplets, 1, MPI_LONG_LONG_INT,
	           MPI_SUM, 0, MPI_COMM_WORLD);
#endif
	if (proc_rank == 0) {
		std::cout << "[" << CurrentTimestamp() << "] guard-compression report"
		          << " stage=" << label
		          << " samples=" << global_samples
		          << " pairs=" << global_pairs
		          << " triplets=" << global_triplets
		          << " floor_active=" << global_floor_active
		          << " worst_floor_violation_eV_atom=" << global_worst_floor
		          << " monotonic_active=" << global_mono_active
		          << " worst_monotonic_violation_eV_atom=" << global_worst_mono
		          << " curvature_active=" << global_curv_active
		          << " worst_curvature_violation_eV_atom=" << global_worst_curv
		          << std::endl;
	}
}

} // namespace

DatasetStats AddConfigs(const string cfgfnm, NonLinearRegression& dtr, int proc_rank, int proc_size)
{
	(void)dtr;

#ifdef MLIP_MPI
	MPI_Barrier(MPI_COMM_WORLD);
#endif

	return LoadConfigsViaRank0Shards(cfgfnm, proc_rank, proc_size, training_set, "train");
}

void Rescale(MTPR_trainer& trainer, MLMTPR& mtpr, const std::vector<Neighborhoods>* training_neighborhoods)
{
#ifdef MLIP_MPI
	if (!trainer.TrainRankActive())
		return;
	const int train_rank = trainer.TrainRank();
	const int train_size = trainer.TrainSize();
	MPI_Comm train_comm = trainer.TrainComm();
#else
	const int train_rank = prank;
	const int train_size = 1;
#endif
	const std::vector<size_t> rescale_subset_indices = BuildRescaleSubsetIndices(training_set
#ifdef MLIP_MPI
		, train_comm, train_size
#endif
	);
	std::vector<Configuration> rescale_subset =
		GatherConfigurationsByIndex(training_set, rescale_subset_indices);
	std::vector<Neighborhoods> rescale_subset_neighborhoods;
	const std::vector<Neighborhoods>* full_neighborhoods_ptr = training_neighborhoods;
	if (!rescale_subset.empty()) {
		if (full_neighborhoods_ptr != nullptr && !full_neighborhoods_ptr->empty())
			rescale_subset_neighborhoods = GatherNeighborhoodsByIndex(*full_neighborhoods_ptr, rescale_subset_indices);
		else
			rescale_subset_neighborhoods = BuildNeighborhoods(rescale_subset, mtpr.CutOff());
	}
	std::vector<Configuration>* rescale_training_set = &training_set;
	const std::vector<Neighborhoods>* rescale_training_neighborhoods = full_neighborhoods_ptr;
	if (!rescale_subset.empty())
	{
		rescale_training_set = &rescale_subset;
		rescale_training_neighborhoods = &rescale_subset_neighborhoods;
	}
	const long long rescale_atoms_local = SumAtoms(*rescale_training_set);
	const long long full_atoms_local = SumAtoms(training_set);
	long long rescale_atoms_total = rescale_atoms_local;
	long long full_atoms_total = full_atoms_local;
	long long rescale_cfg_total = static_cast<long long>(rescale_training_set->size());
	long long full_cfg_total = static_cast<long long>(training_set.size());
#ifdef MLIP_MPI
	MPI_Allreduce(&rescale_atoms_local, &rescale_atoms_total, 1, MPI_LONG_LONG_INT, MPI_SUM, train_comm);
	MPI_Allreduce(&full_atoms_local, &full_atoms_total, 1, MPI_LONG_LONG_INT, MPI_SUM, train_comm);
	long long rescale_cfg_local = static_cast<long long>(rescale_training_set->size());
	long long full_cfg_local = static_cast<long long>(training_set.size());
	MPI_Allreduce(&rescale_cfg_local, &rescale_cfg_total, 1, MPI_LONG_LONG_INT, MPI_SUM, train_comm);
	MPI_Allreduce(&full_cfg_local, &full_cfg_total, 1, MPI_LONG_LONG_INT, MPI_SUM, train_comm);
#endif

	constexpr int kCenterMaxIters = 6;
	constexpr int kBracketExpandMaxIters = 6;
	constexpr double kCenterTolLog = 0.15;
	constexpr double kScalingFloor = 1.0e-12;
	constexpr double kBracketFactor = 2.0;
	const double factors[5] = {1.0 / 1.08, 1.0 / 1.03, 1.0, 1.03, 1.08};

	if (train_rank == 0) {
		std::cout << "[" << CurrentTimestamp() << "] Rescaling..." << std::endl;
		if (rescale_atoms_total < full_atoms_total || rescale_cfg_total < full_cfg_total) {
			std::cout << "[" << CurrentTimestamp() << "] "
			          << "Rescale subset: "
			          << rescale_cfg_total << "/" << full_cfg_total << " structures, "
			          << rescale_atoms_total << "/" << full_atoms_total << " atoms"
		          << std::endl;
		}
	}

	auto evaluate_scaling = [&](double scaling_value, const std::string& context) {
		RescaleEvalResult result;
		result.scaling = scaling_value;
		result.coeffs.resize(mtpr.CoeffCount());
		mtpr.scaling = scaling_value;
		trainer.TrainLinear(prank,
						   *rescale_training_set,
						   rescale_training_neighborhoods,
						   context);
		std::memcpy(result.coeffs.data(), mtpr.Coeff(), mtpr.CoeffCount() * sizeof(double));
		mtpr.LinCoeff();
		result.stats = ComputeMomentCoeffStats(mtpr);
		result.valid = result.stats.valid;
		return result;
	};

	auto log_eval = [&](const std::string& prefix, const RescaleEvalResult& eval) {
		if (train_rank == 0)
			std::cout << "[" << CurrentTimestamp() << "] "
			          << prefix
			          << " scaling=" << eval.scaling
			          << " count=" << eval.stats.count
			          << " center_log=" << eval.stats.center_log
			          << " spread_log=" << eval.stats.spread_log
			          << " typical_scale=" << std::exp(eval.stats.center_log)
			          << std::endl;
	};

	RescaleEvalResult center_eval =
		evaluate_scaling(mtpr.scaling, "rescale center seed");
	if (!center_eval.valid) {
		if (train_rank == 0)
			std::cout << "[" << CurrentTimestamp() << "] "
			          << "Rescale aborted: no valid moment coefficients" << std::endl;
		return;
	}
	log_eval("Rescale center seed", center_eval);

	RescaleEvalResult best_center_eval = center_eval;
	RescaleEvalResult positive_eval;
	RescaleEvalResult negative_eval;
	bool have_positive = false;
	bool have_negative = false;
	auto consider_eval = [&](const RescaleEvalResult& eval) {
		if (!eval.valid)
			return;
		if (std::abs(eval.stats.center_log)
		    < std::abs(best_center_eval.stats.center_log))
			best_center_eval = eval;
		if (eval.stats.center_log >= 0.0) {
			if (!have_positive
			    || eval.stats.center_log < positive_eval.stats.center_log)
				positive_eval = eval;
			have_positive = true;
		} else {
			if (!have_negative
			    || eval.stats.center_log > negative_eval.stats.center_log)
				negative_eval = eval;
			have_negative = true;
		}
	};
	consider_eval(center_eval);

	if (std::abs(center_eval.stats.center_log) >= kCenterTolLog) {
		RescaleEvalResult lower_eval;
		const double lower_scaling =
			std::max(kScalingFloor, center_eval.scaling / kBracketFactor);
		if (lower_scaling < center_eval.scaling) {
			lower_eval = evaluate_scaling(
				lower_scaling, "rescale bracket lower probe");
			if (lower_eval.valid) {
				log_eval("Rescale bracket lower probe", lower_eval);
				consider_eval(lower_eval);
			}
		}

		RescaleEvalResult upper_eval;
		if (!(have_positive && have_negative)) {
			const double upper_scaling = center_eval.scaling * kBracketFactor;
			if (std::isfinite(upper_scaling)) {
				upper_eval = evaluate_scaling(
					upper_scaling, "rescale bracket upper probe");
				if (upper_eval.valid) {
					log_eval("Rescale bracket upper probe", upper_eval);
					consider_eval(upper_eval);
				}
			}
		}

		if (!(have_positive && have_negative)) {
			const int direction = SelectRescaleExpansionDirection(
				center_eval.stats.center_log,
				lower_eval.valid,
				lower_eval.valid ? lower_eval.stats.center_log : 0.0,
				upper_eval.valid,
				upper_eval.valid ? upper_eval.stats.center_log : 0.0);
			RescaleEvalResult bracket_eval =
				direction < 0 ? lower_eval : upper_eval;
			for (int iter = 0;
			     direction != 0
			     && iter < kBracketExpandMaxIters
			     && !(have_positive && have_negative);
			     ++iter) {
				const double trial_scaling = direction < 0
					? std::max(kScalingFloor, bracket_eval.scaling / kBracketFactor)
					: bracket_eval.scaling * kBracketFactor;
				if (!(trial_scaling > 0.0)
				    || !std::isfinite(trial_scaling)
				    || trial_scaling == bracket_eval.scaling)
					break;
				RescaleEvalResult trial_eval = evaluate_scaling(
					trial_scaling,
					"rescale bracket expand " + std::to_string(iter + 1)
						+ "/" + std::to_string(kBracketExpandMaxIters));
				if (!trial_eval.valid)
					break;
				log_eval("Rescale bracket expand", trial_eval);
				const double previous_error =
					std::abs(bracket_eval.stats.center_log);
				consider_eval(trial_eval);
				bracket_eval = trial_eval;
				if (!(have_positive && have_negative)
				    && std::abs(trial_eval.stats.center_log) >= previous_error)
					break;
			}
		}
	}

	if (have_positive && have_negative) {
		for (int iter = 0; iter < kCenterMaxIters; ++iter) {
			const double log_pos = std::log(positive_eval.scaling);
			const double log_neg = std::log(negative_eval.scaling);
			double log_trial = 0.5 * (log_pos + log_neg);
			const double center_pos = positive_eval.stats.center_log;
			const double center_neg = negative_eval.stats.center_log;
			if (std::abs(center_pos - center_neg) > 1.0e-12) {
				log_trial = (log_pos * center_neg - log_neg * center_pos) / (center_neg - center_pos);
				log_trial = std::max(std::min(log_trial, std::max(log_pos, log_neg)), std::min(log_pos, log_neg));
				const double span = std::abs(log_pos - log_neg);
				if (std::abs(log_trial - log_pos) < 0.1 * span || std::abs(log_trial - log_neg) < 0.1 * span)
					log_trial = 0.5 * (log_pos + log_neg);
			}
			const double trial_scaling = std::max(kScalingFloor, std::exp(log_trial));
			RescaleEvalResult trial_eval = evaluate_scaling(
				trial_scaling,
				"rescale center solve " + std::to_string(iter + 1) + "/" + std::to_string(kCenterMaxIters));
			if (!trial_eval.valid)
				break;
			log_eval("Rescale center solve", trial_eval);
			consider_eval(trial_eval);
			if (std::abs(trial_eval.stats.center_log) < kCenterTolLog) {
				best_center_eval = trial_eval;
				break;
			}
		}
	}

	mtpr.scaling = best_center_eval.scaling;
	std::memcpy(mtpr.Coeff(), best_center_eval.coeffs.data(), mtpr.CoeffCount() * sizeof(double));

	const double base_scaling = best_center_eval.scaling;
	double best_metric = std::numeric_limits<double>::infinity();
	double best_scaling = base_scaling;
	MomentCoeffStats best_stats = best_center_eval.stats;
	std::vector<double> best_coeffs(mtpr.CoeffCount());
	std::memcpy(best_coeffs.data(), best_center_eval.coeffs.data(), mtpr.CoeffCount() * sizeof(double));

	for (int j = 0; j < 5; ++j) {
		const double trial_scaling = std::max(kScalingFloor, base_scaling * factors[j]);
		RescaleEvalResult trial_eval = evaluate_scaling(
			trial_scaling,
			"rescale fine trial " + std::to_string(j + 1) + "/5");
		if (!trial_eval.valid)
			continue;
		const double metric = RescaleMetric(trial_eval.stats);
		if (train_rank == 0) {
			std::cout << "[" << CurrentTimestamp() << "] "
			          << "Rescale fine stats center_log=" << trial_eval.stats.center_log
			          << " spread_log=" << trial_eval.stats.spread_log
			          << " metric=" << metric
			          << std::endl;
		}
		if (metric < best_metric) {
			best_metric = metric;
			best_scaling = trial_scaling;
			best_stats = trial_eval.stats;
			std::memcpy(best_coeffs.data(), trial_eval.coeffs.data(), mtpr.CoeffCount() * sizeof(double));
		}
	}

	mtpr.scaling = best_scaling;
	if (best_metric < std::numeric_limits<double>::infinity())
		std::memcpy(mtpr.Coeff(), best_coeffs.data(), mtpr.CoeffCount() * sizeof(double));
#ifdef MLIP_MPI
	MPI_Bcast(mtpr.Coeff(), mtpr.CoeffCount(), MPI_DOUBLE, 0, train_comm);
#endif
	if (train_rank == 0) {
		std::cout << "[" << CurrentTimestamp() << "] "
		          << "Rescaling selected scaling=" << mtpr.scaling;
		if (best_stats.valid) {
			std::cout << " center_log=" << best_stats.center_log
			          << " spread_log=" << best_stats.spread_log
			          << " typical_scale=" << std::exp(best_stats.center_log)
			          << " metric=" << best_metric;
		}
		std::cout << std::endl;
	}
}

void Train_MTPR(std::vector<std::string>& args, std::map<std::string, std::string>& opts)
{
	//args[0] - potname
	//args[1] - ts_name
	const bool inline_sh_model = PrepareInlineSphericalHarmonicModel(args, opts);
	const std::string adaptive_radial_initialization =
		opts["adaptive-radial-initialization"].empty()
			? "legacy" : opts["adaptive-radial-initialization"];
	if (adaptive_radial_initialization != "legacy"
	    && adaptive_radial_initialization != "balanced")
		ERROR("--adaptive-radial-initialization should be legacy or balanced");
	bool balanced_adaptive_radial_init =
		adaptive_radial_initialization == "balanced";
	double adaptive_radial_init_relative_rms = 0.03;
	if (!opts["adaptive-radial-init-relative-rms"].empty()) {
		if (!balanced_adaptive_radial_init)
			ERROR("--adaptive-radial-init-relative-rms requires --adaptive-radial-initialization=balanced");
		adaptive_radial_init_relative_rms = ParseStrictDoubleOption(
			opts["adaptive-radial-init-relative-rms"],
			"--adaptive-radial-init-relative-rms");
	}
	if (!std::isfinite(adaptive_radial_init_relative_rms)
	    || adaptive_radial_init_relative_rms <= 0.0)
		ERROR("--adaptive-radial-init-relative-rms should be finite and positive");
	const std::string pure_w_initialization = opts["pure-w-initialization"].empty()
		? "legacy" : opts["pure-w-initialization"];
	if (pure_w_initialization != "legacy" && pure_w_initialization != "balanced")
		ERROR("--pure-w-initialization should be legacy or balanced");
	const bool balanced_pure_w_init = pure_w_initialization == "balanced";
	const std::string pure_w_head_solve = opts["pure-w-head-solve"].empty()
		? "efs" : opts["pure-w-head-solve"];
	if (pure_w_head_solve != "efs"
	    && pure_w_head_solve != "full-quadratic")
		ERROR("--pure-w-head-solve should be efs or full-quadratic");
	if (pure_w_head_solve != "efs" && !balanced_pure_w_init)
		ERROR("--pure-w-head-solve=full-quadratic requires --pure-w-initialization=balanced");
	double pure_w_init_target_rms = 1.0;
	if (!opts["pure-w-init-target-rms"].empty()) {
		if (!balanced_pure_w_init)
			ERROR("--pure-w-init-target-rms requires --pure-w-initialization=balanced");
		pure_w_init_target_rms = ParseStrictDoubleOption(
			opts["pure-w-init-target-rms"], "--pure-w-init-target-rms");
	}
	if (pure_w_init_target_rms <= 0.0)
		ERROR("--pure-w-init-target-rms should be positive");

	double weight_energy = 1.0;
	if (opts["energy-weight"] != "")
		weight_energy = stod(opts["energy-weight"]);
        double weight_std = 0.0;
                if(opts["std-weight"] != "")
                        weight_std = stod(opts["std-weight"]);
        

        double weight_stdd = 0.0000;
                if(opts["stdd-weight"] != "")
                        weight_stdd = stod(opts["stdd-weight"]);

	double weight_force = 0.01;
	if (opts["force-weight"] != "")
		weight_force = stod(opts["force-weight"]);

	double weight_stress = 0.001;
	if (opts["stress-weight"] != "")
		weight_stress = stod(opts["stress-weight"]);

	double scale_by_force = 0.0;
	if (opts["scale-by-force"] != "")
		scale_by_force = stod(opts["scale-by-force"]);

	string validfnm = "";
	if (opts["valid-cfgs"] != "")
		validfnm = opts["valid-cfgs"];

	int maxits = 1000;
	if (opts["max-iter"] != "")
		maxits = stoi(opts["max-iter"]);

	bool two_layer_residual_staged = false;
	if (opts["two-layer-residual-staged"] != "")
		two_layer_residual_staged = true;
	int stage_a_steps = 0;
	int stage_b_steps = 0;
	int stage_c_steps = 0;
	if (opts["stage-a-steps"] != "")
		stage_a_steps = stoi(opts["stage-a-steps"]);
	if (opts["stage-b-steps"] != "")
		stage_b_steps = stoi(opts["stage-b-steps"]);
	if (opts["stage-c-steps"] != "")
		stage_c_steps = stoi(opts["stage-c-steps"]);
	if (stage_a_steps < 0 || stage_b_steps < 0 || stage_c_steps < 0)
		ERROR("--stage-a-steps, --stage-b-steps, and --stage-c-steps should be >= 0");
	if (two_layer_residual_staged
	    && stage_a_steps == 0
	    && stage_b_steps == 0
	    && stage_c_steps == 0)
		ERROR("--two-layer-residual-staged requires at least one positive stage step count");

	bool skip_preinit = false;
	if (opts["skip-preinit"] != "")
		skip_preinit = true;
        bool do_shift =true;
        if (opts["shift"] != "")
                do_shift = false;

        bool do_lin = false;
        if (opts["do-lin"] != "")
                do_lin = true;
	bool do_lin_rescale = false;
	if (opts["do-lin-rescale"] != "")
		do_lin_rescale = true;
	bool fine_tune = false;
	if (opts["fine-tune"] != "")
		fine_tune = true;
	const bool explicit_trainable_groups = opts.find("trainable-groups") != opts.end();
	const std::string trainable_groups = opts["trainable-groups"];
	if (explicit_trainable_groups && trainable_groups.empty())
		ERROR("--trainable-groups must be a nonempty comma-separated allowlist");
	const bool two_layer_gate_readout_linear_init =
		opts["two-layer-gate-readout-linear-init"] != "";
	int do_lin_step_limit = 1000;
	if (opts["do-lin-steps"] != "")
		do_lin_step_limit = stoi(opts["do-lin-steps"]);
	if (do_lin_step_limit < 0)
		ERROR("--do-lin-steps should be >= 0");
	int do_lin_frequency = 50;
	if (opts["do-lin-freq"] != "")
		do_lin_frequency = stoi(opts["do-lin-freq"]);
	if (do_lin_frequency <= 0)
		ERROR("--do-lin-freq should be > 0");


	string curr_fnm = "";
	if (opts["curr-pot-name"] != "")
		curr_fnm = opts["curr-pot-name"];
	string best_fnm = "";
	if (opts["best-pot-name"] != "")
		best_fnm = opts["best-pot-name"];

	string optimizer_trace_fnm = "";
	if (opts["optimizer-trace-file"] != "")
		optimizer_trace_fnm = opts["optimizer-trace-file"];
	if (opts["bfgs-trace-file"] != "") {
		if (!optimizer_trace_fnm.empty()
		    && optimizer_trace_fnm != opts["bfgs-trace-file"])
			ERROR("--optimizer-trace-file and --bfgs-trace-file disagree");
		optimizer_trace_fnm = opts["bfgs-trace-file"];
	}

	string trained_fnm = "Trained.sus2";
	if (opts["trained-pot-name"] != "")
		trained_fnm = opts["trained-pot-name"];
	sus2::ValidateModelOutputPath(trained_fnm);
	if (!curr_fnm.empty())
		sus2::ValidateModelOutputPath(curr_fnm);
	if (!best_fnm.empty())
		sus2::ValidateModelOutputPath(best_fnm);
	const string resolved_cli_best_fnm = best_fnm.empty()
		? sus2::DefaultBestCheckpointPath(curr_fnm)
		: best_fnm;
	if (sus2::CheckpointDestinationsAlias(resolved_cli_best_fnm, curr_fnm))
		ERROR("--best-pot-name must differ from --curr-pot-name");
	if (sus2::CheckpointDestinationsAlias(resolved_cli_best_fnm, trained_fnm))
		ERROR("--best-pot-name must differ from --trained-pot-name");

	string optimizer_kind = "bfgs";
	if (opts["optimizer"] != "")
		optimizer_kind = opts["optimizer"];
	if (optimizer_kind != "bfgs" && optimizer_kind != "lbfgs")
		ERROR("--optimizer should be 'bfgs' or 'lbfgs'");
	string radial_parameterization = balanced_pure_w_init ? "weight-norm" : "physical";
	if (opts["radial-parameterization"] != "")
		radial_parameterization = opts["radial-parameterization"];
	if (radial_parameterization != "physical"
	    && radial_parameterization != "weight-norm")
		ERROR("--radial-parameterization should be 'physical' or 'weight-norm'");
	string requested_radial_cutoff_type = "";
	if (opts["radial-cutoff-type"] != "") {
		requested_radial_cutoff_type = opts["radial-cutoff-type"];
		if (requested_radial_cutoff_type == "quadratic")
			requested_radial_cutoff_type = "legacy";
		if (requested_radial_cutoff_type != "legacy"
		    && requested_radial_cutoff_type != "polynomial")
			ERROR("--radial-cutoff-type should be 'legacy' or 'polynomial'");
	}
	int requested_radial_cutoff_p = -1;
	if (opts["radial-cutoff-p"] != "") {
		requested_radial_cutoff_p = stoi(opts["radial-cutoff-p"]);
		if (requested_radial_cutoff_p < 1 || requested_radial_cutoff_p > 64)
			ERROR("--radial-cutoff-p should be in [1, 64]");
		if (requested_radial_cutoff_type.empty())
			ERROR("--radial-cutoff-p requires --radial-cutoff-type=polynomial");
		if (requested_radial_cutoff_type != "polynomial")
			ERROR("--radial-cutoff-p only applies to --radial-cutoff-type=polynomial");
	}
	const bool allow_physical_radial_sign_repair =
		opts["allow-physical-radial-sign-repair"] != "";
	string bfgs_coordinate_normalization =
		(balanced_pure_w_init || balanced_adaptive_radial_init)
			? "efs-head" : "none";
	if (opts["bfgs-coordinate-normalization"] != "")
		bfgs_coordinate_normalization =
			opts["bfgs-coordinate-normalization"];
	if (bfgs_coordinate_normalization != "none"
	    && bfgs_coordinate_normalization != "efs-gn"
	    && bfgs_coordinate_normalization != "efs-head"
	    && bfgs_coordinate_normalization != "efs-head-full")
		ERROR("--bfgs-coordinate-normalization should be none, efs-gn, efs-head, or efs-head-full");
	if (optimizer_kind != "bfgs"
	    && bfgs_coordinate_normalization != "none")
		ERROR("--bfgs-coordinate-normalization requires --optimizer=bfgs");
	int bfgs_coordinate_probes = 4;
	if (opts["bfgs-coordinate-probes"] != "")
		bfgs_coordinate_probes =
			stoi(opts["bfgs-coordinate-probes"]);
	if (bfgs_coordinate_probes <= 0)
		ERROR("--bfgs-coordinate-probes should be > 0");
	double bfgs_coordinate_floor = 1.0e-6;
	if (opts["bfgs-coordinate-floor"] != "")
		bfgs_coordinate_floor =
			stod(opts["bfgs-coordinate-floor"]);
	if (!std::isfinite(bfgs_coordinate_floor)
	    || bfgs_coordinate_floor < 0.0
	    || bfgs_coordinate_floor > 1.0)
		ERROR("--bfgs-coordinate-floor should be finite and in [0,1]");

	double bfgs_conv_tol = 1e-3;
	if (opts["optimizer-conv-tol"] != "")
		bfgs_conv_tol = stod(opts["optimizer-conv-tol"]);
	if (opts["bfgs-conv-tol"] != "") {
		const double legacy_value = stod(opts["bfgs-conv-tol"]);
		if (opts["optimizer-conv-tol"] != "" && legacy_value != bfgs_conv_tol)
			ERROR("--optimizer-conv-tol and --bfgs-conv-tol disagree");
		bfgs_conv_tol = legacy_value;
	}
	if (!std::isfinite(bfgs_conv_tol) || bfgs_conv_tol < 0.0)
		ERROR("--optimizer-conv-tol should be finite and >= 0");

	string bfgs_line_search = optimizer_kind == "lbfgs" ? "armijo-value" : "wolfe";
	if (opts["optimizer-line-search"] != "")
		bfgs_line_search = opts["optimizer-line-search"];
	if (opts["bfgs-line-search"] != "") {
		if (opts["optimizer-line-search"] != ""
		    && opts["optimizer-line-search"] != opts["bfgs-line-search"])
			ERROR("--optimizer-line-search and --bfgs-line-search disagree");
		bfgs_line_search = opts["bfgs-line-search"];
	}
	if (bfgs_line_search != "wolfe" && bfgs_line_search != "armijo-value")
		ERROR("--optimizer-line-search should be 'wolfe' or 'armijo-value'");
	if (optimizer_kind == "lbfgs" && bfgs_line_search != "armijo-value")
		ERROR("--optimizer=lbfgs supports --optimizer-line-search=armijo-value only");

	int lbfgs_history_size = 20;
	if (opts["lbfgs-history"] != "")
		lbfgs_history_size = stoi(opts["lbfgs-history"]);
	if (lbfgs_history_size <= 0)
		ERROR("--lbfgs-history should be > 0");
	double lbfgs_curvature_tolerance = 1.0e-10;
	if (opts["lbfgs-curvature-tol"] != "")
		lbfgs_curvature_tolerance = stod(opts["lbfgs-curvature-tol"]);
	if (!std::isfinite(lbfgs_curvature_tolerance)
	    || lbfgs_curvature_tolerance < 0.0)
		ERROR("--lbfgs-curvature-tol should be finite and >= 0");
	double lbfgs_damping_threshold = 0.2;
	if (opts["lbfgs-damping"] != "")
		lbfgs_damping_threshold = stod(opts["lbfgs-damping"]);
	if (!std::isfinite(lbfgs_damping_threshold)
	    || lbfgs_damping_threshold < 0.0
	    || lbfgs_damping_threshold >= 1.0)
		ERROR("--lbfgs-damping should be finite and in [0,1)");
	double lbfgs_armijo_c1 = 1.0e-4;
	if (opts["lbfgs-armijo-c1"] != "")
		lbfgs_armijo_c1 = stod(opts["lbfgs-armijo-c1"]);
	if (!std::isfinite(lbfgs_armijo_c1)
	    || lbfgs_armijo_c1 <= 0.0
	    || lbfgs_armijo_c1 >= 1.0)
		ERROR("--lbfgs-armijo-c1 should be finite and in (0,1)");
	double lbfgs_initial_step = 1.0;
	if (opts["lbfgs-initial-step"] != "")
		lbfgs_initial_step = stod(opts["lbfgs-initial-step"]);
	if (!std::isfinite(lbfgs_initial_step) || lbfgs_initial_step <= 0.0)
		ERROR("--lbfgs-initial-step should be finite and > 0");
	double lbfgs_step_growth = 1.5;
	if (opts["lbfgs-step-growth"] != "")
		lbfgs_step_growth = stod(opts["lbfgs-step-growth"]);
	if (!std::isfinite(lbfgs_step_growth) || lbfgs_step_growth < 1.0)
		ERROR("--lbfgs-step-growth should be finite and >= 1");
        
        bool do_sample = true;
	if (opts["do-samp"] != "")
		do_sample = false;


	string weighting = "vibrations";
	if (opts["weighting"] != "")
		weighting = opts["weighting"];

	ForceLossKind force_loss_kind = ForceLossKind::L2;
	if (opts["force-loss"] != "") {
		try {
			force_loss_kind = ParseForceLossKind(opts["force-loss"]);
		}
		catch (const std::invalid_argument&) {
			ERROR("--force-loss should be 'l2' or 'log-cosh'");
		}
	}
	double force_log_cosh_scale = 2.0;
	if (opts["force-log-cosh-scale"] != "")
		force_log_cosh_scale = stod(opts["force-log-cosh-scale"]);
	if (!std::isfinite(force_log_cosh_scale) || force_log_cosh_scale <= 0.0)
		ERROR("--force-log-cosh-scale should be a finite positive value");

	bool custom_scal_range = false;
	std::pair<double, double> scal_range;
	if (opts["scal-range"] != "") {
		scal_range = ParseRangeOption(opts["scal-range"], "--scal-range");
		custom_scal_range = true;
	}

	bool custom_s_range = false;
	std::pair<double, double> s_range;
	if (opts["s-range"] != "") {
		s_range = ParseRangeOption(opts["s-range"], "--s-range");
		custom_s_range = true;
	}

	double radial_smooth = 1.0e-6;
	if (opts["radial-smooth"] != "")
		radial_smooth = stod(opts["radial-smooth"]);
	if (!std::isfinite(radial_smooth) || radial_smooth < 0.0)
		ERROR("--radial-smooth should be a finite non-negative value");

	int radial_smooth_grid = 128;
	if (opts["radial-smooth-grid"] != "")
		radial_smooth_grid = stoi(opts["radial-smooth-grid"]);
	if (radial_smooth_grid <= 0)
		ERROR("--radial-smooth-grid should be > 0");

	std::string scalar_weight_l2_preset = "none";
	if (opts["scalar-weight-l2-preset"] != "")
		scalar_weight_l2_preset = opts["scalar-weight-l2-preset"];
	if (scalar_weight_l2_preset != "none"
	    && scalar_weight_l2_preset != "recommended")
		ERROR("--scalar-weight-l2-preset should be 'none' or 'recommended'");
	double scalar_head_l2 = 0.0;
		double gate_scalar_l2 = 0.0;
		double gate_mix_l2 = 0.0;
		double gate_full_l2 = 0.0;
		double gate_x_l2 = 1.0e-4;
		const bool explicit_gate_x_l2 = opts["gate-x-l2"] != "";
		if (scalar_weight_l2_preset == "recommended") {
			scalar_head_l2 = 1.0e-5;
			gate_scalar_l2 = 1.0e-4;
		gate_mix_l2 = 1.0e-5;
		gate_full_l2 = 1.0e-4;
	}
	if (opts["scalar-head-l2"] != "")
		scalar_head_l2 = stod(opts["scalar-head-l2"]);
	if (opts["gate-scalar-l2"] != "")
		gate_scalar_l2 = stod(opts["gate-scalar-l2"]);
		if (opts["gate-mix-l2"] != "")
			gate_mix_l2 = stod(opts["gate-mix-l2"]);
		if (opts["gate-full-l2"] != "")
			gate_full_l2 = stod(opts["gate-full-l2"]);
		if (explicit_gate_x_l2)
			gate_x_l2 = stod(opts["gate-x-l2"]);
		if (!std::isfinite(scalar_head_l2) || scalar_head_l2 < 0.0)
			ERROR("--scalar-head-l2 should be a finite non-negative value");
		if (!std::isfinite(gate_scalar_l2) || gate_scalar_l2 < 0.0)
		ERROR("--gate-scalar-l2 should be a finite non-negative value");
	if (!std::isfinite(gate_mix_l2) || gate_mix_l2 < 0.0)
			ERROR("--gate-mix-l2 should be a finite non-negative value");
		if (!std::isfinite(gate_full_l2) || gate_full_l2 < 0.0)
			ERROR("--gate-full-l2 should be a finite non-negative value");
		if (!std::isfinite(gate_x_l2) || gate_x_l2 < 0.0)
			ERROR("--gate-x-l2 should be a finite non-negative value");
	const GuardCompressionOptions guard_compression_options =
		ParseGuardCompressionOptions(opts);

	if (opts["two-layer-gate-tanh-amplitude"] != "") {
		ERROR("--two-layer-gate-tanh-amplitude is obsolete in the release additive-node gate.");
	}
	bool custom_two_layer_gate_site_mode = false;
	std::string two_layer_gate_site_mode = "neighbor";
	if (opts["two-layer-gate-site-mode"] != "") {
		two_layer_gate_site_mode = opts["two-layer-gate-site-mode"];
		custom_two_layer_gate_site_mode = true;
	}
	if (two_layer_gate_site_mode != "neighbor")
		ERROR("--two-layer-gate-site-mode=double is obsolete; release gate supports 'neighbor' only");
	bool custom_two_layer_gate_mode = false;
	std::string two_layer_gate_mode = "mu-body-linear-combo";
	if (opts["two-layer-gate-mode"] != "") {
		two_layer_gate_mode = opts["two-layer-gate-mode"];
		if (two_layer_gate_mode == "mu-body-order")
			two_layer_gate_mode = "mu-scalar-full";
		custom_two_layer_gate_mode = true;
	}
	if (two_layer_gate_mode != "mu-body-linear-combo"
	    && two_layer_gate_mode != "mu-scalar-full")
		ERROR("--two-layer-gate-mode should be 'mu-body-linear-combo' or 'mu-scalar-full'");
	const bool custom_two_layer_gate_radial_mixing =
		opts["two-layer-gate-radial-mixing"] != "";
	const std::string two_layer_gate_radial_mixing =
		custom_two_layer_gate_radial_mixing
			? opts["two-layer-gate-radial-mixing"]
			: "none";
	if (two_layer_gate_radial_mixing != "none"
	    && two_layer_gate_radial_mixing != "full")
		ERROR("--two-layer-gate-radial-mixing should be 'none' or 'full'");
	const bool custom_two_layer_gate_factor_pruning =
		opts["two-layer-gate-factor-pruning"] != "";
	const std::string two_layer_gate_factor_pruning =
		custom_two_layer_gate_factor_pruning
			? opts["two-layer-gate-factor-pruning"]
			: "q-total";
	if (!IsSHFactorPruningValue(two_layer_gate_factor_pruning))
		ERROR("--two-layer-gate-factor-pruning should be same-k, legacy, or q-total");
	bool custom_second_layer_gate_mode = false;
	std::string second_layer_gate_mode = "mu-body-linear-combo";
	if (opts["second-layer-gate-mode"] != "") {
		second_layer_gate_mode = opts["second-layer-gate-mode"];
		if (second_layer_gate_mode == "mu-body-order")
			second_layer_gate_mode = "mu-scalar-full";
		custom_second_layer_gate_mode = true;
	}
	if (second_layer_gate_mode != "mu-body-linear-combo"
	    && second_layer_gate_mode != "mu-scalar-full")
		ERROR("--second-layer-gate-mode should be 'mu-body-linear-combo' or 'mu-scalar-full'");
	const bool custom_second_layer_gate_factor_pruning =
		opts["second-layer-gate-factor-pruning"] != "";
	const std::string second_layer_gate_factor_pruning =
		custom_second_layer_gate_factor_pruning
			? opts["second-layer-gate-factor-pruning"]
			: "gate1";
	if (custom_second_layer_gate_factor_pruning
	    && !IsSHFactorPruningValue(second_layer_gate_factor_pruning))
		ERROR("--second-layer-gate-factor-pruning should be same-k, legacy, or q-total");
	int requested_second_layer_gate_body_order = -1;
	if (opts["second-layer-gate-body-order"] != "") {
		requested_second_layer_gate_body_order =
			stoi(opts["second-layer-gate-body-order"]);
		if (requested_second_layer_gate_body_order < 2)
			ERROR("--second-layer-gate-body-order must be at least 2");
	}

	std::vector<double> fixed_atomic_energies;
	if (opts["atomic-energies"] != "")
		fixed_atomic_energies = ParseDoubleListOption(opts["atomic-energies"], "--atomic-energies");

	double fixed_atomic_energy_weight = 1.0e8;
	if (opts["atomic-energy-weight"] != "")
		fixed_atomic_energy_weight = stod(opts["atomic-energy-weight"]);
	if (!std::isfinite(fixed_atomic_energy_weight) || fixed_atomic_energy_weight < 0.0)
		ERROR("--atomic-energy-weight should be a finite non-negative value");

	if (opts["init-params"] == "")
		opts["init-params"] = "same";
	if (opts["init-params"] != "random" && opts["init-params"] != "same")
		ERROR("--init-params should be 'random' or 'same'");
	const OptionalRandomSeed init_random_seed = ParseOptionalRandomSeed(opts);
	double radial_mixing_init_scale = 0.0;
	const bool custom_radial_mixing_init_scale =
		opts["two-layer-gate-radial-mixing-init-scale"] != "";
	if (custom_radial_mixing_init_scale)
		radial_mixing_init_scale = ParseStrictDoubleOption(
			opts["two-layer-gate-radial-mixing-init-scale"],
			"--two-layer-gate-radial-mixing-init-scale");
	if (radial_mixing_init_scale < 0.0)
		ERROR("--two-layer-gate-radial-mixing-init-scale should be non-negative");

	bool mindist_update = false;
	if (opts["update-mindist"] != "")
		mindist_update = true;
	const ZBLTrainOptions zbl_options = ParseZBLTrainOptions(opts);

	SetTagLogStream("dev", &std::cout);
	int end = 1;
	MLMTPR mtpr = MLMTPR();
	if (custom_scal_range)
		mtpr.SetScalingSlopeRange(scal_range.first, scal_range.second);
	if (custom_s_range)
		mtpr.SetScalingShiftRange(s_range.first, s_range.second);
	for (int i = 0; i < end; i++) {
		try {
			mtpr.Load(args[0]);
			end = 1;
		}
		catch (MlipException& exp) {
			std::cout << exp.What() << std::endl;
			end = 10;
		}
	}
	if (zbl_options.enabled) {
		if (static_cast<int>(zbl_options.atomic_numbers.size()) != mtpr.species_count)
			ERROR("--zbl-elements count should match species_count");
		mtpr.ConfigureZBL(zbl_options.atomic_numbers,
		                  zbl_options.inner,
		                  zbl_options.outer,
		                  zbl_options.typewise,
		                  zbl_options.typewise_factor);
	}
	const bool loaded_complete_parameters = mtpr.HasCompleteParameters();
	const bool adaptive_pytorch_profile = mtpr.OuterUsesAdaptiveRadialCoefficients();
	if (opts.count("grouped-input")) {
		const bool static_radial_model = mtpr.IsSHPotential() && mtpr.OuterKRank() > 0
			&& !adaptive_pytorch_profile && !mtpr.OuterUsesPureRadialMatrix()
			&& !mtpr.TwoLayerGateEnabled() && !mtpr.MultiLayerGateEnabled()
			&& !mtpr.TwoLayerResidualEnabled() && !mtpr.TensorMessageEnabled()
			&& !mtpr.JointReadoutEnabled();
		const bool static_profile = opts.at("grouped-profile") == "native-static-v1";
		const bool legacy_profile = opts.at("grouped-profile") == "native-effect-v1"
			|| opts.at("grouped-profile") == "native-legacy-v1";
		const bool legacy_model = mtpr.IsSHPotential() && mtpr.TwoLayerGateEnabled()
			&& !adaptive_pytorch_profile && !mtpr.OuterUsesPureRadialMatrix()
			&& !mtpr.MultiLayerGateEnabled() && !mtpr.TwoLayerResidualEnabled()
			&& !mtpr.TensorMessageEnabled() && !mtpr.JointReadoutEnabled();
		if (static_profile ? !static_radial_model : (legacy_profile ? !legacy_model : !adaptive_pytorch_profile))
			ERROR("Grouped training.profile does not match the checkpoint architecture; "
			      "use native-static-v1 for a gate-free ranked SH model, native-effect-v1 "
			      "for an effect-gated model, or native-adaptive-v1 for an adaptive model");
		if (opts.at("grouped-input") == "continue" && !loaded_complete_parameters)
			ERROR("Grouped continuation requires a complete checkpoint, not an uninitialized topology");
	}
	if (!trainable_groups.empty()) {
		if (!adaptive_pytorch_profile || !loaded_complete_parameters
		    || opts["init-params"] != "same")
			ERROR("--trainable-groups requires a complete adaptive checkpoint and --init-params=same");
		if (fine_tune || do_lin || do_lin_rescale || two_layer_residual_staged)
			ERROR("--trainable-groups forbids legacy fine-tune, linear refits and residual stages");
		// Validate before reading the training data or performing calibration.
		if (mtpr.ActiveCoeffCount(false, trainable_groups) == 0)
			ERROR("--trainable-groups selected no active coefficients");
	}
	if (adaptive_pytorch_profile) {
		// One production conditioning/regularization contract for adaptive models.
		// Legacy architectures keep their historical options and defaults.
		for (const char* key : {
		         "radial-smooth", "radial-smooth-grid", "scalar-weight-l2-preset",
		         "scalar-head-l2", "gate-scalar-l2", "gate-mix-l2", "gate-full-l2",
		         "gate-x-l2", "radial-parameterization", "bfgs-coordinate-normalization",
		         "bfgs-coordinate-probes", "bfgs-coordinate-floor",
		         "adaptive-radial-initialization", "adaptive-radial-init-relative-rms",
		         "allow-physical-radial-sign-repair", "atomic-energy-weight",
		         "weighting", "scale-by-force", "force-loss", "force-log-cosh-scale"}) {
			if (!opts[key].empty())
				ERROR("Adaptive superlinear uses the fixed PyTorch training profile; remove --"
				      + std::string(key) + ". Only --std-weight and --stdd-weight remain selectable regularizers.");
		}
		if (!std::isfinite(weight_std) || weight_std < 0.0
		    || !std::isfinite(weight_stdd) || weight_stdd < 0.0)
			ERROR("--std-weight and --stdd-weight must be finite and non-negative");
		if (do_lin || do_lin_rescale || fine_tune || two_layer_residual_staged
		    || two_layer_gate_readout_linear_init || mindist_update
		    || !fixed_atomic_energies.empty() || guard_compression_options.enabled)
			ERROR("Adaptive PyTorch profile does not use legacy linear warmup/refits, sign repair, "
			      "fixed atomic-energy penalties, or compression penalties");
		if (mtpr.HasZBL())
			ERROR("Adaptive PyTorch profile calibration currently requires a model without ZBL");
		balanced_adaptive_radial_init = !loaded_complete_parameters;
		radial_parameterization = "weight-norm";
		bfgs_coordinate_normalization = "pytorch-fixed-rms";
		scalar_weight_l2_preset = "recommended";
		scalar_head_l2 = 1.0e-5;
		gate_full_l2 = 1.0e-4;
		gate_scalar_l2 = gate_mix_l2 = gate_x_l2 = 0.0;
		radial_smooth = 1.0e-6;
		radial_smooth_grid = 128;
		skip_preinit = true;
	}
	if (mtpr.OuterUsesAdaptiveRadialCoefficients()) {
		if (!explicit_gate_x_l2) {
			gate_x_l2 = 0.0;
		} else if (gate_x_l2 != 0.0) {
			ERROR("--gate-x-l2 is not valid for adaptive radial coefficient models; "
			      "use --gate-x-l2=0 and the folded adaptive gate regularization instead");
		}
	}
	if (bfgs_coordinate_normalization == "efs-head-full"
	    && !balanced_pure_w_init)
		ERROR("--bfgs-coordinate-normalization=efs-head-full requires "
		      "--pure-w-initialization=balanced");
	if (balanced_pure_w_init) {
		if (maxits < 0)
			ERROR("Balanced pure-W initialization requires --max-iter >= 0");
		if (!mtpr.OuterUsesPureRadialMatrix())
			ERROR("--pure-w-initialization=balanced requires a pure-W channelwise model");
		if (loaded_complete_parameters)
			ERROR("Balanced pure-W initialization only accepts an incomplete fresh seed; "
			      "a complete checkpoint must be resumed with --init-params=same without --pure-w-initialization=balanced");
		if (opts["init-params"] != "same")
			ERROR("Balanced pure-W initialization requires --init-params=same; "
			      "--init-random-seed controls only its new W directions");
		if (optimizer_kind != "bfgs" || radial_parameterization != "weight-norm")
			ERROR("Balanced pure-W initialization currently requires BFGS and weight-norm radial coordinates");
		if (force_loss_kind != ForceLossKind::L2)
			ERROR("Balanced pure-W initialization requires --force-loss=l2 for its initial linear head solve");
		const bool use_full_head_quadratic =
			pure_w_head_solve == "full-quadratic";
		const bool use_full_head_chart =
			bfgs_coordinate_normalization == "efs-head-full";
		if ((use_full_head_quadratic || use_full_head_chart)
		    && bfgs_line_search != "wolfe")
			ERROR("Full scalar-head solve/chart requires Wolfe line search; "
			      "the historical value-only Armijo path uses a different std denominator");
		if (use_full_head_quadratic && do_lin)
			ERROR("--pure-w-head-solve=full-quadratic is incompatible with --do-lin; "
			      "the periodic legacy solve omits std/stdd and would overwrite the exact head solution");
		if (do_lin_rescale || fine_tune || two_layer_residual_staged
		    || two_layer_gate_readout_linear_init || mindist_update)
			ERROR("Balanced pure-W initialization is incompatible with do-lin-rescale, fine-tune, "
			      "staged/readout-only initialization, and update-mindist");
		if (mtpr.HasZBL() || mtpr.MultiLayerGateEnabled() || !opts["multi-layer-gate"].empty()
		    || mtpr.TwoLayerResidualEnabled() || guard_compression_options.enabled)
			ERROR("Balanced pure-W initialization currently supports one-gate pure models without ZBL, residual stages, or compression guards");
			if (custom_radial_mixing_init_scale)
				ERROR("Balanced pure-W initialization uses --pure-w-init-target-rms, not --two-layer-gate-radial-mixing-init-scale");
		}
		if (balanced_adaptive_radial_init) {
			if (maxits < 0)
				ERROR("Balanced adaptive radial initialization requires --max-iter >= 0");
			if (!mtpr.OuterUsesAdaptiveRadialCoefficients())
				ERROR("--adaptive-radial-initialization=balanced requires an adaptive radial coefficient model");
			if (loaded_complete_parameters)
				ERROR("Balanced adaptive radial initialization only accepts an incomplete fresh seed; "
				      "resume a complete checkpoint with --init-params=same without --adaptive-radial-initialization=balanced");
			if (opts["init-params"] != "same")
				ERROR("Balanced adaptive radial initialization requires --init-params=same; "
				      "--init-random-seed controls only its new U directions");
			if (optimizer_kind != "bfgs")
				ERROR("Balanced adaptive radial initialization currently requires BFGS");
			if (force_loss_kind != ForceLossKind::L2)
				ERROR("Balanced adaptive radial initialization requires --force-loss=l2 for its initial linear head solve");
			if (do_lin_rescale || fine_tune || two_layer_residual_staged
			    || two_layer_gate_readout_linear_init || mindist_update)
				ERROR("Balanced adaptive radial initialization is incompatible with do-lin-rescale, fine-tune, "
				      "staged/readout-only initialization, and update-mindist");
			if (mtpr.HasZBL() || mtpr.MultiLayerGateEnabled() || !opts["multi-layer-gate"].empty()
			    || mtpr.TwoLayerResidualEnabled() || guard_compression_options.enabled)
				ERROR("Balanced adaptive radial initialization currently supports one-gate adaptive models without ZBL, residual stages, or compression guards");
			if (balanced_pure_w_init)
				ERROR("Use either --pure-w-initialization=balanced or --adaptive-radial-initialization=balanced, not both");
		}
	if (!requested_radial_cutoff_type.empty()
	    && mtpr.p_RadialBasis->radial_cutoff_type != requested_radial_cutoff_type)
		ERROR("--radial-cutoff-type must match the loaded model; changing cutoff function requires init-sh/inline initialization");
	if (requested_radial_cutoff_p >= 1
	    && mtpr.p_RadialBasis->radial_cutoff_p != requested_radial_cutoff_p)
		ERROR("--radial-cutoff-p must match the loaded model; changing cutoff function requires init-sh/inline initialization");
	const auto requested_scaling_map_it = opts.find("scaling-map");
	if (requested_scaling_map_it != opts.end()
	    && !requested_scaling_map_it->second.empty()) {
		if (!mtpr.IsSHPotential())
			ERROR("--scaling-map is only supported for SUS2-SH models");
		if (requested_scaling_map_it->second != mtpr.ScalingMap())
			ERROR("--scaling-map must match the loaded model; changing K/L/LK/pair topology requires a new init-sh model");
	}
	const bool requested_multi_layer_gate = opts["multi-layer-gate"] != "";
	const bool requested_two_layer_gate_readout =
		opts["two-layer-gate-readout"] != "";
	const bool requested_two_layer_gate_radial_mixing =
		two_layer_gate_radial_mixing == "full";
	const bool requested_two_layer_gate =
		opts["two-layer-gate"] != "" || requested_multi_layer_gate
		|| requested_two_layer_gate_readout
		|| requested_two_layer_gate_radial_mixing;
	const bool requested_two_layer_gate_shared_radial =
		opts["two-layer-gate-shared-radial"] != "";
	const bool requested_two_layer_gate_decoupled_scaling =
		opts["two-layer-gate-decoupled-scaling"] != ""
		|| opts["two-layer-gate-full-decoupled"] != "";
	const bool requested_two_layer_gate_edge_l1 =
		opts["two-layer-gate-edge-l1"] != "";
	const bool requested_two_layer_residual = opts["two-layer-residual"] != "";
	const auto outer_k_rank1_alias_it = opts.find("outer-k-rank1");
	const bool requested_outer_k_rank1_alias =
		outer_k_rank1_alias_it != opts.end();
	if (requested_outer_k_rank1_alias
	    && outer_k_rank1_alias_it->second != "true")
		ERROR("--outer-k-rank1 is a boolean compatibility flag; use it without '=value'");
	const bool has_requested_outer_k_rank =
		opts.find("outer-k-rank") != opts.end();
	if (requested_outer_k_rank1_alias && has_requested_outer_k_rank)
		ERROR("Use either --outer-k-rank1 or --outer-k-rank=<R>, not both");
	int requested_outer_k_rank = -1;
	if (requested_outer_k_rank1_alias)
		requested_outer_k_rank = 1;
	else if (has_requested_outer_k_rank)
		requested_outer_k_rank =
			ParseOptionalNonnegativeInteger(opts, "outer-k-rank");
	const int requested_two_layer_gate_k_rank =
		ParseOptionalNonnegativeInteger(opts, "two-layer-gate-k-rank");
	const std::string requested_superlinear_mode = opts["superlinear-mode"];
	if (!requested_superlinear_mode.empty()
	    && requested_superlinear_mode != "legacy"
	    && requested_superlinear_mode != "pure-w-channelwise"
	    && requested_superlinear_mode != "radial-coefficient-gate")
		ERROR("--superlinear-mode should be legacy, pure-w-channelwise, or radial-coefficient-gate");
	if (!requested_superlinear_mode.empty()
	    && (((requested_superlinear_mode == "pure-w-channelwise")
	         != (mtpr.OuterUsesPureRadialMatrix() && mtpr.OuterUsesSameChannelGraph()))
	        || ((requested_superlinear_mode == "radial-coefficient-gate")
	            != mtpr.OuterUsesAdaptiveRadialCoefficients())))
		ERROR("--superlinear-mode must match the loaded model; changing the outer graph requires init-sh/inline initialization");
		if (!opts["readout-mode"].empty()) {
			if (opts["readout-mode"] != "shared" && opts["readout-mode"] != "species")
				ERROR("--readout-mode should be shared or species");
			if (opts["readout-mode"] != mtpr.ReadoutMode())
				ERROR("--readout-mode must match the loaded model; use the explicit conversion command instead of changing it during resume");
		}
		if (opts.find("joint-readout") != opts.end() && !opts["joint-readout"].empty()) {
			const std::string value = opts["joint-readout"];
			if (value == "true" || value == "1") mtpr.EnableJointReadout();
			else if (value == "false" || value == "0") {
				if (mtpr.JointReadoutEnabled()) ERROR("--joint-readout=false cannot remove a trained head during resume");
			} else ERROR("--joint-readout must be true or false");
		}
		if (!opts["adaptive-radial-projection"].empty()
		    && (!mtpr.OuterUsesAdaptiveRadialCoefficients()
		        || opts["adaptive-radial-projection"] != mtpr.AdaptiveRadialProjection()))
			ERROR("--adaptive-radial-projection must match the loaded adaptive model; full to shared-n is not an exact general conversion");
		if (!opts["adaptive-radial-amplitude-mode"].empty()
		    && (!mtpr.OuterUsesAdaptiveRadialCoefficients()
		        || opts["adaptive-radial-amplitude-mode"] != mtpr.AdaptiveRadialAmplitudeMode()))
			ERROR("--adaptive-radial-amplitude-mode must match the loaded adaptive model");
		if (!opts["adaptive-radial-shared-n-rank"].empty()
		    && (!mtpr.OuterUsesAdaptiveRadialCoefficients()
		        || ParseOptionalNonnegativeInteger(opts, "adaptive-radial-shared-n-rank") != mtpr.AdaptiveRadialSharedNRank()))
			ERROR("--adaptive-radial-shared-n-rank must match the loaded model; no silent topology conversion during resume");
		if (!opts["adaptive-radial-activation"].empty()
		    && (!mtpr.OuterUsesAdaptiveRadialCoefficients()
		        || opts["adaptive-radial-activation"] != mtpr.AdaptiveRadialActivation()))
			ERROR("--adaptive-radial-activation must match the loaded model; enabling tanh changes the physical function");
		if (!opts["tensor-message-lmax"].empty()) {
			const int requested_tensor_message_lmax =
				ParseOptionalNonnegativeInteger(opts, "tensor-message-lmax");
			if (requested_tensor_message_lmax != mtpr.TensorMessageLMax())
				ERROR("--tensor-message-lmax must match the loaded model; recreate or explicitly convert topology instead of changing it during resume");
		}
	if (mtpr.OuterUsesPureRadialMatrix()
	    || mtpr.OuterUsesAdaptiveRadialCoefficients()) {
		const std::string loaded_outer_factor_pruning =
			mtpr.OuterUsesSameChannelGraph() ? "same-k" : "q-total";
		if (!opts["sh-factor-pruning"].empty()
		    && opts["sh-factor-pruning"] != loaded_outer_factor_pruning)
			ERROR("--sh-factor-pruning must match the loaded superlinear outer graph; changing it requires init-sh/inline initialization");
		const auto gate_body_it = opts.find("two-layer-gate-body-order");
		if (gate_body_it != opts.end() && !gate_body_it->second.empty()
		    && ParseOptionalNonnegativeInteger(opts, "two-layer-gate-body-order")
		        != mtpr.TwoLayerGateBodyOrderCount() + 1)
			ERROR("--two-layer-gate-body-order must match the loaded superlinear gate graph; changing it requires init-sh/inline initialization");
	}
	bool plain_to_gate_upgrade = false;
	bool edge_l1_gate_upgrade = false;
	bool multi_layer_gate_upgrade = false;
	bool gate_readout_upgrade = false;
	bool plain_to_gate_disabled_controls = false;
	bool multi_layer_gate_disabled_controls = false;
	int plain_to_gate_body_order = -1;
	bool plain_to_gate_independent_radial = false;
	if (requested_outer_k_rank >= 0
	    && requested_outer_k_rank != mtpr.OuterKRank())
		ERROR("--outer-k-rank must match the loaded model; changing rank requires init-sh/inline initialization");
	if (requested_two_layer_gate_k_rank >= 0
	    && requested_two_layer_gate_k_rank != mtpr.TwoLayerGateKRank())
		ERROR("--two-layer-gate-k-rank must match the loaded model; changing rank requires init-sh/inline initialization");
	if (mtpr.OuterKRankEnabled()
	    && (requested_two_layer_gate_readout
	        || requested_multi_layer_gate
	        || requested_two_layer_residual))
		ERROR("--outer-k-rank is not compatible with readout, multi-layer gate, or residual options");
	if (mtpr.TwoLayerGateKRankEnabled()
	    && (requested_two_layer_gate_readout
	        || requested_multi_layer_gate
	        || requested_two_layer_residual))
		ERROR("--two-layer-gate-k-rank is not compatible with readout, multi-layer gate, or residual options");
	if ((custom_second_layer_gate_mode
	     || custom_second_layer_gate_factor_pruning
	     || requested_second_layer_gate_body_order > 0)
	    && !requested_multi_layer_gate
	    && !mtpr.MultiLayerGateEnabled())
		ERROR("--second-layer-gate-* requires --multi-layer-gate unless the loaded model already has release3 multi-layer gate");
	if (requested_multi_layer_gate && requested_two_layer_gate_edge_l1)
		ERROR("--multi-layer-gate is not compatible with --two-layer-gate-edge-l1");
	if (requested_two_layer_gate_radial_mixing && requested_two_layer_gate_edge_l1)
		ERROR("--two-layer-gate-radial-mixing=full is not compatible with --two-layer-gate-edge-l1");
	if (requested_two_layer_gate_radial_mixing && requested_multi_layer_gate)
		ERROR("--two-layer-gate-radial-mixing=full is not compatible with --multi-layer-gate");
	if (requested_two_layer_gate_radial_mixing
	    && (!mtpr.OuterKRankEnabled() || !mtpr.TwoLayerGateKRankEnabled())
	    && (requested_outer_k_rank <= 0 || requested_two_layer_gate_k_rank <= 0))
		ERROR("--two-layer-gate-radial-mixing=full requires --outer-k-rank=<Ro> and --two-layer-gate-k-rank=<Rg>");
	if (custom_two_layer_gate_radial_mixing
	    && !requested_two_layer_gate_radial_mixing
	    && mtpr.TwoLayerGateRadialMixingEnabled())
		ERROR("--two-layer-gate-radial-mixing=none does not match the loaded full radial-mixing model");
	if (requested_two_layer_gate_readout && requested_multi_layer_gate)
		ERROR("--two-layer-gate-readout first version supports one gate only");
	if (requested_two_layer_gate_readout && requested_two_layer_gate_edge_l1)
		ERROR("--two-layer-gate-readout first version does not include edge-L1");
	if (requested_two_layer_gate_readout && requested_two_layer_residual)
		ERROR("--two-layer-gate-readout is not compatible with --two-layer-residual");
	if (requested_multi_layer_gate && requested_two_layer_gate_decoupled_scaling)
		ERROR("--multi-layer-gate is not compatible with --two-layer-gate-decoupled-scaling");
	if (requested_two_layer_gate_shared_radial && !requested_two_layer_gate
	    && !mtpr.TwoLayerGateEnabled())
		ERROR("--two-layer-gate-shared-radial requires --two-layer-gate when upgrading a plain SH model");
	if (requested_two_layer_gate_decoupled_scaling && !requested_two_layer_gate
	    && !mtpr.TwoLayerGateEnabled())
		ERROR("--two-layer-gate-decoupled-scaling requires --two-layer-gate when upgrading a plain SH model");
	if (custom_two_layer_gate_site_mode && !requested_two_layer_gate
	    && !mtpr.TwoLayerGateEnabled())
		ERROR("--two-layer-gate-site-mode requires --two-layer-gate when upgrading a plain SH model");
	if (custom_two_layer_gate_mode && !requested_two_layer_gate
	    && !mtpr.TwoLayerGateEnabled())
		ERROR("--two-layer-gate-mode requires --two-layer-gate when upgrading a plain SH model");
	if (custom_two_layer_gate_factor_pruning && !requested_two_layer_gate
	    && !mtpr.TwoLayerGateEnabled())
		ERROR("--two-layer-gate-factor-pruning requires --two-layer-gate when upgrading a plain SH model");
	if (custom_two_layer_gate_radial_mixing && !requested_two_layer_gate
	    && !mtpr.TwoLayerGateEnabled())
		ERROR("--two-layer-gate-radial-mixing requires --two-layer-gate when upgrading a plain SH model");
	if (requested_two_layer_gate && !mtpr.TwoLayerGateEnabled()) {
		if (!mtpr.IsSHPotential())
			ERROR("--two-layer-gate can only upgrade or train a SUS2-SH model");
		if (requested_two_layer_residual)
			ERROR("--two-layer-residual is not supported by mu-body-order gate models");
		if (opts["two-layer-gate-body-order"] != "") {
			plain_to_gate_body_order = stoi(opts["two-layer-gate-body-order"]);
			if (plain_to_gate_body_order < 2)
				ERROR("--two-layer-gate-body-order must be at least 2");
		}
		plain_to_gate_independent_radial = true;
		mtpr.UpgradePlainSHToTwoLayerGate(plain_to_gate_body_order,
		                                  plain_to_gate_independent_radial,
		                                  two_layer_gate_site_mode,
		                                  two_layer_gate_mode,
		                                  requested_two_layer_gate_decoupled_scaling,
		                                  two_layer_gate_factor_pruning);
		plain_to_gate_upgrade = true;
		plain_to_gate_disabled_controls = do_lin || do_lin_rescale || fine_tune;
		do_lin = false;
		do_lin_rescale = false;
		fine_tune = false;
	}
	if (requested_two_layer_gate_edge_l1) {
		if (!mtpr.TwoLayerGateEnabled())
			ERROR("--two-layer-gate-edge-l1 requires a two-layer gate model or --two-layer-gate");
		if (!mtpr.TwoLayerGateEdgeL1Enabled()) {
			mtpr.UpgradeTwoLayerGateToEdgeL1();
			edge_l1_gate_upgrade = true;
		}
	}
	if (requested_two_layer_gate_decoupled_scaling) {
		if (!mtpr.TwoLayerGateEnabled())
			ERROR("--two-layer-gate-decoupled-scaling requires a two-layer gate model or --two-layer-gate");
		if (mtpr.MultiLayerGateEnabled())
			ERROR("--two-layer-gate-decoupled-scaling is only supported for one-layer gate models");
		if (!mtpr.TwoLayerGateUsesDecoupledScaling())
			mtpr.EnableTwoLayerGateDecoupledScalingFromBase();
	}
	if (requested_two_layer_gate_radial_mixing) {
		if (!mtpr.TwoLayerGateEnabled())
			ERROR("--two-layer-gate-radial-mixing=full requires a two-layer gate model or --two-layer-gate");
		if (mtpr.TwoLayerGateEdgeL1Enabled())
			ERROR("--two-layer-gate-radial-mixing=full is not compatible with two-layer gate edge-L1 models");
		if (mtpr.MultiLayerGateEnabled())
			ERROR("--two-layer-gate-radial-mixing=full is not compatible with multi-layer gate models");
		if (!mtpr.TwoLayerGateRadialMixingEnabled())
			mtpr.EnableTwoLayerGateRadialMixingFull();
	}
	if (requested_two_layer_gate_readout) {
		if (!mtpr.TwoLayerGateEnabled())
			ERROR("--two-layer-gate-readout requires a two-layer gate model or --two-layer-gate");
		if (mtpr.MultiLayerGateEnabled())
			ERROR("--two-layer-gate-readout first version supports one gate only");
		if (mtpr.TwoLayerGateEdgeL1Enabled())
			ERROR("--two-layer-gate-readout first version does not include edge-L1");
		if (!mtpr.TwoLayerGateReadoutEnabled()) {
			mtpr.EnableTwoLayerGateReadout();
			gate_readout_upgrade = true;
		}
	}
	if (requested_multi_layer_gate) {
		if (!mtpr.TwoLayerGateEnabled())
			ERROR("--multi-layer-gate requires a two-layer gate model or --two-layer-gate");
		if (mtpr.TwoLayerGateEdgeL1Enabled())
			ERROR("--multi-layer-gate is not compatible with two-layer gate edge-L1 models");
		if (!mtpr.MultiLayerGateEnabled()) {
			const std::string inherited_second_layer_factor_pruning =
				custom_second_layer_gate_factor_pruning
					? second_layer_gate_factor_pruning
				: (plain_to_gate_upgrade
					? two_layer_gate_factor_pruning
					: "gate1");
			mtpr.UpgradeTwoLayerGateToMultiLayerGate(
				requested_second_layer_gate_body_order,
				second_layer_gate_mode,
				inherited_second_layer_factor_pruning);
			multi_layer_gate_upgrade = true;
			multi_layer_gate_disabled_controls =
				do_lin || do_lin_rescale || fine_tune;
			do_lin = false;
			do_lin_rescale = false;
			fine_tune = false;
		}
	}
	if (custom_two_layer_gate_site_mode) {
		if (!mtpr.TwoLayerGateEnabled())
			ERROR("--two-layer-gate-site-mode requires a two-layer gate model or --two-layer-gate");
		if (!plain_to_gate_upgrade
		    && mtpr.TwoLayerGateSiteMode() != two_layer_gate_site_mode)
			ERROR("--two-layer-gate-site-mode does not match the loaded two-layer gate model");
	}
	if (custom_two_layer_gate_mode) {
		if (!mtpr.TwoLayerGateEnabled())
			ERROR("--two-layer-gate-mode requires a two-layer gate model or --two-layer-gate");
		if (!plain_to_gate_upgrade
		    && ((two_layer_gate_mode == "mu-body-linear-combo"
		         && !mtpr.TwoLayerGateUsesBodyLinearCombo())
		        || (two_layer_gate_mode == "mu-scalar-full"
		            && !mtpr.TwoLayerGateUsesFullScalarWeights())))
			ERROR("--two-layer-gate-mode does not match the loaded two-layer gate model");
	}
	if (custom_two_layer_gate_factor_pruning) {
		if (!mtpr.TwoLayerGateEnabled())
			ERROR("--two-layer-gate-factor-pruning requires a two-layer gate model or --two-layer-gate");
		if (!mtpr.TwoLayerGateMatchesFactorPruning(two_layer_gate_factor_pruning))
			ERROR("--two-layer-gate-factor-pruning does not match the loaded two-layer gate model");
	}
	if (custom_second_layer_gate_mode) {
		if (!mtpr.MultiLayerGateEnabled())
			ERROR("--second-layer-gate-mode requires a release3 multi-layer gate model or --multi-layer-gate");
		if (!multi_layer_gate_upgrade
		    && ((second_layer_gate_mode == "mu-body-linear-combo"
		         && !mtpr.SecondLayerGateUsesBodyLinearCombo())
		        || (second_layer_gate_mode == "mu-scalar-full"
		            && !mtpr.SecondLayerGateUsesFullScalarWeights())))
			ERROR("--second-layer-gate-mode does not match the loaded release3 multi-layer gate model");
	}
	if (custom_second_layer_gate_factor_pruning) {
		if (!mtpr.MultiLayerGateEnabled())
			ERROR("--second-layer-gate-factor-pruning requires a release3 multi-layer gate model or --multi-layer-gate");
		if (!mtpr.SecondLayerGateMatchesFactorPruning(second_layer_gate_factor_pruning))
			ERROR("--second-layer-gate-factor-pruning does not match the loaded release3 multi-layer gate model");
	}
	if (requested_second_layer_gate_body_order > 0) {
		if (!mtpr.MultiLayerGateEnabled())
			ERROR("--second-layer-gate-body-order requires a release3 multi-layer gate model or --multi-layer-gate");
		if (!multi_layer_gate_upgrade
		    && mtpr.SecondLayerGateBodyOrderCount() + 1
		       != requested_second_layer_gate_body_order)
			ERROR("--second-layer-gate-body-order does not match the loaded release3 multi-layer gate model");
	}
	if (fine_tune && !mtpr.HasCompleteParameters())
		ERROR("--fine-tune requires a complete trained model with shift/scal/radial/linear coefficients.");
	if (!fixed_atomic_energies.empty() &&
	    static_cast<int>(fixed_atomic_energies.size()) != mtpr.species_count)
		ERROR("--atomic-energies count should match species_count");
	if (two_layer_residual_staged && !mtpr.TwoLayerResidualEnabled())
		ERROR("--two-layer-residual-staged requires a model initialized with --two-layer-residual");
	if (mtpr.TwoLayerGateReadoutEnabled()
	    && guard_compression_options.enabled
	    && guard_compression_options.block_monotonic_weight > 0.0)
		ERROR("--guard-compression-block-monotonic-weight is not compatible with gate readout; set it to 0 or disable gate readout");
	if (two_layer_gate_readout_linear_init) {
		if (!loaded_complete_parameters)
			ERROR("--two-layer-gate-readout-linear-init requires a complete trained checkpoint");
		if (!mtpr.TwoLayerGateReadoutEnabled())
			ERROR("--two-layer-gate-readout-linear-init requires --two-layer-gate-readout or an enabled readout model");
		if (plain_to_gate_upgrade || multi_layer_gate_upgrade
		    || edge_l1_gate_upgrade || mtpr.TwoLayerResidualEnabled())
			ERROR("--two-layer-gate-readout-linear-init supports only a trained one-gate, non-residual model");
		if (do_lin || do_lin_rescale || fine_tune)
			ERROR("--two-layer-gate-readout-linear-init is not compatible with --do-lin, --do-lin-rescale, or --fine-tune");
		if (two_layer_residual_staged)
			ERROR("--two-layer-gate-readout-linear-init is not compatible with residual staged training");
		if (force_loss_kind != ForceLossKind::L2)
			ERROR("--two-layer-gate-readout-linear-init requires --force-loss=l2");
		if (weight_std != 0.0 || weight_stdd != 0.0)
			ERROR("--two-layer-gate-readout-linear-init requires --std-weight=0 and --stdd-weight=0");
		if (scale_by_force != 0.0)
			ERROR("--two-layer-gate-readout-linear-init currently requires --scale-by-force=0");
		if (guard_compression_options.enabled)
			ERROR("--two-layer-gate-readout-linear-init is not compatible with guard-compression terms");
	}
	const int required_radial_first_coeff_repairs =
		mtpr.CountRadialFirstCoeffsNeedingPositiveRepair();
	if (loaded_complete_parameters
	    && !two_layer_gate_readout_linear_init
	    && maxits > 0
	    && mtpr.has_radial_coeffs
	    && radial_parameterization == "physical"
	    && required_radial_first_coeff_repairs > 0
	    && !allow_physical_radial_sign_repair) {
		ERROR("Refusing to modify a complete trained checkpoint: "
		      "--radial-parameterization=physical would repair "
		      + std::to_string(required_radial_first_coeff_repairs)
		      + " radial first coefficients and then refit the linear coefficients. "
		        "Use --radial-parameterization=weight-norm to preserve the checkpoint, "
		        "or pass --allow-physical-radial-sign-repair to explicitly opt in "
		        "to the legacy conversion behavior.");
	}
#ifdef MLIP_MPI
	MPI_Comm_rank(MPI_COMM_WORLD, &prank);
	MPI_Comm_size(MPI_COMM_WORLD, &psize);
#endif

#ifdef MLIP_MPI
	MPI_Barrier(MPI_COMM_WORLD);
#endif
	auto save_model_atomically_collective = [&]
		(const std::string& path, const std::string& context) {
		int save_failed = 0;
		std::string save_error;
		if (prank == 0) {
			try {
				sus2::AtomicWriteCheckpoint(
					path,
					[&](const std::string& temporary) {
						mtpr.Save(temporary);
					});
			} catch (const MlipException& exception) {
				save_failed = 1;
				save_error = exception.What();
			} catch (const std::exception& exception) {
				save_failed = 1;
				save_error = exception.what();
			} catch (...) {
				save_failed = 1;
				save_error = "unknown model-save exception";
			}
		}
#ifdef MLIP_MPI
		MPI_Bcast(&save_failed, 1, MPI_INT, 0, MPI_COMM_WORLD);
		int error_length = prank == 0
			? static_cast<int>(save_error.size())
			: 0;
		MPI_Bcast(&error_length, 1, MPI_INT, 0, MPI_COMM_WORLD);
		if (prank != 0)
			save_error.resize(error_length);
		if (error_length > 0)
			MPI_Bcast(
				&save_error[0], error_length, MPI_CHAR, 0, MPI_COMM_WORLD);
#endif
		if (save_failed != 0)
			ERROR("Atomic model save failed during " + context + ": " + save_error);
	};

	const bool direct_outer_radial_mode =
		mtpr.OuterUsesPureRadialMatrix()
		|| mtpr.OuterUsesAdaptiveRadialCoefficients();
	const double legacy_radial_penalty = direct_outer_radial_mode ? 0.0 : 1e-9;
	MTPR_trainer trainer(&mtpr, weight_energy, weight_force, weight_stress,
	                    scale_by_force, legacy_radial_penalty, curr_fnm, 0);
	if (prank == 0 && direct_outer_radial_mode)
		std::cout << (mtpr.OuterUsesAdaptiveRadialCoefficients()
		                  ? "radial-coefficient-gate"
		                  : "pure-w-channelwise")
		          << ": legacy outer radial norm/orthogonality penalty disabled; "
		          << "distance-matrix smoothness regularizes physical radial response."
		          << std::endl;
	//LOSS FUNCTIONAL MODIFICATION!!!
	trainer.weighting = weighting;
        trainer.do_lin=do_lin;
	trainer.do_lin_rescale = do_lin_rescale;
	trainer.do_lin_step_limit = do_lin_step_limit;
	trainer.do_lin_frequency = do_lin_frequency;
	trainer.freeze_scal_coeffs = fine_tune;
	trainer.trainable_groups = trainable_groups;
	trainer.std_scaling = weight_std;
        trainer.stdd_scaling = weight_stdd;
	trainer.linstop = bfgs_conv_tol;	//if in 100 iterations loss decreases less than this, BFGS is finished
	trainer.optimizer_kind = optimizer_kind;
	trainer.bfgs_line_search = bfgs_line_search;
	trainer.radial_parameterization = radial_parameterization;
	trainer.bfgs_coordinate_normalization =
		bfgs_coordinate_normalization;
	trainer.bfgs_coordinate_probes = bfgs_coordinate_probes;
	trainer.bfgs_coordinate_floor = bfgs_coordinate_floor;
	trainer.adaptive_pytorch_profile = adaptive_pytorch_profile;
	trainer.consistent_std_value_loss = adaptive_pytorch_profile;
	trainer.curr_pot_name = curr_fnm;
	trainer.best_pot_name = best_fnm;
	trainer.bfgs_trace_file = optimizer_trace_fnm;
	trainer.lbfgs_history_size = lbfgs_history_size;
	trainer.lbfgs_curvature_tolerance = lbfgs_curvature_tolerance;
	trainer.lbfgs_damping_threshold = lbfgs_damping_threshold;
	trainer.lbfgs_armijo_c1 = lbfgs_armijo_c1;
	trainer.lbfgs_initial_step = lbfgs_initial_step;
	trainer.lbfgs_step_growth = lbfgs_step_growth;
	trainer.radial_smooth_regularization = radial_smooth;
	trainer.radial_smooth_grid = radial_smooth_grid;
	trainer.scalar_head_l2_regularization = scalar_head_l2;
	trainer.gate_scalar_l2_regularization = gate_scalar_l2;
	trainer.gate_mix_l2_regularization = gate_mix_l2;
	trainer.gate_full_l2_regularization = gate_full_l2;
	trainer.gate_x_l2_regularization = gate_x_l2;
	trainer.guard_compression_floor_weight = guard_compression_options.floor_weight;
	trainer.guard_compression_monotonic_weight =
		guard_compression_options.monotonic_weight;
	trainer.guard_compression_curvature_weight =
		guard_compression_options.curvature_weight;
	trainer.guard_compression_block_monotonic_weight =
		guard_compression_options.block_monotonic_weight;
	trainer.guard_compression_floor_margin =
		guard_compression_options.floor_margin;
	trainer.guard_compression_monotonic_margin =
		guard_compression_options.monotonic_margin;
	trainer.guard_compression_curvature_margin =
		guard_compression_options.curvature_margin;
	trainer.guard_compression_smooth = guard_compression_options.smooth;
	trainer.fixed_atomic_energies = fixed_atomic_energies;
	trainer.fixed_atomic_energy_weight = fixed_atomic_energy_weight;
	trainer.force_loss_kind = force_loss_kind;
	trainer.force_log_cosh_scale = force_log_cosh_scale;

	if (prank == 0)
		std::cout << "SUS2.superlinear (2026-10-18)"
		          << " | potential from " << args[0]
		          << ", database: " << args[1] << std::endl;
	if (prank == 0 && inline_sh_model)
		std::cout << "SUS2-SH model topology was built from train command options" << std::endl;
	if (prank == 0 && custom_scal_range)
		std::cout << "scal-range override: " << scal_range.first << ", " << scal_range.second << std::endl;
	if (prank == 0 && custom_s_range)
		std::cout << "s-range override: " << s_range.first << ", " << s_range.second << std::endl;
	if (prank == 0 && plain_to_gate_upgrade) {
		std::cout << "SUS2-SH plain-to-gate upgrade enabled: "
		          << "gate_mode="
		          << (mtpr.TwoLayerGateUsesFullScalarWeights()
		              ? "mu-scalar-full"
		              : "mu-body-linear-combo")
		          << " gate_body_order=" << (mtpr.TwoLayerGateBodyOrderCount() + 1)
		          << " independent_gate_radial_coeffs="
		          << (plain_to_gate_independent_radial ? "true" : "false")
		          << " decoupled_gate_scaling="
		          << (mtpr.TwoLayerGateUsesDecoupledScaling() ? "true" : "false")
		          << " gate_weight_count=" << mtpr.TwoLayerGateWeightCount()
		          << " gate_radial_coeff_count=" << mtpr.TwoLayerGateRadialCoeffCount()
		          << " gate_scaling_coeff_count=" << mtpr.TwoLayerGateScalingCoeffCount()
		          << std::endl;
		if (plain_to_gate_disabled_controls)
			std::cout << "plain-to-gate upgrade disabled do-lin/do-lin-rescale/fine-tune"
			          << std::endl;
	}
	if (prank == 0 && edge_l1_gate_upgrade) {
		std::cout << "SUS2-SH two-layer gate edge-L1 upgrade enabled: "
		          << "source_moment_count="
		          << mtpr.TwoLayerGateEdgeL1SourceCount()
		          << " edge_l1_weight_count="
		          << mtpr.TwoLayerGateEdgeL1WeightCount()
		          << " initialized_weights=zero"
		          << std::endl;
	}
	if (prank == 0 && gate_readout_upgrade) {
		std::cout << "SUS2-SH gate scalar energy readout enabled: "
		          << "readout_coeff_count="
		          << mtpr.TwoLayerGateReadoutCoeffCount()
		          << " shared_center_prefactor=true"
		          << " initialized_coeffs=zero"
		          << std::endl;
	}
	if (prank == 0 && multi_layer_gate_upgrade) {
		std::cout << "SUS2-SH release3 multi-layer gate upgrade enabled: "
		          << "second_gate_mode="
		          << (mtpr.SecondLayerGateUsesFullScalarWeights()
		              ? "mu-scalar-full"
		              : "mu-body-linear-combo")
		          << " second_gate_body_order="
		          << (mtpr.SecondLayerGateBodyOrderCount() + 1)
		          << " second_gate_weight_count="
		          << mtpr.SecondLayerGateWeightCount()
		          << " second_gate_radial_coeff_count="
		          << mtpr.SecondLayerGateRadialCoeffCount()
		          << std::endl;
		if (multi_layer_gate_disabled_controls)
			std::cout << "multi-layer gate upgrade disabled do-lin/do-lin-rescale/fine-tune"
			          << std::endl;
	}
	if (prank == 0 && mtpr.TwoLayerGateEnabled())
		std::cout << "two-layer gate scale mode: additive-node" << std::endl;
	if (prank == 0 && mtpr.OuterUsesAdaptiveRadialCoefficients())
		std::cout << "radial-coefficient-gate: legacy gate-x L2 penalty disabled; "
		          << "gate_x_l2_regularization=0 and folded adaptive gate regularization should be used."
		          << std::endl;
		if (prank == 0)
		std::cout << "radial smoothness penalty: " << radial_smooth
		          << " grid=" << radial_smooth_grid << std::endl;
		if (prank == 0
		    && (scalar_weight_l2_preset != "none"
		        || scalar_head_l2 != 0.0
		        || gate_scalar_l2 != 0.0
		        || gate_mix_l2 != 0.0
		        || gate_full_l2 != 0.0)) {
			std::cout << "scalar weight L2 preset: " << scalar_weight_l2_preset
			          << " head=" << scalar_head_l2
			          << " gate_scalar=" << gate_scalar_l2
			          << " gate_mix=" << gate_mix_l2
			          << " gate_full=" << gate_full_l2
			          << std::endl;
		}
		if (prank == 0 && guard_compression_options.enabled) {
			std::cout << "guard-compression enabled:"
			          << " anchor=" << guard_compression_options.anchor
			          << " scales=";
			for (std::size_t i = 0; i < guard_compression_options.scales.size(); ++i) {
				if (i != 0)
					std::cout << ",";
				std::cout << guard_compression_options.scales[i];
			}
			std::cout << " floor_weight=" << guard_compression_options.floor_weight
			          << " monotonic_weight=" << guard_compression_options.monotonic_weight
			          << " curvature_weight=" << guard_compression_options.curvature_weight
			          << " block_monotonic_weight=" << guard_compression_options.block_monotonic_weight
			          << " floor_margin=" << guard_compression_options.floor_margin
			          << " monotonic_margin=" << guard_compression_options.monotonic_margin
			          << " curvature_margin=" << guard_compression_options.curvature_margin
			          << " smooth=" << guard_compression_options.smooth
			          << std::endl;
		}
		if (prank == 0 && !fixed_atomic_energies.empty()) {
			std::cout << "fixed atomic energies enabled:";
			for (double value : fixed_atomic_energies)
				std::cout << " " << value;
			std::cout << " penalty_weight=" << fixed_atomic_energy_weight << std::endl;
		}
	if (prank == 0 && fine_tune)
		std::cout << "fine-tune mode enabled: scal_coeffs frozen; initial rescale+linear solve will run before BFGS" << std::endl;
	if (prank == 0 && two_layer_residual_staged) {
		std::cout << "two-layer residual staged training enabled"
		          << " A=" << stage_a_steps
		          << " B=" << stage_b_steps
		          << " C=" << stage_c_steps << std::endl;
	}

	Configuration cfg;
	DatasetStats train_stats_local;
	DatasetStats valid_stats_local;
	if (validfnm != "")
	{
		try
		{
			valid_stats_local = LoadConfigsViaRank0Shards(validfnm, prank, psize, validSet, "valid");
			if (prank == 0)
				std::cout << "validation set: " << validfnm << std::endl;
		}
		catch (MlipException& exp)
		{
			std::cout << exp.What() << std::endl;
		}
	}

	for (int i = 0; i < end; i++)
	{
		try
		{
#ifdef MLIP_MPI
			MPI_Barrier(MPI_COMM_WORLD);
#endif
			training_set.clear();
			train_stats_local = AddConfigs(args[1], trainer, prank, psize);
			end = 1;
		}
		catch (MlipException& exp)
		{
			std::cout << exp.What() << std::endl;
			end = 10;
		}
	}
	long long train_cfg_total = train_stats_local.cfg_count;
	long long train_atom_total = train_stats_local.atom_count;
	long long valid_cfg_total = valid_stats_local.cfg_count;
	long long valid_atom_total = valid_stats_local.atom_count;
#ifdef MLIP_MPI
	long long train_cfg_local = train_stats_local.cfg_count;
	long long train_atom_local = train_stats_local.atom_count;
	long long valid_cfg_local = valid_stats_local.cfg_count;
	long long valid_atom_local = valid_stats_local.atom_count;
	MPI_Allreduce(&train_cfg_local, &train_cfg_total, 1, MPI_LONG_LONG_INT, MPI_SUM, MPI_COMM_WORLD);
	MPI_Allreduce(&train_atom_local, &train_atom_total, 1, MPI_LONG_LONG_INT, MPI_SUM, MPI_COMM_WORLD);
	MPI_Allreduce(&valid_cfg_local, &valid_cfg_total, 1, MPI_LONG_LONG_INT, MPI_SUM, MPI_COMM_WORLD);
	MPI_Allreduce(&valid_atom_local, &valid_atom_total, 1, MPI_LONG_LONG_INT, MPI_SUM, MPI_COMM_WORLD);
#endif
	GuardCompressionBuildResult guard_compression =
		BuildGuardCompressionSamplesFromFile(args[1],
		                                     guard_compression_options,
		                                     prank,
		                                     psize,
		                                     mtpr.CutOff());
	if (prank == 0 && guard_compression_options.enabled) {
		if (guard_compression.global_sample_count == 0) {
			std::cout << "[" << CurrentTimestamp() << "] guard-compression warning:"
			          << " no eligible anchor configurations were found"
			          << " for anchor=" << guard_compression_options.anchor
			          << std::endl;
		} else {
			std::cout << "[" << CurrentTimestamp() << "] guard-compression samples ready:"
			          << " groups=" << guard_compression.global_group_count
			          << " samples=" << guard_compression.global_sample_count
			          << " pairs=" << guard_compression.global_pair_count
			          << " triplets=" << guard_compression.global_triplet_count
			          << std::endl;
	}
	}
#ifdef MLIP_MPI
	trainer.ConfigureTrainComm(!training_set.empty()
	                           || !guard_compression.samples.empty(),
	                           prank,
	                           psize);
#endif
	std::size_t estimated_cache_bytes = 0;
	const bool cache_linear_neighborhoods = ShouldCacheNeighborhoods(training_set, mtpr.CutOff(), &estimated_cache_bytes);
	std::vector<Neighborhoods> linear_training_neighborhoods;
	const std::vector<Neighborhoods>* linear_training_neighborhoods_ptr = nullptr;
	if (cache_linear_neighborhoods) {
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] Building linear neighborhoods..."
			          << " estimated_bytes=" << estimated_cache_bytes
			          << " budget_bytes=" << kNeighborhoodCacheBudgetBytesPerRank
			          << std::endl;
#ifdef MLIP_MPI
		double nbh_build_start = MPI_Wtime();
#else
		double nbh_build_start = static_cast<double>(clock()) / CLOCKS_PER_SEC;
#endif
		const bool built_ok = TryBuildNeighborhoods(training_set, mtpr.CutOff(), linear_training_neighborhoods);
#ifdef MLIP_MPI
		double nbh_build_seconds = MPI_Wtime() - nbh_build_start;
		int built_local = built_ok ? 1 : 0;
		int built_global = 0;
		MPI_Allreduce(&built_local, &built_global, 1, MPI_INT, MPI_MIN, MPI_COMM_WORLD);
		double nbh_build_min = 0.0;
		double nbh_build_max = 0.0;
		MPI_Reduce(&nbh_build_seconds, &nbh_build_min, 1, MPI_DOUBLE, MPI_MIN, 0, MPI_COMM_WORLD);
		MPI_Reduce(&nbh_build_seconds, &nbh_build_max, 1, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
		MPI_Barrier(MPI_COMM_WORLD);
#else
		double nbh_build_seconds = static_cast<double>(clock()) / CLOCKS_PER_SEC - nbh_build_start;
		int built_global = built_ok ? 1 : 0;
		double nbh_build_min = nbh_build_seconds;
		double nbh_build_max = nbh_build_seconds;
#endif
		if (built_global) {
			linear_training_neighborhoods_ptr = &linear_training_neighborhoods;
			if (prank == 0)
				std::cout << "[" << CurrentTimestamp() << "] Linear neighborhoods ready"
				          << " build_s[min,max]=" << nbh_build_min << "," << nbh_build_max
				          << std::endl;
		} else if (prank == 0) {
			std::cout << "[" << CurrentTimestamp() << "] Linear neighborhood cache fallback"
			          << " build_s[min,max]=" << nbh_build_min << "," << nbh_build_max
			          << " reason=bad_alloc" << std::endl;
		}
	} else if (prank == 0) {
		std::cout << "[" << CurrentTimestamp() << "] Skipping full neighborhood cache"
		          << " estimated_bytes=" << estimated_cache_bytes
		          << " budget_bytes=" << kNeighborhoodCacheBudgetBytesPerRank
		          << std::endl;
	}

	bool zbl_training_residualized = false;
	if (maxits > 0 && mtpr.HasZBL() && mtpr.ZBLEvaluationEnabled()) {
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] Precomputing training-set ZBL residuals"
			          << " mode=" << (linear_training_neighborhoods_ptr == nullptr ? "zbl-neighborhoods" : "cached-main-neighborhoods")
			          << std::endl;
		ApplyZBLResidualToDataset(training_set, mtpr.ZBL(), true,
		                          linear_training_neighborhoods_ptr);
		mtpr.SetZBLEvaluationEnabled(false);
		zbl_training_residualized = true;
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] Training-set ZBL residuals ready; "
			          << "live ZBL evaluation disabled inside optimizer" << std::endl;
	}

	if (zbl_training_residualized && !guard_compression.samples.empty()) {
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] Applying ZBL residual convention to guard-compression floors"
			          << std::endl;
		ApplyZBLResidualToGuardSamples(
			guard_compression.samples,
			mtpr.ZBL(),
			guard_compression.neighborhoods.empty()
				? nullptr
				: &guard_compression.neighborhoods);
	}
	if (guard_compression_options.enabled
	    && guard_compression.global_sample_count > 0) {
		ReportGuardCompressionStatus(mtpr,
		                             guard_compression.samples,
		                             guard_compression.neighborhoods,
		                             guard_compression.anchor_pairs,
		                             guard_compression.pairs,
		                             guard_compression.anchor_triplets,
		                             guard_compression.triplets,
		                             guard_compression_options,
		                             "initial",
		                             prank);
		trainer.SetGuardCompressionSamples(
			guard_compression.samples,
			guard_compression.neighborhoods,
			guard_compression.anchor_pairs,
			guard_compression.pairs,
			guard_compression.anchor_triplets,
			guard_compression.triplets,
			guard_compression.global_sample_count,
			guard_compression.global_pair_count,
			guard_compression.global_triplet_count,
			static_cast<double>(std::max<long long>(1, train_cfg_total)));
	}

	int radial_first_coeff_repairs = 0;
	if (!two_layer_gate_readout_linear_init
	    && maxits > 0 && mtpr.has_radial_coeffs
	    && radial_parameterization == "physical") {
		if (loaded_complete_parameters
		    && allow_physical_radial_sign_repair
		    && required_radial_first_coeff_repairs > 0
		    && prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] "
			          << "Legacy physical radial sign repair explicitly enabled for complete checkpoint"
			          << std::endl;
		if (prank == 0)
			radial_first_coeff_repairs = mtpr.EnforcePositiveRadialFirstCoeffs();
#ifdef MLIP_MPI
		MPI_Bcast(&radial_first_coeff_repairs, 1, MPI_INT, 0, MPI_COMM_WORLD);
		MPI_Bcast(&mtpr.Coeff()[0], mtpr.CoeffCount(), MPI_DOUBLE, 0, MPI_COMM_WORLD);
#endif
		if (radial_first_coeff_repairs > 0) {
			if (prank == 0)
				std::cout << "[" << CurrentTimestamp() << "] "
				          << "Repaired " << radial_first_coeff_repairs
				          << " negative/zero radial first coefficients; running one linear solve"
				          << std::endl;
			if (trainer.TrainRankActive())
				trainer.TrainLinear(prank,
				                    training_set,
				                    linear_training_neighborhoods_ptr,
				                    "radial first-coeff sign repair");
			trainer.BroadcastCoeffsWorld();
		}
	}

        if (prank == 0) {std::cout <<"num_of_species: " <<mtpr.species_count  <<std::endl;
                         std::cout <<"training structures: " << train_cfg_total << std::endl;
                         std::cout <<"training atoms: " << train_atom_total << std::endl;
                         if (validfnm != "") {
                                std::cout <<"validation structures: " << valid_cfg_total << std::endl;
                                std::cout <<"validation atoms: " << valid_atom_total << std::endl;
                         }
                         std::cout <<"num_of_parameters: " <<mtpr.ActiveCoeffCount(fine_tune, trainable_groups)  <<std::endl;
                         if (!trainable_groups.empty())
                             std::cout << "trainable_groups: " << trainable_groups << std::endl;
                         std::cout <<"num_of_stored_coefficients: " <<mtpr.regression_coeffs.size()  <<std::endl;
                         std::cout <<"num_of_scalar_basis_functions: " <<mtpr.alpha_scalar_moments  <<std::endl;
						 std::cout << "num_of_L_channels: " << mtpr.L << std::endl;
						 std::cout << "num_of_scaling_channels:" << mtpr.K_ << std::endl;
						 std::cout << "scaling map:" <<  std::endl;
						 for (int i =0; i<mtpr.mu_to_K.size();i++)
						 {
							std::cout << mtpr.mu_to_K[i]<< "  " ;
						 }
						 std::cout << std::endl;

		                    }
	// Random initialization of nonlinear coefficients
	if (opts["init-params"] == "random" && !mtpr.inited) {
		if (prank == 0) {
			std::random_device rand_device;
			const std::mt19937_64::result_type seed = init_random_seed.has_value
				? init_random_seed.value
				: static_cast<std::mt19937_64::result_type>(rand_device());
			std::mt19937_64 generator(seed);

			std::cout << "Random initialization of nonlinear coefficients"
			          << " seed=" << seed << std::endl;
			mtpr.RandomizeNonlinearCoeffs(generator, 5e-3, true, 0.12);
			if (radial_mixing_init_scale > 0.0
			    || (mtpr.OuterUsesPureRadialMatrix() && custom_radial_mixing_init_scale)) {
				if (!mtpr.TwoLayerGateRadialMixingEnabled())
					ERROR("--two-layer-gate-radial-mixing-init-scale requires "
					      "--two-layer-gate-radial-mixing=full");
				mtpr.RandomizeTwoLayerGateRadialMixingCoeffs(
					generator, radial_mixing_init_scale);
			}
			if (mtpr.OuterUsesPureRadialMatrix())
				std::cout << "Pure-W random initialization: independent gate rows and physical W; "
				          << "unused R unchanged, W scale="
				          << (custom_radial_mixing_init_scale ? radial_mixing_init_scale : 5e-3)
				          << std::endl;
		}
    //     if (prank == 0) {std::cout << mtpr.regression_coeffs[mtpr.radial_func_count*( mtpr.Get_RB_size() + mtpr.species_count)-4] << std::endl;}
#ifdef MLIP_MPI
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] Random init coeff broadcast start" << std::endl;
		MPI_Bcast(&mtpr.Coeff()[0], mtpr.CoeffCount(), MPI_DOUBLE, 0, MPI_COMM_WORLD);
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] Random init coeff broadcast done" << std::endl;
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] Random init barrier start" << std::endl;
                MPI_Barrier(MPI_COMM_WORLD);
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] Random init barrier done" << std::endl;
#endif
		mtpr.SyncTwoLayerGateRadialMixingCoeffsFromRegression();
	}
	if (maxits == 0 && init_random_seed.has_value
	    && opts["init-params"] == "random" && !loaded_complete_parameters) {
		save_model_atomically_collective(
			trained_fnm, "deterministic fresh initialized model");
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] "
			          << "Deterministic fresh initialized model saved to "
			          << trained_fnm << std::endl;
	}
	if (!balanced_pure_w_init && maxits == 0 && opts["init-params"] == "same"
	    && mtpr.OuterUsesPureRadialMatrix()) {
		// Initialization-only pure-W runs export the supplied physical seed,
		// before shift, linear warmup, rescaling or optimizer setup can change it.
		save_model_atomically_collective(trained_fnm, "pure-W same initial model");
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] "
			          << "Pure-W same initial snapshot saved to " << trained_fnm
			          << " (no parameter reset or linear solve)" << std::endl;
		}
		trainer.shift(do_shift);
		if (balanced_adaptive_radial_init) {
			const std::uint64_t seed = init_random_seed.has_value
				? static_cast<std::uint64_t>(init_random_seed.value) : UINT64_C(1);
			if (prank == 0)
				std::cout << "[" << CurrentTimestamp() << "] "
				          << "Adaptive radial balanced initialization start"
				          << " seed=" << seed
				          << " relative_rms=" << adaptive_radial_init_relative_rms
				          << std::endl;
			mtpr.InitializeAdaptiveRadialFromData(
				training_set,
				linear_training_neighborhoods_ptr,
				adaptive_radial_init_relative_rms,
				static_cast<unsigned>(seed));
			if (adaptive_pytorch_profile)
				trainer.PrepareAdaptivePytorchTraining(
					training_set, linear_training_neighborhoods_ptr, true,
					static_cast<unsigned>(seed));
#ifdef MLIP_MPI
			MPI_Bcast(&mtpr.Coeff()[0], mtpr.CoeffCount(), MPI_DOUBLE, 0, MPI_COMM_WORLD);
#endif
			if (!adaptive_pytorch_profile && trainer.TrainRankActive())
				trainer.TrainLinear(prank, training_set, linear_training_neighborhoods_ptr,
				                    "balanced adaptive radial initial head solve");
			trainer.BroadcastCoeffsWorld();
			if (prank == 0)
				std::cout << "[" << CurrentTimestamp() << "] "
				          << "Adaptive radial balanced initialization complete; "
				          << "no Rescale or 75-step pretraining"
				          << std::endl;
			save_model_atomically_collective(
				maxits == 0 ? trained_fnm : "ini.sus2",
				"balanced adaptive radial initialized model");
		}
		if (adaptive_pytorch_profile && loaded_complete_parameters) {
			trainer.PrepareAdaptivePytorchTraining(
				training_set, linear_training_neighborhoods_ptr, false, 1);
			if (maxits == 0)
				save_model_atomically_collective(trained_fnm, "unchanged adaptive physical checkpoint");
		}
		if (balanced_pure_w_init) {
		// A new initialization protocol, never a checkpoint conversion. All
		// changes are folded into physical W; prediction needs no new metadata.
		const std::uint64_t seed = init_random_seed.has_value
			? static_cast<std::uint64_t>(init_random_seed.value) : UINT64_C(1);
		mtpr.InitializePureWDirections(seed);
#ifdef MLIP_MPI
		MPI_Bcast(&mtpr.Coeff()[0], mtpr.CoeffCount(), MPI_DOUBLE, 0, MPI_COMM_WORLD);
#endif
		mtpr.SyncTwoLayerGateRadialMixingCoeffsFromRegression();
		std::vector<double> local_second_moments(mtpr.L * mtpr.OuterKRank(), 0.0);
		std::vector<double> global_second_moments(local_second_moments.size(), 0.0);
		std::uint64_t local_sites = 0;
		int statistics_failed = 0;
		try {
			for (Configuration& config : training_set)
				mtpr.AccumulatePureWOuterBlockSecondMoments(
					config, local_second_moments, local_sites);
		} catch (const MlipException& exception) {
			std::cerr << "Pure-W initialization statistics rank=" << prank
			          << ": " << exception.What() << std::endl;
			statistics_failed = 1;
		} catch (const std::exception& exception) {
			std::cerr << "Pure-W initialization statistics rank=" << prank
			          << ": " << exception.what() << std::endl;
			statistics_failed = 1;
		}
		unsigned long long global_sites = static_cast<unsigned long long>(local_sites);
#ifdef MLIP_MPI
		int any_failed = 0;
		MPI_Allreduce(&statistics_failed, &any_failed, 1, MPI_INT, MPI_MAX, MPI_COMM_WORLD);
		statistics_failed = any_failed;
		const unsigned long long site_count = static_cast<unsigned long long>(local_sites);
		MPI_Allreduce(&site_count, &global_sites, 1, MPI_UNSIGNED_LONG_LONG, MPI_SUM, MPI_COMM_WORLD);
		MPI_Allreduce(local_second_moments.data(), global_second_moments.data(),
		              static_cast<int>(local_second_moments.size()), MPI_DOUBLE, MPI_SUM, MPI_COMM_WORLD);
#else
		global_second_moments = local_second_moments;
#endif
		if (statistics_failed || global_sites == 0)
			ERROR("Balanced pure-W initialization needs finite outer moments and a nonempty training set");
		std::vector<double> factors(global_second_moments.size(), 1.0);
		if (prank == 0)
			std::cout << std::setprecision(17)
			          << "Pure-W balanced initialization seed=" << seed
			          << " target_rms=" << pure_w_init_target_rms
			          << " sites=" << global_sites << std::endl;
		for (std::size_t block = 0; block < factors.size(); ++block) {
			const double second_moment = global_second_moments[block]
				/ static_cast<double>(global_sites);
			if (!std::isfinite(second_moment) || second_moment < 0.0)
				ERROR("Balanced pure-W initialization encountered non-finite outer moments");
			const double rms = std::sqrt(second_moment);
			const char* status = "scaled";
			if (rms <= 1.0e-12) {
				status = "near-zero-preserved";
			} else {
				const double requested = pure_w_init_target_rms / rms;
				factors[block] = std::max(1.0e-6, std::min(1.0e6, requested));
				if (factors[block] != requested)
					status = "clamped";
			}
			if (prank == 0)
				std::cout << "Pure-W init block l=" << block / mtpr.OuterKRank()
				          << " o=" << block % mtpr.OuterKRank()
				          << " rms_before=" << rms << " factor=" << factors[block]
				          << " rms_after=" << rms * factors[block]
				          << " status=" << status << std::endl;
		}
#ifdef MLIP_MPI
		MPI_Bcast(factors.data(), static_cast<int>(factors.size()), MPI_DOUBLE, 0, MPI_COMM_WORLD);
#endif
		mtpr.ApplyPureWOutputScales(factors);
		if (trainer.TrainRankActive())
			trainer.TrainLinear(prank, training_set, linear_training_neighborhoods_ptr,
			                    "balanced pure-W initial head solve");
		trainer.BroadcastCoeffsWorld();
		if (pure_w_head_solve == "full-quadratic") {
			if (trainer.TrainRankActive())
				trainer.TrainScalarHeadFullQuadratic(
					training_set,
					linear_training_neighborhoods_ptr,
					"balanced pure-W full conditional head solve");
			trainer.BroadcastCoeffsWorld();
		}
		if (prank == 0)
			std::cout << "Pure-W balanced initialization complete; physical global scaling="
			          << mtpr.scaling
			          << "; head_solve=" << pure_w_head_solve
			          << "; no Rescale or 75-step pretraining" << std::endl;
		save_model_atomically_collective(
			maxits == 0 ? trained_fnm : "ini.sus2", "balanced pure-W initialized model");
	}
	if (two_layer_gate_readout_linear_init) {
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] "
			          << "Readout-only residual linear initialization start"
			          << " readout_coeff_count="
			          << mtpr.TwoLayerGateReadoutCoeffCount()
			          << " fixed_nonreadout_coeffs=true"
			          << " rescale=false"
			          << std::endl;
		if (trainer.TrainRankActive())
			trainer.TrainLinear(
				prank,
				training_set,
				linear_training_neighborhoods_ptr,
				"readout-only residual initialization",
				true);
		trainer.BroadcastCoeffsWorld();
		if (prank == 0) {
			std::cout << "[" << CurrentTimestamp() << "] "
			          << "Readout-only residual linear initialization done"
			          << std::endl;
		}
		if (maxits == 0) {
			save_model_atomically_collective(
				trained_fnm, "readout-only initialized model");
			if (prank == 0)
				std::cout << "[" << CurrentTimestamp() << "] "
				          << "Readout-only initialized model saved to "
				          << trained_fnm << std::endl;
		}
		}
		const bool run_initial_untrained_linear_warmup =
			!balanced_pure_w_init && !balanced_adaptive_radial_init
			&& !loaded_complete_parameters && maxits > 0 && !two_layer_residual_staged;
	if (run_initial_untrained_linear_warmup) {
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] "
			          << "Initial untrained model warmup Rescale start"
			          << std::endl;
		if (trainer.TrainRankActive())
			Rescale(trainer, mtpr, linear_training_neighborhoods_ptr);
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] "
			          << "Initial untrained model warmup linear solve start"
			          << std::endl;
		if (trainer.TrainRankActive())
			trainer.TrainLinear(prank,
			                    training_set,
			                    linear_training_neighborhoods_ptr,
			                    "initial untrained model warmup");
		trainer.BroadcastCoeffsWorld();
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] "
			          << "Initial untrained model warmup rescale+linear solve done"
			          << std::endl;
	}
		if (!balanced_pure_w_init && !balanced_adaptive_radial_init
		    && !mtpr.inited && maxits > 0 && !skip_preinit && !two_layer_residual_staged) {
		trainer.max_step_count = 75;
//		trainer.random_sample(prank, training_set);
//		if (prank == 0){
//		                        mtpr.Save(trained_fnm);
//		                                                mtpr.Save_2("unfixed1.sus2");
//		                                                                  
//
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp()
			          << "] Saving ini.sus2 start" << std::endl;
		save_model_atomically_collective("ini.sus2", "initial model");
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp()
			          << "] Saving ini.sus2 done" << std::endl;

	       if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] Entering Rescale" << std::endl;
               if (trainer.TrainRankActive())
	               Rescale(trainer, mtpr, linear_training_neighborhoods_ptr);
               if (do_sample && trainer.TrainRankActive()){
	               trainer.random_sample(prank, training_set, 10, linear_training_neighborhoods_ptr);
               }
		if (prank == 0)
			std::cout << "Pre-training started" << std::endl;

		if (trainer.TrainRankActive())
			trainer.Train(training_set);
		trainer.BroadcastCoeffsWorld();

		
                //trainer.random_sample(prank, training_set, 20);
		if (prank == 0)
			std::cout << "Pre-training ended" << std::endl;
	}

	if (fine_tune && maxits > 0) {
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] Fine-tune initial Rescale start" << std::endl;
		if (trainer.TrainRankActive())
			Rescale(trainer, mtpr, linear_training_neighborhoods_ptr);
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] Fine-tune initial linear solve start" << std::endl;
		if (trainer.TrainRankActive())
			trainer.TrainLinear(prank,
			                    training_set,
			                    linear_training_neighborhoods_ptr,
			                    "fine-tune initial linear solve");
		trainer.BroadcastCoeffsWorld();
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] Fine-tune initial rescale+linear solve done" << std::endl;
	}

	//getting the lowest min_dist for the training setZ
	double min_dist = 999;
	for (int i = 0; i < training_set.size(); i++) {
		if (training_set[i].MinDist() < min_dist)
			min_dist = training_set[i].MinDist();
	}

	double total_min_dist = min_dist;

	//finding minimum distance in configuration among the processes
#ifdef MLIP_MPI
	MPI_Barrier(MPI_COMM_WORLD);
	MPI_Allreduce(&min_dist, &total_min_dist, 1, MPI_DOUBLE, MPI_MIN, MPI_COMM_WORLD);
#endif

	if (mindist_update) {
		if (prank == 0)
		{
			std::cout << "Found configuration with mindist=" << total_min_dist << ", MTP's mindist will be decreased\n";
		}
		mtpr.p_RadialBasis->min_dist = 0.99 * total_min_dist;
	}

	trainer.max_step_count = maxits;				//maximum step count (linesearch doesn't count)

	if (maxits > 0) {
		if (prank == 0) {
			std::cout << "Modified by Hu Yanxiao. " << std::endl;
			std::cout << "Optimizer: " << trainer.optimizer_kind << std::endl;
			std::cout << "Optimizer iterations count set to " << trainer.max_step_count << std::endl;
			std::cout << "Optimizer convergence tolerance set to " << bfgs_conv_tol << std::endl;
			std::cout << "Optimizer line search: " << trainer.bfgs_line_search << std::endl;
			std::cout << "Radial parameterization: "
			          << trainer.radial_parameterization << std::endl;
			std::cout << "BFGS coordinate normalization: "
			          << trainer.bfgs_coordinate_normalization;
			if (trainer.bfgs_coordinate_normalization != "none") {
				if (trainer.bfgs_coordinate_normalization == "efs-gn")
					std::cout << " probes=" << trainer.bfgs_coordinate_probes;
				std::cout << " floor=" << trainer.bfgs_coordinate_floor;
			}
			std::cout << std::endl;
			if (trainer.optimizer_kind == "lbfgs") {
				std::cout << "L-BFGS settings: history=" << trainer.lbfgs_history_size
				          << " curvature_tol=" << trainer.lbfgs_curvature_tolerance
				          << " damping=" << trainer.lbfgs_damping_threshold
				          << " armijo_c1=" << trainer.lbfgs_armijo_c1
				          << " initial_step=" << trainer.lbfgs_initial_step
				          << " step_growth=" << trainer.lbfgs_step_growth
				          << std::endl;
			}
			if (trainer.do_lin) {
				std::cout << "do-lin enabled for first " << trainer.do_lin_step_limit
				          << " optimizer steps, frequency " << trainer.do_lin_frequency << std::endl;
				std::cout << "do-lin-rescale "
				          << (trainer.do_lin_rescale ? "enabled" : "disabled")
				          << std::endl;
			} else {
				std::cout << "do-lin disabled" << std::endl;
			}
                       
			if ((weight_energy != 0) || (weight_force != 0) || (weight_stress != 0)) {
				std::cout << "Energy weight: " << weight_energy << std::endl;
				std::cout << "Force weight: " << weight_force << std::endl;
				std::cout << "Force loss: " << ForceLossKindName(trainer.force_loss_kind);
				if (trainer.force_loss_kind == ForceLossKind::LogCosh)
					std::cout << " scale=" << trainer.force_log_cosh_scale;
				std::cout << std::endl;
				std::cout << "Stress weight: " << weight_stress << std::endl;
				std::cout << "std weight: " << trainer.std_scaling << std::endl;
                                std::cout << "center_std weight: " << trainer.stdd_scaling << std::endl;
			}
		}
                //trainer.std_scaling /= 10000 ;
	//        trainer.random_sample(prank, training_set);
//          	Rescale(trainer, mtpr);
		bool f = true;
		trainer.shift(f);
		if (two_layer_residual_staged) {
			auto run_residual_stage = [&](const char* label,
			                              int stage,
			                              int steps,
			                              const char* solve_context,
			                              bool run_linear_solve) {
				if (steps <= 0)
					return;
				trainer.two_layer_residual_stage = stage;
				trainer.max_step_count = steps;
				if (prank == 0) {
					std::cout << "[" << CurrentTimestamp() << "] "
					          << "Residual two-layer staged training: stage "
					          << label
					          << " steps=" << steps << std::endl;
				}
				if (run_linear_solve && trainer.TrainRankActive())
					trainer.TrainLinear(prank,
					                    training_set,
					                    linear_training_neighborhoods_ptr,
					                    solve_context);
				trainer.BroadcastCoeffsWorld();
				const bool saved_do_lin = trainer.do_lin;
				const bool saved_do_lin_rescale = trainer.do_lin_rescale;
				const int saved_do_lin_step_limit = trainer.do_lin_step_limit;
				trainer.do_lin = false;
				trainer.do_lin_rescale = false;
				trainer.do_lin_step_limit = 0;
				if (trainer.TrainRankActive())
					trainer.Train(training_set);
				trainer.BroadcastCoeffsWorld();
				trainer.do_lin = saved_do_lin;
				trainer.do_lin_rescale = saved_do_lin_rescale;
				trainer.do_lin_step_limit = saved_do_lin_step_limit;
			};
			run_residual_stage("A", MTPR_trainer::kResidualStageE0,
			                   stage_a_steps, "residual stage A E0 solve", true);
			run_residual_stage("B", MTPR_trainer::kResidualStageE1,
			                   stage_b_steps, "residual stage B E1 residual solve", true);
			run_residual_stage("C", MTPR_trainer::kResidualStageFull,
			                   stage_c_steps, "residual stage C BFGS refine", false);
			trainer.two_layer_residual_stage = MTPR_trainer::kResidualStageFull;
			trainer.max_step_count = maxits;
			} else {
				if (trainer.TrainRankActive())
					trainer.Train(training_set);
				trainer.BroadcastCoeffsWorld();
			}
			if (guard_compression_options.enabled
			    && guard_compression.global_sample_count > 0) {
				ReportGuardCompressionStatus(mtpr,
				                             guard_compression.samples,
				                             guard_compression.neighborhoods,
				                             guard_compression.anchor_pairs,
				                             guard_compression.pairs,
				                             guard_compression.anchor_triplets,
				                             guard_compression.triplets,
				                             guard_compression_options,
				                             "final",
				                             prank);
			}
			//string train_name = "pp.sus2";
//		if (prank == 0)
//			mtpr.Save("loop_1.sus2");
//		if (prank == 0) {std::cout << "loop_2 start:" << std::endl;}
//		//trainer.std_scaling *= 10 ;
//		trainer.TrainLinear(prank, training_set);
//		Rescale(trainer, mtpr);
 //               trainer.Train(training_set);
  //              if (prank == 0) {mtpr.Save("loop_2.sus2");}
//                        
//                if (prank == 0) {std::cout << "loop_3 start:" << std::endl;}
//                //trainer.std_scaling *= 10 ;
//                trainer.TrainLinear(prank, training_set);
//                Rescale(trainer, mtpr);
//                trainer.Train(training_set);
//                if (prank == 0) {mtpr.Save("loop_3.sus2");}
//                if (prank == 0) {std::cout << "loop_4 start:" << std::endl;}
                //trainer.std_scaling *= 100 ;
//                trainer.TrainLinear(prank, training_set);
 //               Rescale(trainer, mtpr);
  //              trainer.Train(training_set);
   //             if (prank == 0) {mtpr.Save("loop_4.sus2");}

		save_model_atomically_collective(trained_fnm, "final trained model");
     //                   mtpr.Save_2("unfixed1.sus2");
     //           Rescale(trainer, mtpr);
     //           if (prank==0){ mtpr.Save_2("unfixed2.sus2");
      //                 }
	}
	if (zbl_training_residualized) {
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] Restoring training-set ZBL references"
			          << std::endl;
		ApplyZBLResidualToDataset(training_set, mtpr.ZBL(), false,
		                          linear_training_neighborhoods_ptr);
		mtpr.SetZBLEvaluationEnabled(true);
		if (prank == 0)
			std::cout << "[" << CurrentTimestamp() << "] Training references restored; "
			          << "live ZBL evaluation enabled for final reporting" << std::endl;
	}
	ErrorMonitor errmon, bufferrmon;
	std::cout.precision(15);
	bool have_train_summary = trainer.HasLastTrainErrorSummary() &&
	                          !zbl_training_residualized;
	MTPR_trainer::TrainErrorSummary train_summary;
	if (have_train_summary)
		train_summary = trainer.LastTrainErrorSummary();
#ifdef MLIP_MPI
	int have_train_summary_int = have_train_summary ? 1 : 0;
	MPI_Bcast(&have_train_summary_int, 1, MPI_INT, 0, MPI_COMM_WORLD);
	have_train_summary = (have_train_summary_int != 0);
	if (have_train_summary) {
		double train_summary_values[6];
		if (prank == 0) {
			train_summary_values[0] = train_summary.energy_mae_mev_atom;
			train_summary_values[1] = train_summary.energy_rmse_mev_atom;
			train_summary_values[2] = train_summary.force_mae_mev_a;
			train_summary_values[3] = train_summary.force_rmse_mev_a;
			train_summary_values[4] = train_summary.stress_mae_ev;
			train_summary_values[5] = train_summary.stress_rmse_ev;
		}
		MPI_Bcast(train_summary_values, 6, MPI_DOUBLE, 0, MPI_COMM_WORLD);
		train_summary.energy_mae_mev_atom = train_summary_values[0];
		train_summary.energy_rmse_mev_atom = train_summary_values[1];
		train_summary.force_mae_mev_a = train_summary_values[2];
		train_summary.force_rmse_mev_a = train_summary_values[3];
		train_summary.stress_mae_ev = train_summary_values[4];
		train_summary.stress_rmse_ev = train_summary_values[5];
	}
#endif
	if (have_train_summary) {
		if (prank == 0) {
			std::cout << "\n=== Train Summary ===\n"
			          << std::fixed << std::setprecision(3)
			          << "Structures           : " << train_cfg_total << "\n"
			          << "Atoms                : " << train_atom_total << "\n"
			          << "Energy MAE (meV/atom): " << train_summary.energy_mae_mev_atom << "\n"
			          << "Energy RMSE(meV/atom): " << train_summary.energy_rmse_mev_atom << "\n"
			          << "Force MAE  (meV/A)   : " << train_summary.force_mae_mev_a << "\n"
			          << "Force RMSE (meV/A)   : " << train_summary.force_rmse_mev_a << "\n"
			          << "Stress MAE (eV)      : " << train_summary.stress_mae_ev << "\n"
			          << "Stress RMSE(eV)      : " << train_summary.stress_rmse_ev << "\n"
			          << "=====================\n";
		}
	} else {
		errmon.reset();
		double train_energy_abs_sum = 0.0;
		double train_energy_sq_weighted_sum = 0.0;
		double train_force_abs_component_sum = 0.0;
		double train_force_sq_component_sum = 0.0;
		double train_stress_abs_component_sum = 0.0;
		double train_stress_sq_component_sum = 0.0;
		long long train_force_component_count = 0;
		long long train_stress_component_count = 0;

		for (Configuration& cfg_orig : training_set)
		{
			cfg = cfg_orig;
			mtpr.CalcEFS(cfg);
			errmon.collect(cfg_orig, cfg);
			if (cfg_orig.has_energy() && cfg.has_energy())
			{
				const double dE = cfg_orig.energy - cfg.energy;
				train_energy_abs_sum += std::abs(dE);
				train_energy_sq_weighted_sum += dE * dE / cfg.size();
			}
			if (cfg_orig.has_forces() && cfg.has_forces()) {
				for (int i = 0; i < cfg.size(); i++)
					for (int a = 0; a < 3; a++)
					{
						const double dF = cfg.force(i)[a] - cfg_orig.force(i)[a];
						train_force_abs_component_sum += std::abs(dF);
						train_force_sq_component_sum += dF * dF;
					}
				train_force_component_count += static_cast<long long>(3) * cfg.size();
			}
			if (cfg_orig.has_stresses() && cfg.has_stresses()) {
				const double d0 = cfg.stresses[0][0] - cfg_orig.stresses[0][0];
				const double d1 = cfg.stresses[1][1] - cfg_orig.stresses[1][1];
				const double d2 = cfg.stresses[2][2] - cfg_orig.stresses[2][2];
				const double d3 = cfg.stresses[1][2] - cfg_orig.stresses[1][2];
				const double d4 = cfg.stresses[0][2] - cfg_orig.stresses[0][2];
				const double d5 = cfg.stresses[0][1] - cfg_orig.stresses[0][1];
				train_stress_abs_component_sum += std::abs(d0) + std::abs(d1) + std::abs(d2) +
				                                  std::abs(d3) + std::abs(d4) + std::abs(d5);
				train_stress_sq_component_sum += d0*d0 + d1*d1 + d2*d2 + d3*d3 + d4*d4 + d5*d5;
				train_stress_component_count += 6;
			}

		}
		bufferrmon.reset();
#ifdef MLIP_MPI
		MPI_Barrier(MPI_COMM_WORLD);
		MPI_Reduce(&errmon.ene_all.max, &bufferrmon.ene_all.max, 5, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.ene_all.sum, &bufferrmon.ene_all.sum, 5, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.epa_all.max, &bufferrmon.epa_all.max, 5, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.epa_all.sum, &bufferrmon.epa_all.sum, 5, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.frc_all.max, &bufferrmon.frc_all.max, 5, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.frc_all.sum, &bufferrmon.frc_all.sum, 5, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.ene_all.count, &bufferrmon.ene_all.count, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.epa_all.count, &bufferrmon.epa_all.count, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.frc_all.count, &bufferrmon.frc_all.count, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.str_all.count, &bufferrmon.str_all.count, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.str_all.max, &bufferrmon.str_all.max, 5, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.str_all.sum, &bufferrmon.str_all.sum, 5, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.vir_all.count, &bufferrmon.vir_all.count, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.vir_all.max, &bufferrmon.vir_all.max, 5, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.vir_all.sum, &bufferrmon.vir_all.sum, 5, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		double train_energy_abs_sum_global = 0.0;
		double train_energy_sq_weighted_sum_global = 0.0;
		double train_force_abs_component_sum_global = 0.0;
		double train_force_sq_component_sum_global = 0.0;
		double train_stress_abs_component_sum_global = 0.0;
		double train_stress_sq_component_sum_global = 0.0;
		long long train_force_component_count_global = 0;
		long long train_stress_component_count_global = 0;
		MPI_Reduce(&train_energy_abs_sum, &train_energy_abs_sum_global, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&train_energy_sq_weighted_sum, &train_energy_sq_weighted_sum_global, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&train_force_abs_component_sum, &train_force_abs_component_sum_global, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&train_force_sq_component_sum, &train_force_sq_component_sum_global, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&train_stress_abs_component_sum, &train_stress_abs_component_sum_global, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&train_stress_sq_component_sum, &train_stress_sq_component_sum_global, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&train_force_component_count, &train_force_component_count_global, 1, MPI_LONG_LONG_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&train_stress_component_count, &train_stress_component_count_global, 1, MPI_LONG_LONG_INT, MPI_SUM, 0, MPI_COMM_WORLD);
			if (prank == 0)
			{
				const double train_energy_mae_mev_atom =
					train_atom_total > 0 ? 1000.0 * train_energy_abs_sum_global / static_cast<double>(train_atom_total) : 0.0;
				const double train_energy_rmse_mev_atom =
					train_atom_total > 0 ? 1000.0 * std::sqrt(train_energy_sq_weighted_sum_global / static_cast<double>(train_atom_total)) : 0.0;
				const double train_force_mae_mev_a =
					train_force_component_count_global > 0 ? 1000.0 * train_force_abs_component_sum_global / static_cast<double>(train_force_component_count_global) : 0.0;
				const double train_force_rmse_mev_a =
					train_force_component_count_global > 0 ? 1000.0 * std::sqrt(train_force_sq_component_sum_global / static_cast<double>(train_force_component_count_global)) : 0.0;
				const double train_stress_mae_ev =
					train_stress_component_count_global > 0 ? train_stress_abs_component_sum_global / static_cast<double>(train_stress_component_count_global) : 0.0;
				const double train_stress_rmse_ev =
					train_stress_component_count_global > 0 ? std::sqrt(train_stress_sq_component_sum_global / static_cast<double>(train_stress_component_count_global)) : 0.0;
				std::cout << "\n=== Train Summary ===\n"
				          << std::fixed << std::setprecision(3)
				          << "Structures           : " << train_cfg_total << "\n"
				          << "Atoms                : " << train_atom_total << "\n"
				          << "Energy MAE (meV/atom): " << train_energy_mae_mev_atom << "\n"
				          << "Energy RMSE(meV/atom): " << train_energy_rmse_mev_atom << "\n"
				          << "Force MAE  (meV/A)   : " << train_force_mae_mev_a << "\n"
				          << "Force RMSE (meV/A)   : " << train_force_rmse_mev_a << "\n"
				          << "Stress MAE (eV)      : " << train_stress_mae_ev << "\n"
				          << "Stress RMSE(eV)      : " << train_stress_rmse_ev << "\n"
				          << "=====================\n";
			}

#else
		const double train_energy_mae_mev_atom =
			train_atom_total > 0 ? 1000.0 * train_energy_abs_sum / static_cast<double>(train_atom_total) : 0.0;
		const double train_energy_rmse_mev_atom =
			train_atom_total > 0 ? 1000.0 * std::sqrt(train_energy_sq_weighted_sum / static_cast<double>(train_atom_total)) : 0.0;
		const double train_force_mae_mev_a =
			train_force_component_count > 0 ? 1000.0 * train_force_abs_component_sum / static_cast<double>(train_force_component_count) : 0.0;
		const double train_force_rmse_mev_a =
			train_force_component_count > 0 ? 1000.0 * std::sqrt(train_force_sq_component_sum / static_cast<double>(train_force_component_count)) : 0.0;
		const double train_stress_mae_ev =
			train_stress_component_count > 0 ? train_stress_abs_component_sum / static_cast<double>(train_stress_component_count) : 0.0;
		const double train_stress_rmse_ev =
			train_stress_component_count > 0 ? std::sqrt(train_stress_sq_component_sum / static_cast<double>(train_stress_component_count)) : 0.0;
		std::cout << "\n=== Train Summary ===\n"
		          << std::fixed << std::setprecision(3)
		          << "Structures           : " << train_cfg_total << "\n"
		          << "Atoms                : " << train_atom_total << "\n"
		          << "Energy MAE (meV/atom): " << train_energy_mae_mev_atom << "\n"
		          << "Energy RMSE(meV/atom): " << train_energy_rmse_mev_atom << "\n"
		          << "Force MAE  (meV/A)   : " << train_force_mae_mev_a << "\n"
		          << "Force RMSE (meV/A)   : " << train_force_rmse_mev_a << "\n"
		          << "Stress MAE (eV)      : " << train_stress_mae_ev << "\n"
		          << "Stress RMSE(eV)      : " << train_stress_rmse_ev << "\n"
		          << "=====================\n";
#endif
	}

	errmon.reset();
	bufferrmon.reset();
#ifdef MLIP_MPI
	MPI_Barrier(MPI_COMM_WORLD);
#endif

	if (validfnm != "")
	{
		double valid_energy_abs_sum = 0.0;
		double valid_energy_sq_weighted_sum = 0.0;
		double valid_force_abs_component_sum = 0.0;
		double valid_force_sq_component_sum = 0.0;
		double valid_stress_abs_component_sum = 0.0;
		double valid_stress_sq_component_sum = 0.0;
		long long valid_force_component_count = 0;
		long long valid_stress_component_count = 0;
		for (Configuration& cfg_orig : validSet)
		{
			cfg = cfg_orig;
			mtpr.CalcEFS(cfg);
			errmon.collect(cfg_orig, cfg);
			if (cfg_orig.has_energy() && cfg.has_energy())
			{
				const double dE = cfg_orig.energy - cfg.energy;
				valid_energy_abs_sum += std::abs(dE);
				valid_energy_sq_weighted_sum += dE * dE / cfg.size();
			}
			if (cfg_orig.has_forces() && cfg.has_forces()) {
				for (int i = 0; i < cfg.size(); i++)
					for (int a = 0; a < 3; a++)
					{
						const double dF = cfg.force(i)[a] - cfg_orig.force(i)[a];
						valid_force_abs_component_sum += std::abs(dF);
						valid_force_sq_component_sum += dF * dF;
					}
				valid_force_component_count += static_cast<long long>(3) * cfg.size();
			}
			if (cfg_orig.has_stresses() && cfg.has_stresses()) {
				const double d0 = cfg.stresses[0][0] - cfg_orig.stresses[0][0];
				const double d1 = cfg.stresses[1][1] - cfg_orig.stresses[1][1];
				const double d2 = cfg.stresses[2][2] - cfg_orig.stresses[2][2];
				const double d3 = cfg.stresses[1][2] - cfg_orig.stresses[1][2];
				const double d4 = cfg.stresses[0][2] - cfg_orig.stresses[0][2];
				const double d5 = cfg.stresses[0][1] - cfg_orig.stresses[0][1];
				valid_stress_abs_component_sum += std::abs(d0) + std::abs(d1) + std::abs(d2) +
				                                  std::abs(d3) + std::abs(d4) + std::abs(d5);
				valid_stress_sq_component_sum += d0*d0 + d1*d1 + d2*d2 + d3*d3 + d4*d4 + d5*d5;
				valid_stress_component_count += 6;
			}
		}
		bufferrmon.reset();
#ifdef MLIP_MPI
		MPI_Barrier(MPI_COMM_WORLD);
		MPI_Reduce(&errmon.ene_all.max, &bufferrmon.ene_all.max, 5, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.ene_all.sum, &bufferrmon.ene_all.sum, 5, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.epa_all.max, &bufferrmon.epa_all.max, 5, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.epa_all.sum, &bufferrmon.epa_all.sum, 5, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.frc_all.max, &bufferrmon.frc_all.max, 5, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.frc_all.sum, &bufferrmon.frc_all.sum, 5, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.ene_all.count, &bufferrmon.ene_all.count, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.epa_all.count, &bufferrmon.epa_all.count, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.frc_all.count, &bufferrmon.frc_all.count, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.str_all.count, &bufferrmon.str_all.count, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.str_all.max, &bufferrmon.str_all.max, 5, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.str_all.sum, &bufferrmon.str_all.sum, 5, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.vir_all.count, &bufferrmon.vir_all.count, 1, MPI_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.vir_all.max, &bufferrmon.vir_all.max, 5, MPI_DOUBLE, MPI_MAX, 0, MPI_COMM_WORLD);
		MPI_Reduce(&errmon.vir_all.sum, &bufferrmon.vir_all.sum, 5, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		double valid_energy_abs_sum_global = 0.0;
		double valid_force_abs_component_sum_global = 0.0;
		double valid_stress_abs_component_sum_global = 0.0;
		long long valid_force_component_count_global = 0;
		long long valid_stress_component_count_global = 0;
		MPI_Reduce(&valid_energy_abs_sum, &valid_energy_abs_sum_global, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		double valid_energy_sq_weighted_sum_global = 0.0;
		double valid_force_sq_component_sum_global = 0.0;
		double valid_stress_sq_component_sum_global = 0.0;
		MPI_Reduce(&valid_force_abs_component_sum, &valid_force_abs_component_sum_global, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&valid_stress_abs_component_sum, &valid_stress_abs_component_sum_global, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&valid_energy_sq_weighted_sum, &valid_energy_sq_weighted_sum_global, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&valid_force_sq_component_sum, &valid_force_sq_component_sum_global, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&valid_stress_sq_component_sum, &valid_stress_sq_component_sum_global, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&valid_force_component_count, &valid_force_component_count_global, 1, MPI_LONG_LONG_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		MPI_Reduce(&valid_stress_component_count, &valid_stress_component_count_global, 1, MPI_LONG_LONG_INT, MPI_SUM, 0, MPI_COMM_WORLD);
		if (prank == 0)
		{
			const double valid_energy_mae_mev_atom =
				valid_atom_total > 0 ? 1000.0 * valid_energy_abs_sum_global / static_cast<double>(valid_atom_total) : 0.0;
			const double valid_energy_rmse_mev_atom =
				valid_atom_total > 0 ? 1000.0 * std::sqrt(valid_energy_sq_weighted_sum_global / static_cast<double>(valid_atom_total)) : 0.0;
			const double valid_force_mae_mev_a =
				valid_force_component_count_global > 0 ? 1000.0 * valid_force_abs_component_sum_global / static_cast<double>(valid_force_component_count_global) : 0.0;
			const double valid_force_rmse_mev_a =
				valid_force_component_count_global > 0 ? 1000.0 * std::sqrt(valid_force_sq_component_sum_global / static_cast<double>(valid_force_component_count_global)) : 0.0;
			const double valid_stress_mae_ev =
				valid_stress_component_count_global > 0 ? valid_stress_abs_component_sum_global / static_cast<double>(valid_stress_component_count_global) : 0.0;
			const double valid_stress_rmse_ev =
				valid_stress_component_count_global > 0 ? std::sqrt(valid_stress_sq_component_sum_global / static_cast<double>(valid_stress_component_count_global)) : 0.0;
			std::cout << "\n=== Validation Summary ===\n"
			          << std::fixed << std::setprecision(3)
			          << "Structures           : " << valid_cfg_total << "\n"
			          << "Atoms                : " << valid_atom_total << "\n"
			          << "Energy MAE (meV/atom): " << valid_energy_mae_mev_atom << "\n"
			          << "Energy RMSE(meV/atom): " << valid_energy_rmse_mev_atom << "\n"
			          << "Force MAE  (meV/A)   : " << valid_force_mae_mev_a << "\n"
			          << "Force RMSE (meV/A)   : " << valid_force_rmse_mev_a << "\n"
			          << "Stress MAE (eV)      : " << valid_stress_mae_ev << "\n"
			          << "Stress RMSE(eV)      : " << valid_stress_rmse_ev << "\n"
			          << "==========================\n";
		}
#else
		const double valid_energy_mae_mev_atom =
			valid_atom_total > 0 ? 1000.0 * valid_energy_abs_sum / static_cast<double>(valid_atom_total) : 0.0;
		const double valid_energy_rmse_mev_atom =
			valid_atom_total > 0 ? 1000.0 * std::sqrt(valid_energy_sq_weighted_sum / static_cast<double>(valid_atom_total)) : 0.0;
		const double valid_force_mae_mev_a =
			valid_force_component_count > 0 ? 1000.0 * valid_force_abs_component_sum / static_cast<double>(valid_force_component_count) : 0.0;
		const double valid_force_rmse_mev_a =
			valid_force_component_count > 0 ? 1000.0 * std::sqrt(valid_force_sq_component_sum / static_cast<double>(valid_force_component_count)) : 0.0;
		const double valid_stress_mae_ev =
			valid_stress_component_count > 0 ? valid_stress_abs_component_sum / static_cast<double>(valid_stress_component_count) : 0.0;
		const double valid_stress_rmse_ev =
			valid_stress_component_count > 0 ? std::sqrt(valid_stress_sq_component_sum / static_cast<double>(valid_stress_component_count)) : 0.0;
		std::cout << "\n=== Validation Summary ===\n"
		          << std::fixed << std::setprecision(3)
		          << "Structures           : " << valid_cfg_total << "\n"
		          << "Atoms                : " << valid_atom_total << "\n"
		          << "Energy MAE (meV/atom): " << valid_energy_mae_mev_atom << "\n"
		          << "Energy RMSE(meV/atom): " << valid_energy_rmse_mev_atom << "\n"
		          << "Force MAE  (meV/A)   : " << valid_force_mae_mev_a << "\n"
		          << "Force RMSE (meV/A)   : " << valid_force_rmse_mev_a << "\n"
		          << "Stress MAE (eV)      : " << valid_stress_mae_ev << "\n"
		          << "Stress RMSE(eV)      : " << valid_stress_rmse_ev << "\n"
		          << "==========================\n";
#endif
	}
#ifdef MLIP_MPI
	MPI_Barrier(MPI_COMM_WORLD);
	//MPI_Finalize();
#endif
}
