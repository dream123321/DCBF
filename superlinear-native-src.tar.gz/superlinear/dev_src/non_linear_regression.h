/*   This software is called MLIP for Machine Learning Interatomic Potentials.
 *   MLIP can only be used for non-commercial research and cannot be re-distributed.
 *   The use of MLIP must be acknowledged by citing approriate references.
 *   See the LICENSE file for details.
 */

#ifndef MLIP_NON_LINEAR_REGRESSION_H
#define MLIP_NON_LINEAR_REGRESSION_H

#include "../src/basic_mlip.h"
#include "../src/basic_trainer.h"
#include "force_loss.h"


class NonLinearRegression : public AnyTrainer//, protected LogWriting 
{
public:
	struct GuardCompressionSample {
		Configuration cfg;
		double floor_energy_per_atom = 0.0;
		double scale = 1.0;
		int group_index = -1;
		bool is_anchor = false;
	};
	struct GuardCompressionPair {
		int less_compressed = -1;
		int more_compressed = -1;
	};
	struct GuardCompressionAnchorPair {
		int anchor = -1;
		int more_compressed = -1;
	};
	struct GuardCompressionTriplet {
		int less_compressed = -1;
		int middle_compressed = -1;
		int more_compressed = -1;
	};
	struct GuardCompressionAnchorTriplet {
		int first_compressed = -1;
		int second_compressed = -1;
	};

protected:
	std::vector<Vector3> dLdF;
	std::vector<double> dLdE_i_;
	std::vector<int> type_count_scratch_;
	std::vector<int> active_type_scratch_;
	std::vector<double> type_mean_scratch_;
	std::vector<double> type_joint_scratch_;
	Matrix3 dLdS;
	double metric_energy_abs_sum_ = 0.0;
	double metric_energy_sq_weighted_sum_ = 0.0;
	double metric_force_abs_component_sum_ = 0.0;
	double metric_force_sq_component_sum_ = 0.0;
	double metric_stress_abs_component_sum_ = 0.0;
	double metric_stress_sq_component_sum_ = 0.0;
	long long metric_energy_atom_count_ = 0;
	long long metric_force_component_count_ = 0;
	long long metric_stress_component_count_ = 0;
	bool collect_error_metrics_ = true;
	void AddLoss(const Configuration &orig);
	void AddLoss(const Configuration &orig, const Neighborhoods* neighborhoods);
	void AddLoss(const Configuration &orig, const Neighborhoods* neighborhoods, Configuration* evaluated_cfg_out);
	void AddLossGrad(const Configuration &orig);
	void AddLossGrad(const Configuration &orig, const Neighborhoods* neighborhoods);
	void AddLossGrad(const Configuration &orig, const Neighborhoods* neighborhoods, const Configuration* evaluated_cfg);
	bool NeedForceTerms(const Configuration& orig) const;
	bool NeedStressTerms(const Configuration& orig) const;
	bool NeedPositionDerivativeTerms(const Configuration& orig) const;
	void AddGateXRegularization(Configuration& cfg,
	                            const Neighborhoods* neighborhoods,
	                            Array1D* grad_accumulator);
	void AddGuardCompressionLoss(Array1D* grad_accumulator,
	                             bool use_cached_predictions,
	                             bool fill_prediction_cache);
	void AccumulateGuardCompressionEnergyGrad(Configuration& cfg,
	                                          const Neighborhoods* neighborhoods,
	                                          double dloss_denergy,
	                                          Array1D& grad_accumulator);
	void AccumulateGuardCompressionBodyOrderGrad(Configuration& cfg,
	                                             const Neighborhoods* neighborhoods,
	                                             const std::vector<double>& body_order_weights,
	                                             Array1D& grad_accumulator);
	void EvaluateTrainingConfiguration(const Configuration& orig,
	                                   Configuration& cfg,
	                                   const Neighborhoods* neighborhoods,
	                                   bool request_full_edge_cache);
	bool NeedStdTerms() const { return std_scaling != 0.0 || stdd_scaling != 0.0; }
	void PrepareTypeScratch(const Configuration& cfg);
	void ResetObjectiveAccumulators();
	void AddGlobalRegularization(double local_multiplier, Array1D* grad_accumulator);
	double loss_;											// result of AddLoss and AddLossGrad
	double std_;
        double stdd_;
	double mean_1;
        double mean_2;
	double mean_3;
	std::vector<double> loss_grad_;							// result of AddLossGrad
	std::vector<Configuration> objective_prediction_cache_;
	bool objective_prediction_cache_valid_ = false;
	std::vector<GuardCompressionSample> guard_compression_samples_;
	std::vector<Neighborhoods> guard_compression_neighborhoods_;
	std::vector<GuardCompressionAnchorPair> guard_compression_anchor_pairs_;
	std::vector<GuardCompressionPair> guard_compression_pairs_;
	std::vector<GuardCompressionAnchorTriplet> guard_compression_anchor_triplets_;
	std::vector<GuardCompressionTriplet> guard_compression_triplets_;
	std::vector<Configuration> guard_compression_prediction_cache_;
	bool guard_compression_prediction_cache_valid_ = false;
	long long guard_compression_global_sample_count_ = 0;
	long long guard_compression_global_pair_count_ = 0;
	long long guard_compression_global_triplet_count_ = 0;
	double guard_compression_objective_multiplier_ = 0.0;

public:
	int norm_by_forces = 0;									// whether to scale weight of E&F in configurations depending on the abs(F)
        double std_scaling = 0.2;
        double stdd_scaling = 0.00001;	
	// Adaptive profile uses the same STD objective in value and gradient paths.
	bool consistent_std_value_loss = false;
	double radial_smooth_regularization = 1.0e-6;
	int radial_smooth_grid = 128;
	std::vector<double> fixed_atomic_energies;
	double fixed_atomic_energy_weight = 1.0e8;
		double scalar_head_l2_regularization = 0.0;
		double gate_scalar_l2_regularization = 0.0;
		double gate_mix_l2_regularization = 0.0;
		double gate_full_l2_regularization = 0.0;
		double gate_x_l2_regularization = 1.0e-4;
	double guard_compression_floor_weight = 0.0;
	double guard_compression_monotonic_weight = 0.0;
	double guard_compression_curvature_weight = 0.0;
	double guard_compression_block_monotonic_weight = 0.0;
	double guard_compression_floor_margin = 0.0;
	double guard_compression_monotonic_margin = 0.2;
	double guard_compression_curvature_margin = 0.0;
	double guard_compression_smooth = 0.02;
	ForceLossKind force_loss_kind = ForceLossKind::L2;
	double force_log_cosh_scale = 2.0;

	NonLinearRegression(AnyLocalMLIP* _p_mlip,				// Constructor requires MTP basis
						double _wgt_energy = 1.0,			// Optional parameters are the weights coeficients of energy, forces and stresses equations in minimization problem
						double _wgt_forces = 1.0,
						double _wgt_stress = 1.0,
						double _wgt_relfrc = 0.0,
						double _wgt_constr = 1.0) :
		AnyTrainer(	_p_mlip, 
					_wgt_energy, 
					_wgt_forces, 
					_wgt_stress,
					_wgt_relfrc,
					_wgt_constr) {};
														
	double ObjectiveFunction(std::vector<Configuration>& train_set);			// Calculates objective function summed over train_set
	double ObjectiveFunction(std::vector<Configuration>& train_set, const std::vector<Neighborhoods>* neighborhoods);
	double ObjectiveFunctionAndCachePredictions(std::vector<Configuration>& train_set, const std::vector<Neighborhoods>* neighborhoods);
	void CalcObjectiveFunctionGrad(std::vector<Configuration>& train_set);		// Calculates objective function summed over train_set with their gradients
	void CalcObjectiveFunctionGrad(std::vector<Configuration>& train_set, const std::vector<Neighborhoods>* neighborhoods);
	void CalcObjectiveFunctionGradFromCachedPredictions(std::vector<Configuration>& train_set, const std::vector<Neighborhoods>* neighborhoods);
	double EnergyMAE_meVPerAtom() const;
	double EnergyRMSE_meVPerAtom() const;
	double ForceMAE_meVPerA() const;
	double ForceRMSE_meVPerA() const;
	double StressMAE_eV() const;
	double StressRMSE_eV() const;
	double EFSLoss(double total_loss, double std_term, double stdd_term) const;
	void SetCollectErrorMetrics(bool enabled) { collect_error_metrics_ = enabled; }
	bool CollectErrorMetrics() const { return collect_error_metrics_; }
	void SetGuardCompressionSamples(std::vector<GuardCompressionSample> samples,
	                                std::vector<Neighborhoods> neighborhoods,
	                                std::vector<GuardCompressionAnchorPair> anchor_pairs,
	                                std::vector<GuardCompressionPair> pairs,
	                                std::vector<GuardCompressionAnchorTriplet> anchor_triplets,
	                                std::vector<GuardCompressionTriplet> triplets,
	                                long long global_sample_count,
	                                long long global_pair_count,
	                                long long global_triplet_count,
	                                double objective_multiplier);
	void ClearGuardCompressionSamples();
	bool GuardCompressionEnabled() const;
	int GuardCompressionLocalSampleCount() const { return static_cast<int>(guard_compression_samples_.size()); }
	int GuardCompressionLocalPairCount() const { return static_cast<int>(guard_compression_pairs_.size()); }
	int GuardCompressionLocalTripletCount() const { return static_cast<int>(guard_compression_triplets_.size()); }
	long long GuardCompressionGlobalSampleCount() const { return guard_compression_global_sample_count_; }
	long long GuardCompressionGlobalPairCount() const { return guard_compression_global_pair_count_; }
	long long GuardCompressionGlobalTripletCount() const { return guard_compression_global_triplet_count_; }

	virtual void Train(std::vector<Configuration>& train_set) override;

	bool CheckLossConsistency_debug(Configuration cfg,
									double displacement = 0.001,
									double control_delta = 0.01);

};

#endif // MLIP_NON_LINEAR_REGRESSION_H
