/*   This software is called MLIP for Machine Learning Interatomic Potentials.
 *   MLIP can only be used for non-commercial research and cannot be re-distributed.
 *   The use of MLIP must be acknowledged by citing approriate references.
 *   See the LICENSE file for details.
 */

#ifdef MLIP_MPI
#	include <mpi.h>
#endif

#include <random>
#include <ctime>
#include <sstream>


#include <fstream>
#include <iomanip>
#include <set>
#include <iostream>
#include <algorithm>
#include <cmath>
#include <utility>

#include "non_linear_regression.h"
#include "mtpr.h"
#include "../src/common/bfgs.h"

using namespace std;

namespace {
inline void AccumulateStressErrorMetrics(const Matrix3& lhs,
										 const Matrix3& rhs,
										 double& abs_sum,
										 double& sq_sum)
{
	const double d0 = lhs[0][0] - rhs[0][0];
	const double d1 = lhs[1][1] - rhs[1][1];
	const double d2 = lhs[2][2] - rhs[2][2];
	const double d3 = lhs[1][2] - rhs[1][2];
	const double d4 = lhs[0][2] - rhs[0][2];
	const double d5 = lhs[0][1] - rhs[0][1];

	abs_sum += std::abs(d0) + std::abs(d1) + std::abs(d2)
			+ std::abs(d3) + std::abs(d4) + std::abs(d5);
	sq_sum += d0 * d0 + d1 * d1 + d2 * d2
		   + d3 * d3 + d4 * d4 + d5 * d5;
}

inline double PositiveHuberValue(double z, double eps)
{
	if (z <= 0.0)
		return 0.0;
	if (eps <= 0.0 || z >= eps)
		return z - 0.5 * std::max(0.0, eps);
	return 0.5 * z * z / eps;
}

inline double PositiveHuberGrad(double z, double eps)
{
	if (z <= 0.0)
		return 0.0;
	if (eps <= 0.0 || z >= eps)
		return 1.0;
	return z / eps;
}

inline double GuardCompressionCoordinate(double scale)
{
	if (!std::isfinite(scale) || scale <= 0.0)
		ERROR("guard-compression scale should be finite and positive");
	return -3.0 * std::log(scale);
}
}

void NonLinearRegression::PrepareTypeScratch(const Configuration& cfg)
{
	for (int type : active_type_scratch_) {
		type_count_scratch_[type] = 0;
		type_mean_scratch_[type] = 0.0;
		type_joint_scratch_[type] = 0.0;
	}
	active_type_scratch_.clear();

	int max_type = -1;
	for (int type : cfg.types_)
		max_type = std::max(max_type, type);
	if (max_type < 0)
		return;

	const std::size_t required_size = static_cast<std::size_t>(max_type + 1);
	if (type_count_scratch_.size() < required_size) {
		type_count_scratch_.resize(required_size, 0);
		type_mean_scratch_.resize(required_size, 0.0);
		type_joint_scratch_.resize(required_size, 0.0);
	}

	for (int type : cfg.types_) {
		if (type_count_scratch_[type] == 0)
			active_type_scratch_.push_back(type);
		++type_count_scratch_[type];
	}
}

void NonLinearRegression::ResetObjectiveAccumulators()
{
	loss_ = 0.0;
	std_ = 0.0;
	stdd_ = 0.0;
	mean_1 = 0.0;
	mean_2 = 0.0;
	mean_3 = 0.0;
	metric_energy_abs_sum_ = 0.0;
	metric_energy_sq_weighted_sum_ = 0.0;
	metric_force_abs_component_sum_ = 0.0;
	metric_force_sq_component_sum_ = 0.0;
	metric_stress_abs_component_sum_ = 0.0;
	metric_stress_sq_component_sum_ = 0.0;
	metric_energy_atom_count_ = 0;
	metric_force_component_count_ = 0;
	metric_stress_component_count_ = 0;
}

void NonLinearRegression::SetGuardCompressionSamples(
	std::vector<GuardCompressionSample> samples,
	std::vector<Neighborhoods> neighborhoods,
	std::vector<GuardCompressionAnchorPair> anchor_pairs,
	std::vector<GuardCompressionPair> pairs,
	std::vector<GuardCompressionAnchorTriplet> anchor_triplets,
	std::vector<GuardCompressionTriplet> triplets,
	long long global_sample_count,
	long long global_pair_count,
	long long global_triplet_count,
	double objective_multiplier)
{
	if (!neighborhoods.empty() && neighborhoods.size() != samples.size())
		ERROR("guard-compression neighborhood cache size mismatch");
	if (global_sample_count < 0 || global_pair_count < 0 || global_triplet_count < 0)
		ERROR("guard-compression global counts should be non-negative");
	if (!std::isfinite(objective_multiplier) || objective_multiplier < 0.0)
		ERROR("guard-compression objective multiplier should be finite and non-negative");
	for (const GuardCompressionAnchorPair& pair : anchor_pairs) {
		if (pair.anchor >= static_cast<int>(samples.size())
		    || pair.more_compressed < 0
		    || pair.more_compressed >= static_cast<int>(samples.size()))
			ERROR("guard-compression anchor-pair index is out of range");
		if (pair.anchor >= 0 && !samples[pair.anchor].is_anchor)
			ERROR("guard-compression anchor-pair anchor index should point to an anchor sample");
	}
	for (const GuardCompressionPair& pair : pairs) {
		if (pair.less_compressed < 0 || pair.more_compressed < 0
		    || pair.less_compressed >= static_cast<int>(samples.size())
		    || pair.more_compressed >= static_cast<int>(samples.size()))
			ERROR("guard-compression pair index is out of range");
	}
	for (const GuardCompressionAnchorTriplet& triplet : anchor_triplets) {
		if (triplet.first_compressed < 0
		    || triplet.second_compressed < 0
		    || triplet.first_compressed >= static_cast<int>(samples.size())
		    || triplet.second_compressed >= static_cast<int>(samples.size()))
			ERROR("guard-compression anchor-triplet index is out of range");
		const double x0 = 0.0;
		const double x1 = GuardCompressionCoordinate(
			samples[triplet.first_compressed].scale);
		const double x2 = GuardCompressionCoordinate(
			samples[triplet.second_compressed].scale);
		if (!(x0 < x1 && x1 < x2))
			ERROR("guard-compression anchor-triplet scales should be ordered from anchor to more compressed");
	}
	for (const GuardCompressionTriplet& triplet : triplets) {
		if (triplet.less_compressed < 0
		    || triplet.middle_compressed < 0
		    || triplet.more_compressed < 0
		    || triplet.less_compressed >= static_cast<int>(samples.size())
		    || triplet.middle_compressed >= static_cast<int>(samples.size())
		    || triplet.more_compressed >= static_cast<int>(samples.size()))
			ERROR("guard-compression triplet index is out of range");
		const double x0 = GuardCompressionCoordinate(
			samples[triplet.less_compressed].scale);
		const double x1 = GuardCompressionCoordinate(
			samples[triplet.middle_compressed].scale);
		const double x2 = GuardCompressionCoordinate(
			samples[triplet.more_compressed].scale);
		if (!(x0 < x1 && x1 < x2))
			ERROR("guard-compression triplet scales should be ordered from less to more compressed");
	}

	guard_compression_samples_ = std::move(samples);
	guard_compression_neighborhoods_ = std::move(neighborhoods);
	guard_compression_anchor_pairs_ = std::move(anchor_pairs);
	guard_compression_pairs_ = std::move(pairs);
	guard_compression_anchor_triplets_ = std::move(anchor_triplets);
	guard_compression_triplets_ = std::move(triplets);
	guard_compression_global_sample_count_ = global_sample_count;
	guard_compression_global_pair_count_ = global_pair_count;
	guard_compression_global_triplet_count_ = global_triplet_count;
	guard_compression_objective_multiplier_ = objective_multiplier;
	guard_compression_prediction_cache_.clear();
	guard_compression_prediction_cache_valid_ = false;
}

void NonLinearRegression::ClearGuardCompressionSamples()
{
	guard_compression_samples_.clear();
	guard_compression_neighborhoods_.clear();
	guard_compression_anchor_pairs_.clear();
	guard_compression_pairs_.clear();
	guard_compression_anchor_triplets_.clear();
	guard_compression_triplets_.clear();
	guard_compression_prediction_cache_.clear();
	guard_compression_prediction_cache_valid_ = false;
	guard_compression_global_sample_count_ = 0;
	guard_compression_global_pair_count_ = 0;
	guard_compression_global_triplet_count_ = 0;
	guard_compression_objective_multiplier_ = 0.0;
}

bool NonLinearRegression::GuardCompressionEnabled() const
{
	return !guard_compression_samples_.empty()
		&& guard_compression_objective_multiplier_ > 0.0
		&& ((guard_compression_floor_weight > 0.0
		     && guard_compression_global_sample_count_ > 0)
		    || (guard_compression_monotonic_weight > 0.0
		        && guard_compression_global_pair_count_ > 0)
		    || (guard_compression_curvature_weight > 0.0
		        && guard_compression_global_triplet_count_ > 0)
		    || (guard_compression_block_monotonic_weight > 0.0
		        && guard_compression_global_pair_count_ > 0));
}

void NonLinearRegression::AddGlobalRegularization(double local_multiplier, Array1D* grad_accumulator)
{
	if (local_multiplier <= 0.0)
		return;
	if (radial_smooth_regularization < 0.0)
		ERROR("--radial-smooth should be >= 0");
	if (radial_smooth_grid <= 0)
		ERROR("--radial-smooth-grid should be > 0");
	if (fixed_atomic_energy_weight < 0.0)
		ERROR("--atomic-energy-weight should be >= 0");
	if (!std::isfinite(scalar_head_l2_regularization) || scalar_head_l2_regularization < 0.0)
		ERROR("--scalar-head-l2 should be finite and >= 0");
	if (!std::isfinite(gate_scalar_l2_regularization) || gate_scalar_l2_regularization < 0.0)
		ERROR("--gate-scalar-l2 should be finite and >= 0");
	if (!std::isfinite(gate_mix_l2_regularization) || gate_mix_l2_regularization < 0.0)
		ERROR("--gate-mix-l2 should be finite and >= 0");
	if (!std::isfinite(gate_full_l2_regularization) || gate_full_l2_regularization < 0.0)
		ERROR("--gate-full-l2 should be finite and >= 0");

	const double radial_coeff = local_multiplier * radial_smooth_regularization;
	if (radial_coeff != 0.0)
		p_mlip->AddRadialSmoothnessPenalty(radial_coeff,
		                                   radial_smooth_grid,
		                                   loss_,
		                                   grad_accumulator);

	if (!fixed_atomic_energies.empty() && fixed_atomic_energy_weight != 0.0) {
		p_mlip->AddFixedAtomicEnergyPenalty(fixed_atomic_energies,
		                                    local_multiplier * fixed_atomic_energy_weight,
		                                    loss_,
		                                    grad_accumulator);
	}

	if (scalar_head_l2_regularization != 0.0
	    || gate_scalar_l2_regularization != 0.0
	    || gate_mix_l2_regularization != 0.0
	    || gate_full_l2_regularization != 0.0) {
		p_mlip->AddScalarWeightL2Penalty(
			local_multiplier * scalar_head_l2_regularization,
			local_multiplier * gate_scalar_l2_regularization,
			local_multiplier * gate_mix_l2_regularization,
			local_multiplier * gate_full_l2_regularization,
			loss_,
			grad_accumulator);
	}
}

bool NonLinearRegression::NeedForceTerms(const Configuration& orig) const
{
	return wgt_eqtn_forces != 0.0 && orig.has_forces();
}

bool NonLinearRegression::NeedStressTerms(const Configuration& orig) const
{
	return wgt_eqtn_stress != 0.0 && orig.has_stresses();
}

bool NonLinearRegression::NeedPositionDerivativeTerms(const Configuration& orig) const
{
	return NeedForceTerms(orig) || NeedStressTerms(orig);
}

void NonLinearRegression::AddGateXRegularization(
	Configuration& cfg,
	const Neighborhoods* neighborhoods,
	Array1D* grad_accumulator)
{
	if (gate_x_l2_regularization == 0.0)
		return;
	if (!std::isfinite(gate_x_l2_regularization)
	    || gate_x_l2_regularization < 0.0)
		ERROR("--gate-x-l2 should be a finite non-negative value");

	MLMTPR* mtpr = dynamic_cast<MLMTPR*>(p_mlip);
	if (mtpr == nullptr || !mtpr->TwoLayerGateEnabled())
		return;

	if (neighborhoods != nullptr) {
		mtpr->AddTwoLayerGateX2Penalty(
			cfg, *neighborhoods, gate_x_l2_regularization,
			loss_, grad_accumulator);
		return;
	}

	Neighborhoods local_neighborhoods(cfg, p_mlip->CutOff());
	mtpr->AddTwoLayerGateX2Penalty(
		cfg, local_neighborhoods, gate_x_l2_regularization,
		loss_, grad_accumulator);
}

void NonLinearRegression::AccumulateGuardCompressionEnergyGrad(
	Configuration& cfg,
	const Neighborhoods* neighborhoods,
	double dloss_denergy,
	Array1D& grad_accumulator)
{
	if (cfg.size() == 0 || dloss_denergy == 0.0)
		return;
	if (dLdE_i_.size() != cfg.size())
		dLdE_i_.resize(cfg.size());
	std::fill(dLdE_i_.begin(), dLdE_i_.end(), dloss_denergy);
	if (neighborhoods != nullptr)
		p_mlip->AccumulateEnergyCombinationGrad(cfg, dLdE_i_, grad_accumulator, *neighborhoods);
	else
		p_mlip->AccumulateEnergyCombinationGrad(cfg, dLdE_i_, grad_accumulator);
}

void NonLinearRegression::AccumulateGuardCompressionBodyOrderGrad(
	Configuration& cfg,
	const Neighborhoods* neighborhoods,
	const std::vector<double>& body_order_weights,
	Array1D& grad_accumulator)
{
	bool has_weight = false;
	for (double weight : body_order_weights)
		if (weight != 0.0) {
			has_weight = true;
			break;
		}
	if (!has_weight || cfg.size() == 0)
		return;
	MLMTPR* mtpr = dynamic_cast<MLMTPR*>(p_mlip);
	if (mtpr == nullptr)
		ERROR("guard-compression block monotonic loss requires an MLMTPR model");
	if (neighborhoods != nullptr) {
		mtpr->AccumulateSHBodyOrderEnergyGrad(cfg,
		                                      *neighborhoods,
		                                      body_order_weights,
		                                      grad_accumulator);
		return;
	}
	Neighborhoods local_neighborhoods(cfg, p_mlip->CutOff());
	mtpr->AccumulateSHBodyOrderEnergyGrad(cfg,
	                                      local_neighborhoods,
	                                      body_order_weights,
	                                      grad_accumulator);
}

void NonLinearRegression::AddGuardCompressionLoss(
	Array1D* grad_accumulator,
	bool use_cached_predictions,
	bool fill_prediction_cache)
{
	if (!GuardCompressionEnabled())
		return;
	if (!std::isfinite(guard_compression_floor_weight)
	    || guard_compression_floor_weight < 0.0)
		ERROR("--guard-compression-floor-weight should be finite and non-negative");
	if (!std::isfinite(guard_compression_monotonic_weight)
	    || guard_compression_monotonic_weight < 0.0)
		ERROR("--guard-compression-monotonic-weight should be finite and non-negative");
	if (!std::isfinite(guard_compression_curvature_weight)
	    || guard_compression_curvature_weight < 0.0)
		ERROR("--guard-compression-curvature-weight should be finite and non-negative");
	if (!std::isfinite(guard_compression_block_monotonic_weight)
	    || guard_compression_block_monotonic_weight < 0.0)
		ERROR("--guard-compression-block-monotonic-weight should be finite and non-negative");
	if (!std::isfinite(guard_compression_floor_margin))
		ERROR("--guard-compression-floor-margin should be finite");
	if (!std::isfinite(guard_compression_monotonic_margin))
		ERROR("--guard-compression-monotonic-margin should be finite");
	if (!std::isfinite(guard_compression_curvature_margin))
		ERROR("--guard-compression-curvature-margin should be finite");
	if (!std::isfinite(guard_compression_smooth)
	    || guard_compression_smooth < 0.0)
		ERROR("--guard-compression-smooth should be finite and non-negative");

	const std::size_t sample_count = guard_compression_samples_.size();
	const bool need_floor =
		guard_compression_floor_weight > 0.0
		&& guard_compression_global_sample_count_ > 0;
	const bool need_monotonic =
		guard_compression_monotonic_weight > 0.0
		&& guard_compression_global_pair_count_ > 0;
	const bool need_curvature =
		guard_compression_curvature_weight > 0.0
		&& guard_compression_global_triplet_count_ > 0;
	const bool need_block_monotonic =
		guard_compression_block_monotonic_weight > 0.0
		&& guard_compression_global_pair_count_ > 0;
	const bool need_energy_terms =
		need_floor || need_monotonic || need_curvature;
	if (!need_energy_terms && !need_block_monotonic)
		return;
	std::vector<Configuration> local_predictions;
	std::vector<Configuration>* predictions = nullptr;
	MLMTPR* mtpr = nullptr;
	int block_body_order_max = 0;
	std::vector<std::vector<double>> sample_body_energy_per_atom;
	std::vector<std::vector<double>> sample_body_grad_scale;
	if (need_block_monotonic) {
		mtpr = dynamic_cast<MLMTPR*>(p_mlip);
		if (mtpr == nullptr || !mtpr->HasSHBodyOrderBlocks())
			ERROR("guard-compression block monotonic loss requires a non-residual SUS2-SH model with sh_scalar_info metadata");
		block_body_order_max = mtpr->SHBodyOrderMax();
		if (block_body_order_max < 2)
			ERROR("guard-compression block monotonic loss found no body-order blocks");
		sample_body_energy_per_atom.assign(
			sample_count, std::vector<double>(block_body_order_max + 1, 0.0));
		sample_body_grad_scale.assign(
			sample_count, std::vector<double>(block_body_order_max + 1, 0.0));
	}
	bool body_energy_filled_during_prediction = false;
	if (need_energy_terms) {
		if (use_cached_predictions
		    && guard_compression_prediction_cache_valid_
		    && guard_compression_prediction_cache_.size() == sample_count) {
			predictions = &guard_compression_prediction_cache_;
		} else {
			if (fill_prediction_cache) {
				guard_compression_prediction_cache_.clear();
				guard_compression_prediction_cache_.resize(sample_count);
				predictions = &guard_compression_prediction_cache_;
			} else {
				local_predictions.resize(sample_count);
				predictions = &local_predictions;
			}
			for (std::size_t idx = 0; idx < sample_count; ++idx) {
				(*predictions)[idx] = guard_compression_samples_[idx].cfg;
				const Neighborhoods* neighborhoods =
					guard_compression_neighborhoods_.empty()
						? nullptr
						: &guard_compression_neighborhoods_[idx];
				if (need_block_monotonic) {
					std::vector<double> body_energy;
					if (neighborhoods != nullptr) {
						mtpr->CalcEnergyAndSiteEnergiesWithSHBodyOrderContributions(
							(*predictions)[idx], *neighborhoods, body_energy);
					} else {
						Neighborhoods local_neighborhoods(
							(*predictions)[idx], p_mlip->CutOff());
						mtpr->CalcEnergyAndSiteEnergiesWithSHBodyOrderContributions(
							(*predictions)[idx], local_neighborhoods, body_energy);
					}
					if ((*predictions)[idx].size() != 0)
						for (int body_order = 2; body_order <= block_body_order_max; ++body_order)
							sample_body_energy_per_atom[idx][body_order] =
								body_energy[body_order] / (*predictions)[idx].size();
				} else {
					if (neighborhoods != nullptr)
						p_mlip->CalcEnergyAndSiteEnergies((*predictions)[idx], *neighborhoods);
					else
						p_mlip->CalcEnergyAndSiteEnergies((*predictions)[idx]);
				}
			}
			body_energy_filled_during_prediction = need_block_monotonic;
			guard_compression_prediction_cache_valid_ = fill_prediction_cache;
		}
	}

	std::vector<double> sample_energy_per_atom;
	std::vector<double> sample_grad_scale;
	if (need_energy_terms) {
		sample_energy_per_atom.assign(sample_count, 0.0);
		sample_grad_scale.assign(sample_count, 0.0);
		for (std::size_t idx = 0; idx < sample_count; ++idx) {
			const Configuration& pred = (*predictions)[idx];
			if (pred.size() == 0)
				continue;
			sample_energy_per_atom[idx] = pred.energy / pred.size();
		}
	}

	if (need_block_monotonic && !body_energy_filled_during_prediction) {
		for (std::size_t idx = 0; idx < sample_count; ++idx) {
			Configuration cfg = guard_compression_samples_[idx].cfg;
			if (cfg.size() == 0)
				continue;
			std::vector<double> body_energy;
			const Neighborhoods* neighborhoods =
				guard_compression_neighborhoods_.empty()
					? nullptr
					: &guard_compression_neighborhoods_[idx];
			if (neighborhoods != nullptr) {
				mtpr->CalcSHBodyOrderEnergyContributions(
					cfg, *neighborhoods, body_energy);
			} else {
				Neighborhoods local_neighborhoods(cfg, p_mlip->CutOff());
				mtpr->CalcSHBodyOrderEnergyContributions(
					cfg, local_neighborhoods, body_energy);
			}
			for (int body_order = 2; body_order <= block_body_order_max; ++body_order)
				sample_body_energy_per_atom[idx][body_order] =
					body_energy[body_order] / cfg.size();
		}
	}

	if (need_floor) {
		const double scale = guard_compression_objective_multiplier_
			* guard_compression_floor_weight
			/ static_cast<double>(guard_compression_global_sample_count_);
		for (std::size_t idx = 0; idx < sample_count; ++idx) {
			const GuardCompressionSample& sample = guard_compression_samples_[idx];
			const Configuration& pred = (*predictions)[idx];
			if (pred.size() == 0 || sample.is_anchor)
				continue;
			const double violation = sample.floor_energy_per_atom
				+ guard_compression_floor_margin
				- sample_energy_per_atom[idx];
			const double value = PositiveHuberValue(violation, guard_compression_smooth);
			const double derivative = PositiveHuberGrad(violation, guard_compression_smooth);
			loss_ += scale * pred.size() * value;
			sample_grad_scale[idx] -= scale * derivative;
		}
	}

	if (need_monotonic) {
		const double scale = guard_compression_objective_multiplier_
			* guard_compression_monotonic_weight
			/ static_cast<double>(guard_compression_global_pair_count_);
		for (const GuardCompressionAnchorPair& pair : guard_compression_anchor_pairs_) {
			const GuardCompressionSample& sample =
				guard_compression_samples_[pair.more_compressed];
			Configuration& more_pred = (*predictions)[pair.more_compressed];
			if (more_pred.size() == 0)
				continue;
			const double violation =
				sample.floor_energy_per_atom
				+ guard_compression_monotonic_margin
				- sample_energy_per_atom[pair.more_compressed];
			const double value = PositiveHuberValue(violation, guard_compression_smooth);
			const double derivative = PositiveHuberGrad(violation, guard_compression_smooth);
			loss_ += scale * more_pred.size() * value;
			sample_grad_scale[pair.more_compressed] -= scale * derivative;
		}
		for (const GuardCompressionPair& pair : guard_compression_pairs_) {
			Configuration& less_pred = (*predictions)[pair.less_compressed];
			Configuration& more_pred = (*predictions)[pair.more_compressed];
			if (less_pred.size() == 0 || more_pred.size() == 0)
				continue;
			const double violation =
				sample_energy_per_atom[pair.less_compressed]
				+ guard_compression_monotonic_margin
				- sample_energy_per_atom[pair.more_compressed];
			const double value = PositiveHuberValue(violation, guard_compression_smooth);
			const double derivative = PositiveHuberGrad(violation, guard_compression_smooth);
			const double pair_atoms = static_cast<double>(
				std::min(less_pred.size(), more_pred.size()));
			loss_ += scale * pair_atoms * value;
			sample_grad_scale[pair.less_compressed] +=
				scale * pair_atoms * derivative / less_pred.size();
			sample_grad_scale[pair.more_compressed] -=
				scale * pair_atoms * derivative / more_pred.size();
		}
	}

	if (need_block_monotonic) {
		const long long global_block_pair_count =
			guard_compression_global_pair_count_
			* static_cast<long long>(block_body_order_max - 1);
		if (global_block_pair_count <= 0)
			ERROR("guard-compression block monotonic loss found no block pairs");
		const double scale = guard_compression_objective_multiplier_
			* guard_compression_block_monotonic_weight
			/ static_cast<double>(global_block_pair_count);
		auto add_block_pair = [&](int less_index, int more_index) {
			const Configuration& less_cfg = guard_compression_samples_[less_index].cfg;
			const Configuration& more_cfg = guard_compression_samples_[more_index].cfg;
			if (less_cfg.size() == 0 || more_cfg.size() == 0)
				return;
			const double pair_atoms = static_cast<double>(
				std::min(less_cfg.size(), more_cfg.size()));
			for (int body_order = 2; body_order <= block_body_order_max; ++body_order) {
				const double violation =
					sample_body_energy_per_atom[less_index][body_order]
					- sample_body_energy_per_atom[more_index][body_order];
				const double value = PositiveHuberValue(violation,
				                                        guard_compression_smooth);
				const double derivative = PositiveHuberGrad(violation,
				                                            guard_compression_smooth);
				loss_ += scale * pair_atoms * value;
				sample_body_grad_scale[less_index][body_order] +=
					scale * pair_atoms * derivative / less_cfg.size();
				sample_body_grad_scale[more_index][body_order] -=
					scale * pair_atoms * derivative / more_cfg.size();
			}
		};
		for (const GuardCompressionAnchorPair& pair : guard_compression_anchor_pairs_) {
			if (pair.anchor < 0)
				ERROR("guard-compression block monotonic loss requires cached anchor samples");
			add_block_pair(pair.anchor, pair.more_compressed);
		}
		for (const GuardCompressionPair& pair : guard_compression_pairs_)
			add_block_pair(pair.less_compressed, pair.more_compressed);
	}

	if (need_curvature) {
		const double scale = guard_compression_objective_multiplier_
			* guard_compression_curvature_weight
			/ static_cast<double>(guard_compression_global_triplet_count_);
		for (const GuardCompressionAnchorTriplet& triplet : guard_compression_anchor_triplets_) {
			const GuardCompressionSample& first_sample =
				guard_compression_samples_[triplet.first_compressed];
			Configuration& first_pred = (*predictions)[triplet.first_compressed];
			Configuration& second_pred = (*predictions)[triplet.second_compressed];
			if (first_pred.size() == 0 || second_pred.size() == 0)
				continue;
			const double x_anchor = 0.0;
			const double x_first = GuardCompressionCoordinate(first_sample.scale);
			const double x_second = GuardCompressionCoordinate(
				guard_compression_samples_[triplet.second_compressed].scale);
			const double dx_left = x_first - x_anchor;
			const double dx_right = x_second - x_first;
			if (!(dx_left > 0.0 && dx_right > 0.0))
				ERROR("guard-compression anchor-curvature triplet has non-increasing compression coordinate");
			const double slope_left =
				(sample_energy_per_atom[triplet.first_compressed]
				 - first_sample.floor_energy_per_atom) / dx_left;
			const double slope_right =
				(sample_energy_per_atom[triplet.second_compressed]
				 - sample_energy_per_atom[triplet.first_compressed]) / dx_right;
			const double violation =
				slope_left + guard_compression_curvature_margin - slope_right;
			const double value = PositiveHuberValue(violation, guard_compression_smooth);
			const double derivative = PositiveHuberGrad(violation, guard_compression_smooth);
			const double triplet_atoms = static_cast<double>(
				std::min(first_pred.size(), second_pred.size()));
			loss_ += scale * triplet_atoms * value;
			sample_grad_scale[triplet.first_compressed] +=
				scale * triplet_atoms * derivative
				* (1.0 / dx_left + 1.0 / dx_right) / first_pred.size();
			sample_grad_scale[triplet.second_compressed] -=
				scale * triplet_atoms * derivative / (dx_right * second_pred.size());
		}
		for (const GuardCompressionTriplet& triplet : guard_compression_triplets_) {
			Configuration& less_pred = (*predictions)[triplet.less_compressed];
			Configuration& middle_pred = (*predictions)[triplet.middle_compressed];
			Configuration& more_pred = (*predictions)[triplet.more_compressed];
			if (less_pred.size() == 0 || middle_pred.size() == 0 || more_pred.size() == 0)
				continue;
			const double x_less = GuardCompressionCoordinate(
				guard_compression_samples_[triplet.less_compressed].scale);
			const double x_middle = GuardCompressionCoordinate(
				guard_compression_samples_[triplet.middle_compressed].scale);
			const double x_more = GuardCompressionCoordinate(
				guard_compression_samples_[triplet.more_compressed].scale);
			const double dx_left = x_middle - x_less;
			const double dx_right = x_more - x_middle;
			if (!(dx_left > 0.0 && dx_right > 0.0))
				ERROR("guard-compression curvature triplet has non-increasing compression coordinate");
			const double slope_left =
				(sample_energy_per_atom[triplet.middle_compressed]
				 - sample_energy_per_atom[triplet.less_compressed]) / dx_left;
			const double slope_right =
				(sample_energy_per_atom[triplet.more_compressed]
				 - sample_energy_per_atom[triplet.middle_compressed]) / dx_right;
			const double violation =
				slope_left + guard_compression_curvature_margin - slope_right;
			const double value = PositiveHuberValue(violation, guard_compression_smooth);
			const double derivative = PositiveHuberGrad(violation, guard_compression_smooth);
			const double triplet_atoms = static_cast<double>(
				std::min(less_pred.size(), std::min(middle_pred.size(), more_pred.size())));
			loss_ += scale * triplet_atoms * value;
			sample_grad_scale[triplet.less_compressed] -=
				scale * triplet_atoms * derivative / (dx_left * less_pred.size());
			sample_grad_scale[triplet.middle_compressed] +=
				scale * triplet_atoms * derivative
				* (1.0 / dx_left + 1.0 / dx_right) / middle_pred.size();
			sample_grad_scale[triplet.more_compressed] -=
				scale * triplet_atoms * derivative / (dx_right * more_pred.size());
		}
	}

	if (grad_accumulator == nullptr)
		return;
	if (need_energy_terms) {
		for (std::size_t idx = 0; idx < sample_count; ++idx) {
			if (sample_grad_scale[idx] == 0.0)
				continue;
			const Neighborhoods* neighborhoods =
				guard_compression_neighborhoods_.empty()
					? nullptr
					: &guard_compression_neighborhoods_[idx];
			AccumulateGuardCompressionEnergyGrad((*predictions)[idx],
			                                     neighborhoods,
			                                     sample_grad_scale[idx],
			                                     *grad_accumulator);
		}
	}
	if (need_block_monotonic && !sample_body_grad_scale.empty()) {
		for (std::size_t idx = 0; idx < sample_count; ++idx) {
			bool has_body_grad = false;
			for (int body_order = 2; body_order <= block_body_order_max; ++body_order)
				if (sample_body_grad_scale[idx][body_order] != 0.0) {
					has_body_grad = true;
					break;
				}
			if (!has_body_grad)
				continue;
			const Neighborhoods* neighborhoods =
				guard_compression_neighborhoods_.empty()
					? nullptr
					: &guard_compression_neighborhoods_[idx];
			AccumulateGuardCompressionBodyOrderGrad(
				guard_compression_samples_[idx].cfg,
				neighborhoods,
				sample_body_grad_scale[idx],
				*grad_accumulator);
		}
	}
}

void NonLinearRegression::EvaluateTrainingConfiguration(
	const Configuration& orig,
	Configuration& cfg,
	const Neighborhoods* neighborhoods,
	bool request_full_edge_cache)
{
	const bool need_position_derivatives = NeedPositionDerivativeTerms(orig);
	if (need_position_derivatives) {
		if (request_full_edge_cache && neighborhoods != nullptr) {
			if (MLMTPR* mtpr = dynamic_cast<MLMTPR*>(p_mlip))
				mtpr->RequestTwoLayerFullEdgeCacheForNextCalcEFS();
		}
		if (neighborhoods != nullptr)
			p_mlip->CalcEFS(cfg, *neighborhoods);
		else
			p_mlip->CalcEFS(cfg);
		return;
	}

	if (neighborhoods != nullptr)
		p_mlip->CalcEnergyAndSiteEnergies(cfg, *neighborhoods);
	else
		p_mlip->CalcEnergyAndSiteEnergies(cfg);
}

void NonLinearRegression::AddLoss(const Configuration & orig)
{
	AddLoss(orig, nullptr);
}

void NonLinearRegression::AddLoss(const Configuration & orig, const Neighborhoods* neighborhoods)
{
	AddLoss(orig, neighborhoods, nullptr);
}

void NonLinearRegression::AddLoss(const Configuration & orig,
								  const Neighborhoods* neighborhoods,
								  Configuration* evaluated_cfg_out)
{
	if (orig.size() == 0)
		return;

	const bool need_std_terms = NeedStdTerms();
	Configuration cfg = orig;
	EvaluateTrainingConfiguration(orig, cfg, neighborhoods, false);
	if (evaluated_cfg_out != nullptr)
		*evaluated_cfg_out = cfg;

	if (collect_error_metrics_ && orig.has_energy() && cfg.has_energy()) {
		const double energy_delta = orig.energy - cfg.energy;
		metric_energy_abs_sum_ += std::abs(energy_delta);
		metric_energy_sq_weighted_sum_ += energy_delta * energy_delta / orig.size();
		metric_energy_atom_count_ += orig.size();
	}
	if (collect_error_metrics_ && orig.has_forces() && cfg.has_forces()) {
		for (int i = 0; i < cfg.size(); i++) {
			for (int a = 0; a < 3; a++)
			{
				const double force_delta = cfg.force(i)[a] - orig.force(i)[a];
				metric_force_abs_component_sum_ += std::abs(force_delta);
				metric_force_sq_component_sum_ += force_delta * force_delta;
			}
		}
		metric_force_component_count_ += static_cast<long long>(3) * cfg.size();
	}
	if (collect_error_metrics_ && orig.has_stresses() && cfg.has_stresses()) {
		AccumulateStressErrorMetrics(cfg.stresses,
									 orig.stresses,
									 metric_stress_abs_component_sum_,
									 metric_stress_sq_component_sum_);
		metric_stress_component_count_ += 6;
	}
	int fn = norm_by_forces;
	double d = 0.1;
	double avef = 0;
	double _std_ = 0.0;
	double _stdd_ = 0.0;
	if (need_std_terms)
	{
		const double mean_ = orig.energy / orig.size();
		PrepareTypeScratch(cfg);

		std::vector<double>& type_mean = type_mean_scratch_;
		for (int i = 0; i < cfg.size(); i++)
			type_mean[cfg.type(i)] += cfg.cal_se[i] / type_count_scratch_[cfg.type(i)];

		for (int type : active_type_scratch_)
			_stdd_ += (type_mean[type] - mean_) * (type_mean[type] - mean_);

		const double std_force_scale = consistent_std_value_loss ? 200.0 : 20.0;
		for (int i = 0; i < cfg.size(); i++)
			_std_ += std_force_scale * (cfg.cal_se[i] - type_mean[cfg.type(i)]) * (cfg.cal_se[i] - type_mean[cfg.type(i)])
				/ orig.size() / (std_force_scale + orig.force(i).NormSq());

		stdd_ += stdd_scaling * _stdd_;
		std_ += std_scaling * _std_;
		loss_ += std_scaling * _std_ + stdd_scaling * _stdd_;
	}
	if (orig.has_forces())
		for (int ind = 0; ind < orig.size(); ind++)
			avef += orig.force(ind).NormSq() / orig.size();

	if (wgt_eqtn_forces != 0 && orig.has_forces())
		for (int i=0; i<cfg.size(); i++)
		{
			double wgt = (wgt_rel_forces<=0.0) ?
						 wgt_eqtn_forces :
						 wgt_eqtn_forces*wgt_rel_forces / (orig.force(i).NormSq() + wgt_rel_forces);

			if (weighting == "structures")
				wgt /= cfg.size();

			const Vector3 delta = cfg.force(i) - orig.force(i);
			double force_loss = 0.0;
			for (int a = 0; a < 3; ++a)
				force_loss += ForceResidualLoss(delta[a],
				                                force_loss_kind,
				                                force_log_cosh_scale);
			loss_ += wgt * force_loss * d / (d + fn*avef);
		}

	double wgt_energy = wgt_eqtn_energy;
	double wgt_stress = wgt_eqtn_stress;

	if (weighting == "structures")
	{
		wgt_energy /= cfg.size();
		wgt_stress /= cfg.size();
	}
	else if (weighting == "molecules")
	{
		wgt_energy *= cfg.size();
		wgt_stress *= cfg.size();
	}

	if (wgt_stress!=0 && orig.has_stresses())
		loss_ += wgt_stress * (orig.stresses-cfg.stresses).NormFrobeniusSq() 
				 * (1.0/cfg.size());

	p_mlip->AddPenaltyGrad(wgt_eqtn_constr, loss_);

	// it is important to add energy latest - less round-off errors this way
	if (wgt_energy!=0 && orig.has_energy())
		loss_ += wgt_energy * (orig.energy-cfg.energy)*(orig.energy-cfg.energy) 
				 * d / ((d + fn*avef)*cfg.size());
	AddGateXRegularization(cfg, neighborhoods, nullptr);
	
}

void NonLinearRegression::AddLossGrad(const Configuration & orig)
{
	AddLossGrad(orig, nullptr);
}

void NonLinearRegression::AddLossGrad(const Configuration & orig, const Neighborhoods* neighborhoods)
{
	AddLossGrad(orig, neighborhoods, nullptr);
}

void NonLinearRegression::AddLossGrad(const Configuration & orig,
									  const Neighborhoods* neighborhoods,
									  const Configuration* evaluated_cfg)
{
	if (orig.size() == 0)
		return;

	if (loss_grad_.size() != p_mlip->CoeffCount())
		loss_grad_.resize(p_mlip->CoeffCount());

	const bool need_std_terms = NeedStdTerms();
	Configuration cfg = evaluated_cfg != nullptr ? *evaluated_cfg : orig;
	if (evaluated_cfg == nullptr)
		EvaluateTrainingConfiguration(orig, cfg, neighborhoods, true);

	if (collect_error_metrics_ && orig.has_energy() && cfg.has_energy()) {
		const double energy_delta = orig.energy - cfg.energy;
		metric_energy_abs_sum_ += std::abs(energy_delta);
		metric_energy_sq_weighted_sum_ += energy_delta * energy_delta / orig.size();
		metric_energy_atom_count_ += orig.size();
	}
	if (collect_error_metrics_ && orig.has_forces() && cfg.has_forces()) {
		for (int i = 0; i < cfg.size(); i++) {
			for (int a = 0; a < 3; a++)
			{
				const double force_delta = cfg.force(i)[a] - orig.force(i)[a];
				metric_force_abs_component_sum_ += std::abs(force_delta);
				metric_force_sq_component_sum_ += force_delta * force_delta;
			}
		}
		metric_force_component_count_ += static_cast<long long>(3) * cfg.size();
	}
	if (collect_error_metrics_ && orig.has_stresses() && cfg.has_stresses()) {
		AccumulateStressErrorMetrics(cfg.stresses,
									 orig.stresses,
									 metric_stress_abs_component_sum_,
									 metric_stress_sq_component_sum_);
		metric_stress_component_count_ += 6;
	}
	//for (int i = 0; i < p_mlip->CoeffCount(); i++)
	//	cout << p_mlip->Coeff()[i] << " ";
	//cout << endl;

	// the derivatives of loss_ wrt energy, forces and stresses
	double dLdE;
	if (dLdE_i_.size() != cfg.size())
		dLdE_i_.resize(cfg.size());
	FillWithZero(dLdE_i_);
	if (dLdF.size() != cfg.size())
		dLdF.resize(cfg.size());
	int fn = norm_by_forces;
	double d = 0.1;
	double avef = 0;
	double _std_ = 0;
	double _stdd_ = 0;
	double mean_ = 0.0;
	std::vector<double>& type_mean = type_mean_scratch_;
	std::vector<double>& type_joint = type_joint_scratch_;
	if (need_std_terms)
	{
		mean_ = orig.energy / orig.size();
		PrepareTypeScratch(cfg);
		for (int i = 0; i < cfg.size(); i++)
			type_mean[cfg.type(i)] += cfg.cal_se[i] / type_count_scratch_[cfg.type(i)];

		if ((int)type_mean.size() > 0) mean_1 += type_mean[0];
		if ((int)type_mean.size() > 1) mean_2 += type_mean[1];
		if ((int)type_mean.size() > 2) mean_3 += type_mean[2];

		for (int i = 0; i < cfg.size(); i++)
			type_joint[cfg.type(i)] += (cfg.cal_se[i] - type_mean[cfg.type(i)]) * 200.0 / (200.0 + orig.force(i).NormSq())
				/ type_count_scratch_[cfg.type(i)] / orig.size();

		for (int type : active_type_scratch_)
			_stdd_ += (type_mean[type] - mean_) * (type_mean[type] - mean_);

		for (int i = 0; i < cfg.size(); i++)
			_std_ += (cfg.cal_se[i] - type_mean[cfg.type(i)]) * (cfg.cal_se[i] - type_mean[cfg.type(i)])
				* 200.0 / (200.0 + orig.force(i).NormSq()) / orig.size();

		std_ += std_scaling * _std_;
		stdd_ += stdd_scaling * _stdd_;
	}
	


	if (orig.has_forces())
		for (int ind = 0; ind < orig.size(); ind++)
			avef += orig.force(ind).NormSq() / orig.size();

	// it is important to add the energy latest - less round-off errors this way
	if (wgt_eqtn_forces != 0 && orig.has_forces())
		for (int i = 0; i < cfg.size(); i++)
		{
			double wgt = (wgt_rel_forces<=0.0) ?
						 wgt_eqtn_forces :
						 wgt_eqtn_forces*wgt_rel_forces / (orig.force(i).NormSq() + wgt_rel_forces);

			if (weighting == "structures")
				wgt /= cfg.size();

			const Vector3 delta = cfg.force(i) - orig.force(i);
			double force_loss = 0.0;
			for (int a = 0; a < 3; ++a)
				force_loss += ForceResidualLoss(delta[a],
				                                force_loss_kind,
				                                force_log_cosh_scale);
			const double force_scale = wgt * d / (d + fn*avef);
			loss_ += force_scale * force_loss;
			for (int a = 0; a < 3; ++a)
				dLdF[i][a] = force_scale *
					ForceResidualGrad(delta[a],
					                  force_loss_kind,
					                  force_log_cosh_scale);
		}
	else
		FillWithZero(dLdF);

	double wgt_energy = wgt_eqtn_energy;
	double wgt_stress = wgt_eqtn_stress;

	if (weighting == "structures")
	{
		wgt_energy /= cfg.size();
		wgt_stress /= cfg.size();
	}
	else if (weighting == "molecules")
	{
		wgt_energy *= cfg.size();
		wgt_stress *= cfg.size();
	}

	if (wgt_stress!=0 && orig.has_stresses())
	{
		loss_ += wgt_stress * (cfg.stresses - orig.stresses).NormFrobeniusSq() / cfg.size();
		dLdS = -2.0 * wgt_stress * (cfg.stresses - orig.stresses) * (1.0/cfg.size());
	}
	else
		dLdS *= 0.0;

	if (wgt_energy!=0 && orig.has_energy())
	{
		loss_ += wgt_energy * (cfg.energy - orig.energy)*(cfg.energy - orig.energy) *d/ ((d + fn*avef)*cfg.size());
		dLdE = 2.0 * wgt_energy * (cfg.energy - orig.energy)*d /((d + fn*avef)*cfg.size());
	}
	else
		dLdE = 0.0;
	for (int i = 0; i < cfg.size(); i++)
	{
		dLdE_i_[i] += dLdE;
			if (need_std_terms)
			{
				dLdE_i_[i] += std_scaling * 2.0 * ((cfg.cal_se[i] - type_mean[cfg.type(i)]) * 200.0 / (200.0 + orig.force(i).NormSq()) / orig.size()
					- type_joint[cfg.type(i)])
					+ stdd_scaling * 2.0 * (type_mean[cfg.type(i)] - mean_) / type_count_scratch_[cfg.type(i)];
			}
		//dLdE_i[i] += dLdE + std_scaling * 2 * ((cfg.cal_se[i] - type_mean[cfg.type(i)])  / orig.size()- 0.0 * type_joint[cfg.type(i)]);
	}
	if (need_std_terms)
		loss_ += std_scaling * _std_ + stdd_scaling * _stdd_;
	p_mlip->AddPenaltyGrad(wgt_eqtn_constr, loss_, &loss_grad_);

	// Now we compute gradients, this adds to loss_grad_
	if (NeedPositionDerivativeTerms(orig)) {
		if (neighborhoods != nullptr)
			p_mlip->AccumulateEFSCombinationGrad(cfg, dLdE_i_, dLdF, dLdS, loss_grad_, *neighborhoods);
		else
			p_mlip->AccumulateEFSCombinationGrad(cfg, dLdE_i_, dLdF, dLdS, loss_grad_);
	} else {
		if (neighborhoods != nullptr)
			p_mlip->AccumulateEnergyCombinationGrad(cfg, dLdE_i_, loss_grad_, *neighborhoods);
		else
			p_mlip->AccumulateEnergyCombinationGrad(cfg, dLdE_i_, loss_grad_);
	}
	AddGateXRegularization(cfg, neighborhoods, &loss_grad_);
}


// Calculates objective function summed over train_set
double NonLinearRegression::ObjectiveFunction(vector<Configuration>& training_set)
{
	return ObjectiveFunction(training_set, nullptr);
}

double NonLinearRegression::ObjectiveFunction(vector<Configuration>& training_set, const std::vector<Neighborhoods>* neighborhoods)
{
	objective_prediction_cache_valid_ = false;
	guard_compression_prediction_cache_valid_ = false;
	ResetObjectiveAccumulators();
	for (size_t i = 0; i < training_set.size(); ++i)
		AddLoss(training_set[i], neighborhoods == nullptr ? nullptr : &(*neighborhoods)[i]);
	AddGlobalRegularization(static_cast<double>(training_set.size()), nullptr);
	AddGuardCompressionLoss(nullptr, false, false);
	return loss_;
}

double NonLinearRegression::ObjectiveFunctionAndCachePredictions(
	vector<Configuration>& training_set,
	const std::vector<Neighborhoods>* neighborhoods)
{
	ResetObjectiveAccumulators();
	objective_prediction_cache_.clear();
	objective_prediction_cache_.resize(training_set.size());
	for (size_t i = 0; i < training_set.size(); ++i)
		AddLoss(training_set[i],
		        neighborhoods == nullptr ? nullptr : &(*neighborhoods)[i],
		        &objective_prediction_cache_[i]);
	AddGlobalRegularization(static_cast<double>(training_set.size()), nullptr);
	AddGuardCompressionLoss(nullptr, false, true);
	objective_prediction_cache_valid_ =
		objective_prediction_cache_.size() == training_set.size();
	return loss_;
}

// Calculates objective function summed over train_set with their gradients
void NonLinearRegression::CalcObjectiveFunctionGrad(vector<Configuration>& training_set)
{
	CalcObjectiveFunctionGrad(training_set, nullptr);
}

void NonLinearRegression::CalcObjectiveFunctionGrad(vector<Configuration>& training_set, const std::vector<Neighborhoods>* neighborhoods)
{
	objective_prediction_cache_valid_ = false;
	guard_compression_prediction_cache_valid_ = false;
	ResetObjectiveAccumulators();
	loss_grad_.resize(p_mlip->CoeffCount());
	FillWithZero(loss_grad_);

	for (size_t i = 0; i < training_set.size(); ++i) 
		AddLossGrad(training_set[i], neighborhoods == nullptr ? nullptr : &(*neighborhoods)[i]);
	AddGlobalRegularization(static_cast<double>(training_set.size()), &loss_grad_);
	AddGuardCompressionLoss(&loss_grad_, false, false);
}

void NonLinearRegression::CalcObjectiveFunctionGradFromCachedPredictions(
	vector<Configuration>& training_set,
	const std::vector<Neighborhoods>* neighborhoods)
{
	if (!objective_prediction_cache_valid_
	    || objective_prediction_cache_.size() != training_set.size()) {
		CalcObjectiveFunctionGrad(training_set, neighborhoods);
		return;
	}

	ResetObjectiveAccumulators();
	loss_grad_.resize(p_mlip->CoeffCount());
	FillWithZero(loss_grad_);

	for (size_t i = 0; i < training_set.size(); ++i)
		AddLossGrad(training_set[i],
		            neighborhoods == nullptr ? nullptr : &(*neighborhoods)[i],
		            &objective_prediction_cache_[i]);
	AddGlobalRegularization(static_cast<double>(training_set.size()), &loss_grad_);
	AddGuardCompressionLoss(&loss_grad_, true, false);
	objective_prediction_cache_valid_ = false;
	guard_compression_prediction_cache_valid_ = false;
}

double NonLinearRegression::EnergyMAE_meVPerAtom() const
{
	if (metric_energy_atom_count_ == 0) return 0.0;
	return 1000.0 * metric_energy_abs_sum_ / static_cast<double>(metric_energy_atom_count_);
}

double NonLinearRegression::EnergyRMSE_meVPerAtom() const
{
	if (metric_energy_atom_count_ == 0) return 0.0;
	return 1000.0 * std::sqrt(metric_energy_sq_weighted_sum_ / static_cast<double>(metric_energy_atom_count_));
}

double NonLinearRegression::ForceMAE_meVPerA() const
{
	if (metric_force_component_count_ == 0) return 0.0;
	return 1000.0 * metric_force_abs_component_sum_ / static_cast<double>(metric_force_component_count_);
}

double NonLinearRegression::ForceRMSE_meVPerA() const
{
	if (metric_force_component_count_ == 0) return 0.0;
	return 1000.0 * std::sqrt(metric_force_sq_component_sum_ / static_cast<double>(metric_force_component_count_));
}

double NonLinearRegression::StressMAE_eV() const
{
	if (metric_stress_component_count_ == 0) return 0.0;
	return metric_stress_abs_component_sum_ / static_cast<double>(metric_stress_component_count_);
}

double NonLinearRegression::StressRMSE_eV() const
{
	if (metric_stress_component_count_ == 0) return 0.0;
	return std::sqrt(metric_stress_sq_component_sum_ / static_cast<double>(metric_stress_component_count_));
}

double NonLinearRegression::EFSLoss(double total_loss, double std_term, double stdd_term) const
{
	return total_loss - std_term - stdd_term;
}

#ifdef MLIP_MPI
void NonLinearRegression::Train(std::vector<Configuration>& train_set)
{
	int mpi_rank;
	int mpi_size;
	MPI_Comm_rank(MPI_COMM_WORLD, &mpi_rank);
	MPI_Comm_size(MPI_COMM_WORLD, &mpi_size);

	if (mpi_rank == 0)
	{
    std::stringstream logstrm1;
		logstrm1	<< "\tTrainer(default): Training over "
			<< train_set.size() << " configurations" << endl;
    MLP_LOG("dev",logstrm1.str());
	}

	int size = p_mlip->CoeffCount();
	double *x = p_mlip->Coeff();

        int m = (int)train_set.size(); // train set size on the current core
        int K = m;                     // train set size over all cores

        MPI_Allreduce(&m, &K, 1, MPI_INT, MPI_SUM, MPI_COMM_WORLD);

        BFGS bfgs;
        double bfgs_f;
        Array1D bfgs_g(size);

        bfgs.Set_x(x, size);

        for (int i = 0; i < size; i++)
                for (int j = 0; j < size; j++)
			if (i == j)
                                bfgs.inv_hess(i,j) = 1;
                        else
                                bfgs.inv_hess(i,j) = 0;

        int max_step_count = 500;
        double linstop = 1e-6;
        int num_step = 0;
        double linf = 9e99;
        bool converge = false;
        bool linesearch = false;

        while (!converge)
        {
                if (!linesearch)
                {
					//if (mpi_rank == 0) cout << num_step << endl;
                        if (mpi_rank == 0)
                                bfgs.Set_x(x, size);

                        MPI_Bcast(&x[0], size, MPI_DOUBLE, 0, MPI_COMM_WORLD);

                        //if (mpi_rank == 0) {
                        //        p_mlip->Save("current.mlip");
                        //}

                }

                for (int i = 0; i < size; i++)
                        x[i] = bfgs.x(i);

                MPI_Bcast(&x[0], size, MPI_DOUBLE, 0, MPI_COMM_WORLD);

                CalcObjectiveFunctionGrad(train_set);
                loss_ /= K;
                for (int i = 0; i < size; i++)
                        loss_grad_[i] /= K;

		MPI_Barrier(MPI_COMM_WORLD);
                MPI_Reduce(&loss_, &bfgs_f, 1, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);
                MPI_Reduce(&loss_grad_[0], &bfgs_g[0], size, MPI_DOUBLE, MPI_SUM, 0, MPI_COMM_WORLD);

                if (mpi_rank == 0) {
                        if (!converge) {
                                bfgs.Iterate(bfgs_f,bfgs_g);
				//if (!linesearch) {
		            //            cout << bfgs_f << endl;
					//for (int i = 0; i < size; i++)
					//	cout << bfgs.x(i) << " ";
					//cout << endl;
					//for (int i = 0; i < size; i++)
					//	cout << bfgs_g[i] << " ";
					//cout << endl;
				//}

                                while (abs(bfgs.x(0) - x[0]) > 0.5) 
                                        bfgs.ReduceStep(0.25);
                        }
                }

                linesearch = bfgs.is_in_linesearch();

                if (!linesearch) {
                        if (mpi_rank == 0) {

                                num_step++;
                                //cout << num_step << endl;

                                if (num_step % 40 == 0)
                                {
                                        if ((linf - bfgs_f) / bfgs_f < linstop)
                                        {
                                                converge = true;
                                        }

                                        //cout << (linf - bfgs_f) << " " << linf << " " << bfgs_f << endl;

                                        linf = bfgs_f;
                                }

                                if (num_step >= max_step_count || bfgs_f < 1E-15)
                                {
                                        converge = true;
                                }
                        }
                }

		MPI_Barrier(MPI_COMM_WORLD);
                MPI_Bcast(&converge, 1, MPI_C_BOOL, 0, MPI_COMM_WORLD);
                MPI_Bcast(&linesearch, 1, MPI_C_BOOL, 0, MPI_COMM_WORLD);
                MPI_Bcast(&num_step, 1, MPI_INT, 0, MPI_COMM_WORLD);
        }

	if (mpi_rank == 0)
	{
		if (!converge)
			Warning("Convergence was not achieved while training");
		else // Ok
    {
      std::stringstream logstrm1;
			logstrm1 << "\tTrainer(default): Training# "
					<< ++train_cntr << " complete" << endl;
      MLP_LOG("dev",logstrm1.str());
    }
	}
}
#else
void NonLinearRegression::Train(std::vector<Configuration>& train_set)
{
	int size = p_mlip->CoeffCount();
	double *x = p_mlip->Coeff();

        BFGS bfgs;
        double bfgs_f;
        Array1D bfgs_g(size);

        bfgs.Set_x(x, size);

        for (int i = 0; i < size; i++)
                for (int j = 0; j < size; j++)
			if (i == j)
                                bfgs.inv_hess(i,j) = 1;
                        else
                                bfgs.inv_hess(i,j) = 0;

        int max_step_count = 500;
        double linstop = 1e-6;
        int num_step = 0;
        double linf = 9e99;
        bool converge = false;
        bool linesearch = false;

        while (!converge)
        {
                if (!linesearch)
                {
                        bfgs.Set_x(x, size);

                        //p_mlip->Save("current.mlip");

                }

                for (int i = 0; i < size; i++)
                        x[i] = bfgs.x(i);

                CalcObjectiveFunctionGrad(train_set);
                loss_ /= train_set.size();
                for (int i = 0; i < size; i++)
                        loss_grad_[i] /= train_set.size();

		bfgs_f = loss_;
		memcpy(&bfgs_g[0], &loss_grad_[0], p_mlip->CoeffCount()*sizeof(double));		

                if (!converge) {
                        bfgs.Iterate(bfgs_f,bfgs_g);
			//if (!linesearch) {
	                        //cout << bfgs_f << endl;
				//for (int i = 0; i < size; i++)
				//	cout << bfgs.x(i) << " ";
				//cout << endl;
				//for (int i = 0; i < size; i++)
				//	cout << bfgs_g[i] << " ";
				//cout << endl;
			//}

                        while (abs(bfgs.x(0) - x[0]) > 0.5) 
                                bfgs.ReduceStep(0.25);
                }

                linesearch = bfgs.is_in_linesearch();

                if (!linesearch) {

                       num_step++;
                        //cout << num_step << endl;

                        if (num_step % 100 == 0)
                        {
                                if ((linf - bfgs_f) / bfgs_f < linstop)
                                {
                                        converge = true;
                                }

                                //cout << (linf - bfgs_f) << " " << linf << " " << bfgs_f << endl;

                                linf = bfgs_f;
                        }

                        if (num_step >= max_step_count || bfgs_f < 1E-15)
                        {
                                converge = true;
                        }

                }

        }

	if (!converge)
		Warning("Convergence was not achieved while training");
	else // Ok
  {
    std::stringstream logstrm1;
		logstrm1 << "\tTrainer(default): Training# "
			<< ++train_cntr << " complete" << endl;
    MLP_LOG("dev",logstrm1.str());
  }
}
#endif

bool NonLinearRegression::CheckLossConsistency_debug(Configuration cfg, double displacement, double control_delta)
{
	default_random_engine generator(777);
	uniform_real_distribution<double> distribution(0.0, 1.0);
	double delta_c = displacement;
	double dloss_actual;
	double rel_err_max = 0;
	int n = p_mlip->CoeffCount();
	vector<double> dloss_predict(n);

	vector<Configuration> train_set(1, cfg);

	//for (int i=0; i<n; i++)
		//p_mlip->Coeff()[i] = distribution(generator);

	CalcObjectiveFunctionGrad(train_set);

	//double loss0 = loss_;
	double lossp, lossm;

	for (int i=0; i<n; i++)
		dloss_predict[i] = loss_grad_[i];

	for (int i=0; i<n; i++)
	{
		p_mlip->Coeff()[i] += delta_c;
		//cout << p_mlip->Coeff()[i] << " ";
		lossp = ObjectiveFunction(train_set);
		p_mlip->Coeff()[i] -= 2*delta_c;
		//cout << p_mlip->Coeff()[i] << endl;
		lossm = ObjectiveFunction(train_set);
		p_mlip->Coeff()[i] += delta_c;
		dloss_actual = (lossp - lossm) / (2*displacement);

		//cout << i << " " << lossp << " " << lossm << endl;
		//cout << loss_grad_[i] << " " << dloss_actual << " " << fabs(dloss_actual-loss_grad_[i]) << endl; 

		if (abs((dloss_actual - dloss_predict[i]) / dloss_actual)>rel_err_max)
			rel_err_max = abs((dloss_actual - dloss_predict[i]) / dloss_actual);
	}

	return (rel_err_max < control_delta);
}
